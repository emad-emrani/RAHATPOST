import { createServerFn } from "@tanstack/react-start";
import { sanitizeSettings, type SiteSettings } from "./types";

/** Public: current settings (applied on every page by the root route, never stale-cached). */
export const getSiteSettings = createServerFn({ method: "GET" }).handler(
  async (): Promise<SiteSettings> => {
    const { loadSettings } = await import("./store.server");
    const settings = await loadSettings();
    try {
      const { setResponseHeader } = await import("@tanstack/react-start/server");
      setResponseHeader("Cache-Control", "private, no-store, no-cache, must-revalidate, max-age=0");
    } catch {
      // outside a request
    }
    return settings;
  },
);

async function owner(): Promise<boolean> {
  const { isAdmin, isOwner } = await import("@/lib/admin-auth");
  const [adm, own] = await Promise.all([
    isAdmin().catch(() => false),
    isOwner().catch(() => false),
  ]);
  return Boolean(adm || own);
}

export const adminGetSiteSettings = createServerFn({ method: "POST" }).handler(
  async (): Promise<{ authed: boolean; settings: SiteSettings | null }> => {
    if (!(await owner())) return { authed: false, settings: null };
    const { loadSettings } = await import("./store.server");
    return { authed: true, settings: await loadSettings() };
  },
);

export const adminSaveSiteSettings = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => input)
  .handler(
    async ({ data }): Promise<{ ok: boolean; message?: string; settings?: SiteSettings }> => {
      if (!(await owner())) return { ok: false, message: "هذا القسم لمالك الموقع فقط." };
      if (JSON.stringify(data ?? {}).length > 80_000)
        return { ok: false, message: "البيانات كبيرة جداً." };
      try {
        const settings = sanitizeSettings(data);
        const { saveSettings } = await import("./store.server");
        await saveSettings(settings);
        return { ok: true, settings };
      } catch (error) {
        console.error("[settings] save failed", error);
        const errMsg = error instanceof Error ? error.message : String(error ?? "");
        const errCode = (error as { code?: string })?.code ?? "";
        if (errCode === "53000" || /quota|compute time|transfer|storage limit|exceeded/i.test(errMsg)) {
          return {
            ok: false,
            message: "تعذّر الحفظ: قاعدة البيانات (Neon) وصلت للحد المجاني — افتح لوحة Neon للتحقق من الحصة.",
          };
        }
        return { ok: false, message: `تعذّر الحفظ في قاعدة البيانات (${errCode || errMsg.slice(0, 80) || "خطأ غير معروف"}).` };
      }
    },
  );

export const adminResetSiteSettings = createServerFn({ method: "POST" }).handler(
  async (): Promise<{ ok: boolean }> => {
    if (!(await owner())) return { ok: false };
    const { resetSettings } = await import("./store.server");
    await resetSettings();
    return { ok: true };
  },
);
