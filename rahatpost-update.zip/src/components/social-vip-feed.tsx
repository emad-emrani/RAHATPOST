import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useSiteSettings } from "@/lib/site-settings/context";
import { tr, trv } from "@/lib/i18n/core";

export interface SocialVipPostItem {
  id: string;
  platform: "x" | "facebook";
  authorName: string;
  authorHandle: string;
  authorRole: string;
  category: "politicians" | "celebrities" | "sports" | "local";
  avatarUrl: string;
  verified: "blue" | "gold" | "gray";
  publishedAgo: string;
  originalLang: "he" | "en" | "ar";
  originalText: string;
  translatedAr: string;
  trendTag?: string;
  likes: number;
  commentsCount: number;
  shares: number;
  views: string;
  linkPreview?: {
    title: string;
    description: string;
    domain: string;
    imageUrl?: string;
    url?: string;
  };
  sampleComments: { author: string; text: string; time: string; avatar?: string }[];
}

export interface LocalTrackedFigure {
  id: string;
  name: string;
  fbUrl: string;
  role: string;
  category: "local" | "politicians" | "community";
  autoPublish: boolean;
  avatarUrl?: string;
  lastChecked?: string;
}

export interface TrendTopicItem {
  rank: number;
  scope: "global" | "local";
  hashtag: string;
  categoryLabel: string;
  postsCount: string;
  summaryAr: string;
  isHot?: boolean;
}

export interface SocialHubConfig {
  vipSectionEnabled: boolean;
  defaultTrendScope: "local" | "global";
  showTrendsDrawerOpen: boolean;
  fbPageName: string;
  fbPageUrl: string;
  fbPageId: string;
  fbAutoPublish: boolean;
  tiktokHandle: string;
  telegramChannel: string;
}

export interface WorldVipPreset {
  id: string;
  name: string;
  handle: string;
  role: string;
  platform: "x" | "facebook";
  category: "politicians" | "celebrities" | "sports";
  avatarInitials: string;
  avatarBg: string;
  verified: "blue" | "gold" | "gray";
  defaultText: string;
  translatedAr: string;
  trendTag: string;
  fbOrXUrl: string;
}

function fromBase64UrlSafe(b64u: string): string {
  try {
    const b64 = b64u.replace(/-/g, "+").replace(/_/g, "/");
    const pad = b64.length % 4 === 0 ? "" : "=".repeat(4 - (b64.length % 4));
    const bin = typeof atob === "function" ? atob(b64 + pad) : "";
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch {
    return "";
  }
}

export function toBase64UrlSafe(str: string): string {
  try {
    const bytes = new TextEncoder().encode(str);
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  } catch {
    return "";
  }
}

export function parseSocialHubConfig(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): SocialHubConfig {
  const item = (quickLinks ?? []).find((q) => q.id === "socialhubcfg");
  let vipSectionEnabled = false;
  let defaultTrendScope: "local" | "global" = "local";
  let showTrendsDrawerOpen = false;
  let fbPageName = "رهط بوست - Rahat Post";
  let fbPageUrl = "https://www.facebook.com/rahatpost";
  let fbPageId = "";
  let fbAutoPublish = true;
  let tiktokHandle = "@rahatpost";
  let telegramChannel = "https://t.me/rahatpost";

  if (item) {
    const raw = `${item.title ?? ""}|${item.subtitle ?? ""}`;
    for (const part of raw.split("|")) {
      const p = part.trim();
      if (p.startsWith("vip:")) vipSectionEnabled = p.slice(4) === "1";
      else if (p.startsWith("scope:")) {
        const v = p.slice(6);
        if (v === "global" || v === "local") defaultTrendScope = v;
      } else if (p.startsWith("open:")) showTrendsDrawerOpen = p.slice(5) === "1";
      else if (p.startsWith("fbauto:")) fbAutoPublish = p.slice(7) !== "0";
      else if (p.startsWith("fbid:")) fbPageId = p.slice(5);
      else if (p.startsWith("tt:")) tiktokHandle = p.slice(3) || tiktokHandle;
    }
    if (item.url && item.url.startsWith("/__shcfg?")) {
      const jsonStr = fromBase64UrlSafe(item.url.slice(9));
      if (jsonStr) {
        try {
          const parsed = JSON.parse(jsonStr);
          if (typeof parsed.fbPageName === "string" && parsed.fbPageName) fbPageName = parsed.fbPageName;
          if (typeof parsed.fbPageUrl === "string" && parsed.fbPageUrl) fbPageUrl = parsed.fbPageUrl;
          if (typeof parsed.telegramChannel === "string" && parsed.telegramChannel)
            telegramChannel = parsed.telegramChannel;
        } catch {
          /* ignore */
        }
      }
    }
  }

  return {
    vipSectionEnabled,
    defaultTrendScope,
    showTrendsDrawerOpen,
    fbPageName,
    fbPageUrl,
    fbPageId,
    fbAutoPublish,
    tiktokHandle,
    telegramChannel,
  };
}

export function parseCustomVipPosts(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): SocialVipPostItem[] {
  const item = (quickLinks ?? []).find((q) => q.id === "socialvipcustom");
  if (!item?.url?.startsWith("/__svip?")) return [];
  const raw = fromBase64UrlSafe(item.url.slice(8) + (item.subtitle && item.subtitle !== "vip" ? item.subtitle : ""));
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export const DEFAULT_LOCAL_FIGURES: LocalTrackedFigure[] = [
  {
    id: "fig-rahat-muni",
    name: "بلدية رهط - الصفحة الرسمية",
    fbUrl: "https://www.facebook.com/RahatMunicipality",
    role: "إدارة البلدية والمشاريع العامة",
    category: "local",
    autoPublish: true,
  },
  {
    id: "fig-matnas-rahat",
    name: "المركز الجماهيري رهط",
    fbUrl: "https://www.facebook.com/matnas.rahat",
    role: "فعاليات ثقافية وشبابية",
    category: "community",
    autoPublish: true,
  },
  {
    id: "fig-mansour-abbas",
    name: "د. منصور عباس - Mansour Abbas",
    fbUrl: "https://www.facebook.com/MansourAbbasOfficial",
    role: "عضو كنيست · شؤون النقب والمجتمع",
    category: "politicians",
    autoPublish: true,
  },
  {
    id: "fig-negev-sports",
    name: "نادي هبوعيل أبناء رهط",
    fbUrl: "https://www.facebook.com/rahat.football",
    role: "رياضة وكرة القدم المحلية",
    category: "local",
    autoPublish: true,
  },
];

export function parseLocalTrackedFigures(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): LocalTrackedFigure[] {
  const item = (quickLinks ?? []).find((q) => q.id === "socialfigures");
  if (!item?.url?.startsWith("/__sfig?")) return DEFAULT_LOCAL_FIGURES;
  const raw = fromBase64UrlSafe(item.url.slice(8) + (item.subtitle && item.subtitle !== "fig" ? item.subtitle : ""));
  if (!raw) return DEFAULT_LOCAL_FIGURES;
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) && arr.length > 0 ? arr : DEFAULT_LOCAL_FIGURES;
  } catch {
    return DEFAULT_LOCAL_FIGURES;
  }
}

export function encodeLocalTrackedFigures(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
  figures: LocalTrackedFigure[],
) {
  const encoded = toBase64UrlSafe(JSON.stringify(figures));
  const otherLinks = (quickLinks ?? []).filter((q) => q.id !== "socialfigures");
  return [
    ...otherLinks,
    {
      id: "socialfigures",
      title: `figures:${figures.length}`,
      subtitle: encoded.slice(180) || "fig",
      url: `/__sfig?${encoded.slice(0, 180)}`,
      emoji: "👥",
    },
  ];
}

export function makeAvatarSvgDataUri(initials: string, bgHex: string, accentHex = "#ffffff"): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${bgHex}"/><stop offset="100%" stop-color="#0f172a"/></linearGradient></defs><rect width="80" height="80" rx="40" fill="url(#g)"/><circle cx="40" cy="40" r="37" fill="none" stroke="${accentHex}" stroke-opacity="0.3" stroke-width="2"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="${accentHex}" font-family="system-ui, sans-serif" font-weight="800" font-size="26">${initials}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const WORLD_VIP_PRESETS: WorldVipPreset[] = [
  {
    id: "elon-musk",
    name: "Elon Musk",
    handle: "@elonmusk",
    role: "مالك 𝕏 ورئيس Tesla و SpaceX",
    platform: "x",
    category: "celebrities",
    avatarInitials: "EM",
    avatarBg: "#0f172a",
    verified: "blue",
    defaultText: "The pace of AI progress is accelerating rapidly. Open source models, humanoid robotics, and autonomous systems will change everyday life faster than people think. Exciting future ahead! 🚀🤖",
    translatedAr: "وتيرة تقدم الذكاء الاصطناعي تتسارع بشكل هائل. النماذج مفتوحة المصدر والروبوتات الشبيهة بالبشر والأنظمة الذاتية ستغير الحياة اليومية أسرع مما يتوقع الكثيرون. المستقبل القادم واعد ومثير جداً! 🚀🤖",
    trendTag: "#AI_Innovation",
    fbOrXUrl: "https://x.com/elonmusk",
  },
  {
    id: "donald-trump",
    name: "Donald J. Trump",
    handle: "@realDonaldTrump",
    role: "الرئيس الأمريكي الـ47 · سياسي ورجل أعمال",
    platform: "x",
    category: "politicians",
    avatarInitials: "DJT",
    avatarBg: "#1e3a8a",
    verified: "gray",
    defaultText: "We are laser-focused on restoring economic strength, manufacturing independence, energy dominance, and global peace through strength. Big results coming for all workers and families!",
    translatedAr: "تركيزنا منصب بدقة على استعادة القوة الاقتصادية والاستقلال الصناعي والهيمنة في قطاع الطاقة وتحقيق السلام عبر القوة. نتائج كبرى قادمة لجميع العمال والأسر!",
    trendTag: "#MiddleEastNews",
    fbOrXUrl: "https://x.com/realDonaldTrump",
  },
  {
    id: "benjamin-netanyahu",
    name: "Benjamin Netanyahu - בנימין נתניהו",
    handle: "@netanyahu",
    role: "رئيس الحكومة الإسرائيلية · سياسي",
    platform: "x",
    category: "politicians",
    avatarInitials: "BN",
    avatarBg: "#1d4ed8",
    verified: "gray",
    defaultText: "אנחנו ממשיכים לפעול בנחישות להבטחת ביטחון המדינה, להרחבת היציבות וההסכמים האזוריים, ולחיזוק הכלכלה והתשתיות בכל רחבי הארץ ובדרום.",
    translatedAr: "نحن نواصل العمل بحزم لضمان أمن الدولة وتوسيع الاستقرار والاتفاقيات الإقليمية وتعزيز الاقتصاد والبنية التحتية في جميع أنحاء البلاد والجنوب.",
    trendTag: "#أخبار_النقب",
    fbOrXUrl: "https://x.com/netanyahu",
  },
  {
    id: "ahmad-tibi",
    name: "د. أحمد الطيبي - Ahmad Tibi",
    handle: "@Ahmad_tibi",
    role: "عضو كنيست · رئيس الحركة العربية للتغيير",
    platform: "x",
    category: "politicians",
    avatarInitials: "أط",
    avatarBg: "#0f766e",
    verified: "gray",
    defaultText: "مستمرون في التصدي لسياسات التمييز وهدم البيوت في النقب والبلدات العربية، ومطلبنا واضح: حقوق متساوية كاملة، ميزانيات عادلة، واعتراف رسمي بكافة القرى غير المعترف بها.",
    translatedAr: "مستمرون في التصدي لسياسات التمييز وهدم البيوت في النقب والبلدات العربية، ومطلبنا واضح: حقوق متساوية كاملة، ميزانيات عادلة، واعتراف رسمي بكافة القرى غير المعترف بها.",
    trendTag: "#أخبار_النقب",
    fbOrXUrl: "https://x.com/Ahmad_tibi",
  },
  {
    id: "ayman-odeh",
    name: "أيمن عودة - Ayman Odeh",
    handle: "@AyOdeh",
    role: "عضو كنيست · سياسي وقيادي",
    platform: "x",
    category: "politicians",
    avatarInitials: "ع ع",
    avatarBg: "#b91c1c",
    verified: "gray",
    defaultText: "النقب كان وسيبقى صامداً بأهله وأرضه. لا يمكن لأي خطة أن تنجح دون الاعتراف بحق أهلنا التاريخي في أراضيهم وقراهم وبناء مستقبل كريم لشبابنا.",
    translatedAr: "النقب كان وسيبقى صامداً بأهله وأرضه. لا يمكن لأي خطة أن تنجح دون الاعتراف بحق أهلنا التاريخي في أراضيهم وقراهم وبناء مستقبل كريم لشبابنا.",
    trendTag: "#أخبار_النقب",
    fbOrXUrl: "https://x.com/AyOdeh",
  },
  {
    id: "recep-erdogan",
    name: "Recep Tayyip Erdoğan",
    handle: "@RTErdogan",
    role: "الرئيس التركي · سياسي وقائد دولي",
    platform: "x",
    category: "politicians",
    avatarInitials: "RTE",
    avatarBg: "#dc2626",
    verified: "gray",
    defaultText: "Bölgemizde ve dünyada barış, istikrar ve adaletin tesisi için diplomasiyi en güçlü şekilde işletmeye ve mazlum halkların sesi olmaya kararlılıkla devam edeceğiz.",
    translatedAr: "سنواصل بحزم تفعيل الدبلوماسية بأقوى شكل ممكن لترسيخ السلام والاستقرار والعدالة في منطقتنا والعالم، ونظل صوتاً للشعوب المظلومة.",
    trendTag: "#MiddleEastNews",
    fbOrXUrl: "https://x.com/RTErdogan",
  },
  {
    id: "joe-biden",
    name: "Joe Biden",
    handle: "@JoeBiden",
    role: "رئيس الولايات المتحدة الأمريكية",
    platform: "x",
    category: "politicians",
    avatarInitials: "JB",
    avatarBg: "#1e40af",
    verified: "gray",
    defaultText: "Democracy, international alliances, and investing in our people remain the bedrock of sustainable progress across the globe.",
    translatedAr: "الديمقراطية والتحالفات الدولية والاستثمار في طاقات شعوبنا تظل حجر الأساس لتحقيق التقدم المستدام في جميع أنحاء العالم.",
    trendTag: "#MiddleEastNews",
    fbOrXUrl: "https://x.com/JoeBiden",
  },
  {
    id: "cristiano-ronaldo",
    name: "Cristiano Ronaldo",
    handle: "@Cristiano",
    role: "أسطورة كرة القدم العالمية · النصر",
    platform: "x",
    category: "sports",
    avatarInitials: "CR7",
    avatarBg: "#fbbf24",
    verified: "blue",
    defaultText: "Dedication, passion and teamwork always lead to glory! Thank you to our incredible fans around the world for your unconditional love and support. Siuuu! ⚽️🟡🔵",
    translatedAr: "التفاني والشغف والعمل الجماعي يقود دائماً إلى المجد! شكراً لجماهيرنا الرائعة حول العالم على محبتكم ودعمكم المستمر. إلى الأمام دائماً! ⚽️🟡🔵",
    trendTag: "#ChampionsLeague",
    fbOrXUrl: "https://x.com/Cristiano",
  },
  {
    id: "bill-gates",
    name: "Bill Gates",
    handle: "@BillGates",
    role: "مؤسس Microsoft ورئيس مؤسسة غيتس",
    platform: "x",
    category: "celebrities",
    avatarInitials: "BG",
    avatarBg: "#0284c7",
    verified: "blue",
    defaultText: "The intersection of clean energy innovation and generative AI gives us the greatest chance to solve global challenges like climate and healthcare equity.",
    translatedAr: "إن التقاء ابتكارات الطاقة النظيفة مع الذكاء الاصطناعي التوليدي يمنحنا أعظم فرصة لمواجهة التحديات العالمية مثل المناخ والعدالة الصحية.",
    trendTag: "#TechTrends2026",
    fbOrXUrl: "https://x.com/BillGates",
  },
  {
    id: "lionel-messi",
    name: "Leo Messi",
    handle: "@leomessi",
    role: "أسطورة كرة القدم العالمية · إنتر ميامي",
    platform: "facebook",
    category: "sports",
    avatarInitials: "LM",
    avatarBg: "#ec4899",
    verified: "blue",
    defaultText: "Very happy for another great victory with the team! We keep working hard with humility and determination for every upcoming match. Vamos! 💖⚽️",
    translatedAr: "سعيد جداً بتحقيق انتصار رائع جديد مع الفريق! نواصل العمل بجد وتواضع وعزيمة لكل مباراة وتحدٍ قادم. إلى الأمام! 💖⚽️",
    trendTag: "#ChampionsLeague",
    fbOrXUrl: "https://www.facebook.com/leomessi",
  },
  {
    id: "mark-zuckerberg",
    name: "Mark Zuckerberg",
    handle: "@zuck",
    role: "مؤسس فيسبوك والرئيس التنفيذي لـ Meta",
    platform: "facebook",
    category: "celebrities",
    avatarInitials: "MZ",
    avatarBg: "#1877f2",
    verified: "blue",
    defaultText: "Open source AI and next-generation smart glasses are transforming personal computing. Millions of communities connect every day across Facebook, WhatsApp and Instagram through intelligent tools.",
    translatedAr: "الذكاء الاصطناعي مفتوح المصدر ونظارات الجيل القادم الذكية تُحدث تحولاً جذرياً في الحوسبة الشخصية. ملايين المجتمعات تتواصل يومياً عبر فيسبوك وواتساب وإنستغرام عبر أدوات ذكية متطورة.",
    trendTag: "#TechTrends2026",
    fbOrXUrl: "https://www.facebook.com/zuck",
  },
];

export const DEFAULT_TREND_TOPICS: TrendTopicItem[] = [
  {
    rank: 1,
    scope: "local",
    hashtag: "#رهط_بوست",
    categoryLabel: "رهط والنقب · متصدر إكس وفيسبوك",
    postsCount: "38.2K تفاعل",
    summaryAr: "تغطية شاملة لأخبار ومشاريع مدينة رهط ومواعيد باصات غاليم والمباريات.",
    isHot: true,
  },
  {
    rank: 2,
    scope: "local",
    hashtag: "#أخبار_النقب",
    categoryLabel: "شؤون محلية وسياسة",
    postsCount: "29.4K تغريدة ومنشور",
    summaryAr: "تفاعل واسع مع مشاريع البنية التحتية وتطوير الخدمات في بلدات النقب.",
    isHot: true,
  },
  {
    rank: 3,
    scope: "local",
    hashtag: "#بلدية_رهط",
    categoryLabel: "خدمات ومشاريع المدينة",
    postsCount: "21.6K تفاعل",
    summaryAr: "بيانات مشاريع الشوارع والمناوبات الطبية وتطوير المرافق العامة.",
    isHot: true,
  },
  {
    rank: 4,
    scope: "local",
    hashtag: "#الكنيست_والعرب",
    categoryLabel: "سياسة وبرلمان",
    postsCount: "34.1K تغريدة",
    summaryAr: "تصريحات النواب والكتل البرلمانية العربية حول قضايا النقب والمجتمع.",
    isHot: true,
  },
  {
    rank: 5,
    scope: "local",
    hashtag: "#هبوعيل_بئر_السبع",
    categoryLabel: "رياضة محلية · ليغات هعل",
    postsCount: "17.9K منشور",
    summaryAr: "تحليلات جماهير الكرة في رهط والجنوب لمباريات الدوري الممتاز.",
  },
  // Global Trends
  {
    rank: 1,
    scope: "global",
    hashtag: "#AI_Innovation",
    categoryLabel: "تريند عالمي · 𝕏 وتكنولوجيا",
    postsCount: "420K تغريدة",
    summaryAr: "تغريدات إيلون ماسك وقادة التقنية حول ثورة الروبوتات والذكاء الاصطناعي.",
    isHot: true,
  },
  {
    rank: 2,
    scope: "global",
    hashtag: "#MiddleEastNews",
    categoryLabel: "سياسة وأخبار دولية",
    postsCount: "680K تغريدة وتفاعل",
    summaryAr: "تصريحات ترامب وأردوغان والقادة الدوليين حول المستجدات الإقليمية.",
    isHot: true,
  },
  {
    rank: 3,
    scope: "global",
    hashtag: "#ChampionsLeague",
    categoryLabel: "تريند عالمي · رياضة",
    postsCount: "530K منشور وتغريدة",
    summaryAr: "أصداء مواجهات دوري أبطال أوروبا وتألق كبار أندية العالم.",
    isHot: true,
  },
  {
    rank: 4,
    scope: "global",
    hashtag: "#TechTrends2026",
    categoryLabel: "ابتكارات واقتصاد رقمي",
    postsCount: "215K تغريدة",
    summaryAr: "تقنيات الهواتف الذكية والنظارات الذكية وتطبيقات المستقبل.",
  },
];

export const DEFAULT_VIP_POSTS: SocialVipPostItem[] = [
  // 1. إيلون ماسك على إكس (تويتر)
  {
    id: "vip-elon-musk",
    platform: "x",
    authorName: "Elon Musk",
    authorHandle: "@elonmusk",
    authorRole: "مالك 𝕏 ورئيس Tesla و SpaceX و xAI",
    category: "celebrities",
    avatarUrl: makeAvatarSvgDataUri("EM", "#0f172a", "#f2c94c"),
    verified: "blue",
    publishedAgo: "منذ 28 دقيقة",
    originalLang: "en",
    originalText:
      "The pace of AI progress is accelerating rapidly. Open source models, humanoid robotics, and autonomous systems will change everyday life faster than people think. Exciting future ahead! 🚀🤖",
    translatedAr:
      "وتيرة تقدم الذكاء الاصطناعي تتسارع بشكل هائل. النماذج مفتوحة المصدر والروبوتات الشبيهة بالبشر والأنظمة الذاتية ستغير الحياة اليومية أسرع مما يتوقع الكثيرون. المستقبل القادم واعد ومثير جداً! 🚀🤖",
    trendTag: "#AI_Innovation",
    likes: 198000,
    commentsCount: 17400,
    shares: 31200,
    views: "9.4M",
    linkPreview: {
      title: "Elon Musk: Next generation xAI Grok & Tesla Optimus update",
      description: "Real-time robotics and language models advancing global compute power.",
      domain: "x.com",
      url: "https://x.com/elonmusk",
    },
    sampleComments: [
      { author: "Tech Lead", text: "Humanoid robotics and autonomous AI are advancing at lightning speed.", time: "منذ 20 د" },
      { author: "مبرمج من رهط", text: "إيلون ماسك يقود ثورة الذكاء الاصطناعي في العالم.", time: "منذ 10 د" },
    ],
  },
  // 2. دونالد ترامب على إكس (تويتر)
  {
    id: "vip-donald-trump-x",
    platform: "x",
    authorName: "Donald J. Trump",
    authorHandle: "@realDonaldTrump",
    authorRole: "الرئيس الأمريكي الـ47 · سياسي وقائد",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("DJT", "#1e3a8a", "#f59e0b"),
    verified: "gray",
    publishedAgo: "منذ 45 دقيقة",
    originalLang: "en",
    originalText:
      "We are laser-focused on restoring economic strength, manufacturing independence, energy dominance, and global peace through strength. Big results coming for all workers and families!",
    translatedAr:
      "تركيزنا منصب بدقة على استعادة القوة الاقتصادية والاستقلال الصناعي والهيمنة في قطاع الطاقة وتحقيق السلام عبر القوة. نتائج كبرى قادمة لجميع العمال والأسر!",
    trendTag: "#MiddleEastNews",
    likes: 164000,
    commentsCount: 28900,
    shares: 22800,
    views: "7.8M",
    linkPreview: {
      title: "Donald J. Trump Statement on Economic & Energy Policy",
      description: "Major initiatives for industrial growth, bilateral trade, and global peace.",
      domain: "x.com",
      url: "https://x.com/realDonaldTrump",
    },
    sampleComments: [
      { author: "متابع شؤون دولية", text: "تصريحات ترامب تحرك الأسواق العالمية والنفط في دقائق.", time: "منذ 30 د" },
    ],
  },
  // 3. د. أحمد الطيبي على إكس (تويتر)
  {
    id: "vip-ahmad-tibi",
    platform: "x",
    authorName: "د. أحمد الطيبي - Ahmad Tibi",
    authorHandle: "@Ahmad_tibi",
    authorRole: "عضو كنيست · رئيس الحركة العربية للتغيير",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("أط", "#0f766e", "#f2c94c"),
    verified: "gray",
    publishedAgo: "منذ ساعة",
    originalLang: "ar",
    originalText:
      "مستمرون في التصدي لسياسات التمييز وهدم البيوت في النقب والبلدات العربية. مطلبنا واضح وثابت: حقوق متساوية كاملة، ميزانيات عادلة، واعتراف رسمي فوري بكافة القرى غير المعترف بها في النقب.",
    translatedAr:
      "مستمرون في التصدي لسياسات التمييز وهدم البيوت في النقب والبلدات العربية. مطلبنا واضح وثابت: حقوق متساوية كاملة، ميزانيات عادلة، واعتراف رسمي فوري بكافة القرى غير المعترف بها في النقب.",
    trendTag: "#الكنيست_والعرب",
    likes: 4850,
    commentsCount: 680,
    shares: 720,
    views: "145K",
    sampleComments: [
      { author: "خليل الهزيل - رهط", text: "صوت النقب وقضاياه في الكنيست، كل التقدير دكتور.", time: "منذ 40 د" },
    ],
  },
  // 4. بنيامين نتنياهو على إكس (تويتر)
  {
    id: "vip-netanyahu-x",
    platform: "x",
    authorName: "Benjamin Netanyahu - בנימין נתניהו",
    authorHandle: "@netanyahu",
    authorRole: "رئيس الحكومة الإسرائيلية · سياسي",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("BN", "#1d4ed8", "#ffffff"),
    verified: "gray",
    publishedAgo: "منذ ساعة وربع",
    originalLang: "he",
    originalText:
      "אנחנו ממשיכים לפעול בנחישות להבטחת ביטחון המדינה, להרחבת היציבות וההסכמים האזוריים, ולחיזוק הכלכלה והתשתיות בכל רחבי הארץ ובדרום.",
    translatedAr:
      "نحن نواصل العمل بحزم لضمان أمن الدولة وتوسيع الاستقرار والاتفاقيات الإقليمية وتعزيز الاقتصاد والبنية التحتية في جميع أنحاء البلاد والجنوب.",
    trendTag: "#أخبار_النقب",
    likes: 34200,
    commentsCount: 8100,
    shares: 4200,
    views: "1.1M",
    sampleComments: [
      { author: "متابع محلي - الجنوب", text: "المطلوب قرارات ملموسة لمشاريع البنية التحتية والتشغيل في النقب.", time: "منذ ساعة" },
    ],
  },
  // 5. رجب طيب أردوغان على إكس (تويتر)
  {
    id: "vip-erdogan",
    platform: "x",
    authorName: "Recep Tayyip Erdoğan",
    authorHandle: "@RTErdogan",
    authorRole: "الرئيس التركي · سياسي وقائد دولي",
    platform: "x",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("RTE", "#dc2626", "#ffffff"),
    verified: "gray",
    publishedAgo: "منذ ساعة ونصف",
    originalLang: "tr",
    originalText:
      "Bölgemizde ve dünyada barış, istikrar ve adaletin tesisi için diplomasiyi en güçlü şekilde işletmeye ve mazlum halkların sesi olmaya kararlılıkla devam edeceğiz.",
    translatedAr:
      "سنواصل بحزم تفعيل الدبلوماسية بأقوى شكل ممكن لترسيخ السلام والاستقرار والعدالة في منطقتنا والعالم، ونظل صوتاً للشعوب المظلومة.",
    trendTag: "#MiddleEastNews",
    likes: 58900,
    commentsCount: 9400,
    shares: 8800,
    views: "2.8M",
    sampleComments: [
      { author: "متابع شؤون الشرق الأوسط", text: "الدبلوماسية الإقليمية تشهد تحركات مكثفة هذا الأسبوع.", time: "منذ ساعة" },
    ],
  },
  // 6. أيمن عودة على إكس (تويتر)
  {
    id: "vip-ayman-odeh",
    platform: "x",
    authorName: "أيمن عودة - Ayman Odeh",
    authorHandle: "@AyOdeh",
    authorRole: "عضو كنيست · سياسي وقيادي",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("ع ع", "#b91c1c", "#fde047"),
    verified: "gray",
    publishedAgo: "منذ ساعتين",
    originalLang: "ar",
    originalText:
      "النقب كان وسيبقى صامداً بأهله وأرضه وشبابه. لا يمكن لأي خطة أن تنجح دون الاعتراف بحق أهلنا التاريخي في أراضيهم وبناء مستقبل كريم لأبنائنا في مدن وقرى النقب.",
    translatedAr:
      "النقب كان وسيبقى صامداً بأهله وأرضه وشبابه. لا يمكن لأي خطة أن تنجح دون الاعتراف بحق أهلنا التاريخي في أراضيهم وبناء مستقبل كريم لأبنائنا في مدن وقرى النقب.",
    trendTag: "#الكنيست_والعرب",
    likes: 3820,
    commentsCount: 512,
    shares: 490,
    views: "98K",
    sampleComments: [
      { author: "شاب من رهط", text: "الصمود والحفاظ على الأرض في النقب هو الأساس.", time: "منذ ساعة" },
    ],
  },
  // 7. كريستيانو رونالدو على إكس (تويتر)
  {
    id: "vip-cristiano-ronaldo-x",
    platform: "x",
    authorName: "Cristiano Ronaldo",
    authorHandle: "@Cristiano",
    authorRole: "أسطورة كرة القدم العالمية · النصر",
    category: "sports",
    avatarUrl: makeAvatarSvgDataUri("CR7", "#fbbf24", "#0f172a"),
    verified: "blue",
    publishedAgo: "منذ ساعتين ونصف",
    originalLang: "en",
    originalText:
      "Dedication, passion and teamwork always lead to glory! Thank you to our incredible fans around the world for your unconditional love and support. Siuuu! ⚽️🟡🔵",
    translatedAr:
      "التفاني والشغف والعمل الجماعي يقود دائماً إلى المجد! شكراً لجماهيرنا الرائعة حول العالم على محبتكم ودعمكم المستمر. إلى الأمام دائماً! ⚽️🟡🔵",
    trendTag: "#ChampionsLeague",
    likes: 362000,
    commentsCount: 33400,
    shares: 46800,
    views: "16.1M",
    sampleComments: [
      { author: "عشاق الدون في رهط", text: "الأسطورة لا يتوقف عن العطاء، كل التحية من النقب!", time: "منذ ساعتين" },
    ],
  },
  // 8. بيل غيتس على إكس (تويتر)
  {
    id: "vip-bill-gates",
    platform: "x",
    authorName: "Bill Gates",
    authorHandle: "@BillGates",
    authorRole: "مؤسس Microsoft ورئيس مؤسسة غيتس",
    category: "celebrities",
    avatarUrl: makeAvatarSvgDataUri("BG", "#0284c7", "#ffffff"),
    verified: "blue",
    publishedAgo: "منذ 3 ساعات",
    originalLang: "en",
    originalText:
      "The intersection of clean energy innovation and generative AI gives us the greatest chance to solve global challenges like climate and healthcare equity.",
    translatedAr:
      "إن التقاء ابتكارات الطاقة النظيفة مع الذكاء الاصطناعي التوليدي يمنحنا أعظم فرصة لمواجهة التحديات العالمية مثل المناخ والعدالة الصحية.",
    trendTag: "#TechTrends2026",
    likes: 42100,
    commentsCount: 3900,
    shares: 6100,
    views: "2.4M",
    sampleComments: [
      { author: "باحث تقني", text: "الذكاء الاصطناعي في الطب والطاقة النظيفة يمثل قفزة نوعية للبشرية.", time: "منذ ساعتين" },
    ],
  },
  // 9. ليونيل ميسي على فيسبوك
  {
    id: "vip-lionel-messi-fb",
    platform: "facebook",
    authorName: "Leo Messi",
    authorHandle: "@leomessi",
    authorRole: "أسطورة كرة القدم العالمية · إنتر ميامي",
    category: "sports",
    avatarUrl: makeAvatarSvgDataUri("LM", "#ec4899", "#111827"),
    verified: "blue",
    publishedAgo: "منذ 3 ساعات ونصف",
    originalLang: "en",
    originalText:
      "Very happy for another great victory with the team! We keep working hard with humility and determination for every upcoming match. Vamos! 💖⚽️",
    translatedAr:
      "سعيد جداً بتحقيق انتصار رائع جديد مع الفريق! نواصل العمل بجد وتواضع وعزيمة لكل مباراة وتحدٍ قادم. إلى الأمام! 💖⚽️",
    trendTag: "#ChampionsLeague",
    likes: 442000,
    commentsCount: 39800,
    shares: 58200,
    views: "18.1M",
    linkPreview: {
      title: "Leo Messi Match Highlights & Golden Goals",
      description: "Exclusive moments and magic from the Argentine legend.",
      domain: "facebook.com",
    },
    sampleComments: [
      { author: "جماهير التانغو - رهط", text: "سحر ميسي مستمر في الملاعب العالمية!", time: "منذ ساعتين" },
    ],
  },
  // 10. مارك زوكربيرغ على فيسبوك
  {
    id: "vip-mark-zuckerberg-fb",
    platform: "facebook",
    authorName: "Mark Zuckerberg",
    authorHandle: "@zuck",
    authorRole: "مؤسس فيسبوك والرئيس التنفيذي لـ Meta",
    category: "celebrities",
    avatarUrl: makeAvatarSvgDataUri("MZ", "#1877f2", "#ffffff"),
    verified: "blue",
    publishedAgo: "منذ 4 ساعات",
    originalLang: "en",
    originalText:
      "Open source AI and next-generation smart glasses are transforming personal computing. Millions of communities connect every day across Facebook, WhatsApp and Instagram through intelligent tools.",
    translatedAr:
      "الذكاء الاصطناعي مفتوح المصدر ونظارات الجيل القادم الذكية تُحدث تحولاً جذرياً في الحوسبة الشخصية. ملايين المجتمعات تتواصل يومياً عبر فيسبوك وواتساب وإنستغرام عبر أدوات ذكية متطورة.",
    trendTag: "#TechTrends2026",
    likes: 98000,
    commentsCount: 8900,
    shares: 11200,
    views: "5.1M",
    sampleComments: [
      { author: "مبرمج من النقب", text: "النظارات الذكية وتقنيات الواقع المعزز ستكون بديل الهواتف قريباً.", time: "منذ 3 ساعات" },
    ],
  },
  // 11. بلدية رهط على فيسبوك
  {
    id: "vip-rahat-muni-fb",
    platform: "facebook",
    authorName: "بلدية رهط - الصفحة الرسمية",
    authorHandle: "@RahatMunicipality",
    authorRole: "مؤسسة رسمية · بلدية رهط",
    category: "local",
    avatarUrl: makeAvatarSvgDataUri("رهط", "#0e8f47", "#f2c94c"),
    verified: "gold",
    publishedAgo: "منذ 4 ساعات ونصف",
    originalLang: "ar",
    originalText:
      "أهلنا الكرام في مدينة رهط، نواصل على مدار الساعة تنفيذ مشاريع تعبيد الشوارع وتوسعة شبكة الإنارة الذكية في الأحياء الجديدة، إلى جانب تهيئة المرافق العامة لخدمة أهالينا. نرحب بجميع ملاحظاتكم وبلاغاتكم عبر مركز الخدمات البلدي 106.",
    translatedAr:
      "أهلنا الكرام في مدينة رهط، نواصل على مدار الساعة تنفيذ مشاريع تعبيد الشوارع وتوسعة شبكة الإنارة الذكية في الأحياء الجديدة، إلى جانب تهيئة المرافق العامة لخدمة أهالينا. نرحب بجميع ملاحظاتكم وبلاغاتكم عبر مركز الخدمات البلدي 106.",
    trendTag: "#بلدية_رهط",
    likes: 1280,
    commentsCount: 154,
    shares: 198,
    views: "27.2K",
    linkPreview: {
      title: "دليل بلدية رهط والخدمات البلدية ومركز 106",
      description: "طرق دفع الأرنونا والمياه، التواصل مع قسم الجباية، وأرقام البلاغات البلدية عبر منصة رهط بوست.",
      domain: "rahatpost.com",
    },
    sampleComments: [
      { author: "أبو سند الهزيل", text: "بارك الله في جهودكم، نأمل الإسراع في إنارة المدخل الشمالي للحي.", time: "منذ 3 ساعات" },
    ],
  },
  // 12. د. منصور عباس على فيسبوك
  {
    id: "vip-mansour-abbas-fb",
    platform: "facebook",
    authorName: "د. منصور عباس - Mansour Abbas",
    authorHandle: "@MansourAbbasOfficial",
    authorRole: "عضو كنيست · شؤون النقب",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("مع", "#0f766e", "#f2c94c"),
    verified: "blue",
    publishedAgo: "منذ 5 ساعات",
    originalLang: "ar",
    originalText:
      "قضايا النقب ورهط والقرى المعترف بها وغير المعترف بها تظل في صدارة أولوياتنا البرلمانية. نطالب بزيادة الميزانيات المخصصة للتعليم ومراكز الطوارئ والربط الكامل بشبكات المواصلات العامة.",
    translatedAr:
      "قضايا النقب ورهط والقرى المعترف بها وغير المعترف بها تظل في صدارة أولوياتنا البرلمانية. نطالب بزيادة الميزانيات المخصصة للتعليم ومراكز الطوارئ والربط الكامل بشبكات المواصلات العامة.",
    trendTag: "#أخبار_النقب",
    likes: 2240,
    commentsCount: 320,
    shares: 245,
    views: "49.5K",
    sampleComments: [
      { author: "سالم العطاونة", text: "الأهم متابعة التنفيذ الميداني للمشاريع.", time: "منذ 4 ساعات" },
    ],
  },
  // 13. محمد صلاح على فيسبوك
  {
    id: "vip-mohamed-salah-fb",
    platform: "facebook",
    authorName: "محمد صلاح - Mohamed Salah",
    authorHandle: "@momosalah",
    authorRole: "نجم كرة قدم عالمي · ليفربول",
    category: "sports",
    avatarUrl: makeAvatarSvgDataUri("MS", "#b91c1c", "#fde047"),
    verified: "blue",
    publishedAgo: "منذ 5 ساعات ونصف",
    originalLang: "en",
    originalText:
      "Great team spirit and another important step forward! Thanks to all fans for the incredible love and energy. 🔴⚽️",
    translatedAr:
      "روح جماعية رائعة وخطوة مهمة جديدة إلى الأمام! شكراً لجميع الجماهير على الدعم والطاقة التي لا توصف. 🔴⚽️",
    trendTag: "#ChampionsLeague",
    likes: 99800,
    commentsCount: 9240,
    shares: 12600,
    views: "4.1M",
    sampleComments: [
      { author: "عشاق الكرة في رهط", text: "فخر العرب دائماً!", time: "منذ 4 ساعات" },
    ],
  },
  // 14. يائير لبيد على إكس (تويتر)
  {
    id: "vip-yair-lapid-x",
    platform: "x",
    authorName: "Yair Lapid - יאיר לפיד",
    authorHandle: "@yairlapid",
    authorRole: "رئيس المعارضة · سياسي",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("YL", "#1d4ed8", "#ffffff"),
    verified: "gray",
    publishedAgo: "منذ 6 ساعات",
    originalLang: "he",
    originalText:
      "השקעה בתשתיות, בחינוך ובתעסוקה בנגב ובכלל החברה היא המפתח לצמיחה כלכלית אמיתית. עלינו לפעול בדחיפות להורדת יוקר המחיה ולמתן מענה לכלל האזרחים.",
    translatedAr:
      "إن الاستثمار في البنية التحتية والتعليم والتشغيل في النقب والمجتمع بأسره هو المفتاح لنمو اقتصادي حقيقي. يجب أن نعمل بشكل عاجل لخفض غلاء المعيشة وتوفير الحلول لجميع المواطنين.",
    trendTag: "#رهط_بوست",
    likes: 3520,
    commentsCount: 560,
    shares: 395,
    views: "115K",
    sampleComments: [
      { author: "محلل سياسي", text: "غلاء المعيشة والبنية التحتية قضايا تهم كل مواطن.", time: "منذ 4 ساعات" },
    ],
  },
];

export function SocialVipFeedAndTrendsSection({
  forceShowForAdminPreview = false,
  isFullPage = false,
}: {
  forceShowForAdminPreview?: boolean;
  isFullPage?: boolean;
}) {
  const st = useSiteSettings();
  const hubCfg = useMemo(() => parseSocialHubConfig(st.quickLinks), [st.quickLinks]);
  const customPosts = useMemo(() => parseCustomVipPosts(st.quickLinks), [st.quickLinks]);

  const [trendScope, setTrendScope] = useState<"local" | "global">(hubCfg.defaultTrendScope);
  const [showTrendsPanel, setShowTrendsPanel] = useState<boolean>(hubCfg.showTrendsDrawerOpen || isFullPage);
  const [selectedTrendTag, setSelectedTrendTag] = useState<string>("");
  const [platformFilter, setPlatformFilter] = useState<"all" | "x" | "facebook" | "politicians" | "celebrities" | "local">("all");
  const [translatedIds, setTranslatedIds] = useState<Record<string, boolean>>({});
  const [reactionsMap, setReactionsMap] = useState<Record<string, { emoji: string; count: number }>>({});
  const [sharedIds, setSharedIds] = useState<Record<string, number>>({});
  const [openCommentsId, setOpenCommentsId] = useState<string>("");
  const [expandedTextIds, setExpandedTextIds] = useState<Record<string, boolean>>({});
  const [userComments, setUserComments] = useState<Record<string, { author: string; text: string; time: string; avatar?: string }[]>>({});
  const [commentDraft, setCommentDraft] = useState<string>("");

  useEffect(() => {
    setTrendScope(hubCfg.defaultTrendScope);
  }, [hubCfg.defaultTrendScope]);

  if (!hubCfg.vipSectionEnabled && !forceShowForAdminPreview && !isFullPage) {
    return null;
  }

  const allPosts = [...customPosts, ...DEFAULT_VIP_POSTS];
  const filteredPosts = allPosts.filter((p) => {
    if (selectedTrendTag && p.trendTag !== selectedTrendTag) return false;
    if (platformFilter === "x") return p.platform === "x";
    if (platformFilter === "facebook") return p.platform === "facebook";
    if (platformFilter === "politicians") return p.category === "politicians";
    if (platformFilter === "celebrities") return p.category === "celebrities" || p.category === "sports";
    if (platformFilter === "local") return p.category === "local";
    return true;
  });

  const activeTrends = DEFAULT_TREND_TOPICS.filter((t) => t.scope === trendScope);

  const REACTION_CHOICES = [
    { label: "أعجبني", emoji: "👍" },
    { label: "أحببته", emoji: "❤️" },
    { label: "أدعمه", emoji: "🥰" },
    { label: "أضحكني", emoji: "😆" },
    { label: "أذهلني", emoji: "😮" },
    { label: "أحزنني", emoji: "😢" },
  ];

  return (
    <section
      id="social-vip-section"
      className="space-y-4"
      aria-labelledby="social-vip-heading"
    >
      {/* Clean Top Header Bar (No Stories or Prompt Box) */}
      <div className="stamp flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-paper p-3.5 shadow-2xs">
        <div className="flex items-center gap-2.5">
          <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#0f1419] via-[#1877f2] to-[#0f1419] text-base font-black text-white shadow-2xs">
            𝕏
          </span>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 id="social-vip-heading" className="text-base font-extrabold text-ink sm:text-lg">
                {tr("تواصل اجتماعي · المشاهير والسياسيون والتريند")}
              </h2>
              <span className="rounded-full bg-[#0f1419] px-2 py-0.5 text-[10px] font-black text-white">
                𝕏 Twitter + Facebook
              </span>
            </div>
            <p className="text-[11px] font-semibold text-muted">
              {tr("أحدث تغريدات ومنشورات مشاهير وسياسيي العالم ورهط والنقب مع زر الترجمة الفورية للعربية")}
            </p>
          </div>
        </div>

        {/* Global / Local Trend Toggle Switch */}
        <div className="flex items-center gap-1.5">
          <div className="inline-flex rounded-xl border border-line bg-surface p-0.5 text-xs font-extrabold">
            <button
              type="button"
              onClick={() => {
                setTrendScope("local");
                setShowTrendsPanel(true);
              }}
              className={`rounded-lg px-3 py-1.5 transition ${
                trendScope === "local"
                  ? "bg-primary text-[#111827] shadow-2xs"
                  : "text-muted hover:text-ink"
              }`}
            >
              📍 {tr("تريند محلي (رهط والنقب)")}
            </button>
            <button
              type="button"
              onClick={() => {
                setTrendScope("global");
                setShowTrendsPanel(true);
              }}
              className={`rounded-lg px-3 py-1.5 transition ${
                trendScope === "global"
                  ? "bg-[#0f1419] text-white shadow-2xs"
                  : "text-muted hover:text-ink"
              }`}
            >
              🌍 {tr("تريند عالمي")}
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Trends Drawer */}
      {showTrendsPanel ? (
        <div className="rounded-2xl border border-primary-deep/40 bg-gradient-to-br from-primary-soft/40 via-surface to-paper p-3.5 shadow-xs">
          <div className="mb-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🔥</span>
              <h3 className="text-xs font-extrabold text-ink">
                {trendScope === "local"
                  ? tr("أبرز مواضيع التريند في رهط والنقب والبلاد:")
                  : tr("أبرز مواضيع تريند إكس (تويتر) وفيسبوك العالمي:")}
              </h3>
            </div>
            {selectedTrendTag ? (
              <button
                type="button"
                onClick={() => setSelectedTrendTag("")}
                className="rounded-full bg-ink px-2.5 py-0.5 text-[10px] font-extrabold text-paper"
              >
                ✕ {tr("إلغاء فلتر")} {selectedTrendTag}
              </button>
            ) : null}
          </div>

          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {activeTrends.map((t) => {
              const active = selectedTrendTag === t.hashtag;
              return (
                <button
                  key={t.hashtag}
                  type="button"
                  onClick={() => setSelectedTrendTag(active ? "" : t.hashtag)}
                  className={`flex flex-col justify-between rounded-xl border p-2.5 text-start transition ${
                    active
                      ? "border-primary-deep bg-primary text-[#111827] shadow-xs"
                      : "border-line bg-paper hover:border-primary-deep"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-[9.5px] font-bold opacity-75">
                      <span>#{t.rank} · {trv(t.categoryLabel)}</span>
                      {t.isHot ? <span className="text-amber-600">🔥 رائج</span> : null}
                    </div>
                    <p dir="auto" className="mt-1 text-xs font-extrabold">
                      {t.hashtag}
                    </p>
                    <p className="mt-0.5 line-clamp-2 text-[10.5px] font-semibold opacity-80">
                      {trv(t.summaryAr)}
                    </p>
                  </div>
                  <p className="mt-2 text-[10px] font-extrabold text-primary-ink">
                    📊 {t.postsCount}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      ) : null}

      {/* Filter Tabs (الكل، تويتر إكس، فيسبوك، سياسيون، مشاهير، محلي) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {[
          { id: "all", label: "الكل 🌐" },
          { id: "x", label: "𝕏 تغريدات إكس (تويتر)" },
          { id: "politicians", label: "🏛️ سياسيون وقادة العالم" },
          { id: "celebrities", label: "⭐ مشاهير العالم والتقنية والرياضة" },
          { id: "facebook", label: "📘 منشورات فيسبوك" },
          { id: "local", label: "📍 شخصيات ومؤسسات رهط والنقب" },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setPlatformFilter(tab.id as typeof platformFilter)}
            className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-extrabold transition ${
              platformFilter === tab.id
                ? tab.id === "x"
                  ? "bg-[#0f1419] text-white shadow-xs"
                  : "bg-primary text-[#111827] shadow-xs"
                : "border border-line bg-paper text-ink hover:border-primary-deep"
            }`}
          >
            {tr(tab.label)}
          </button>
        ))}
      </div>

      {/* Posts Grid: Authentic 𝕏 (Twitter) and Facebook Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {filteredPosts.map((post) => {
          const isX = post.platform === "x";
          const isTranslated = Boolean(translatedIds[post.id]);
          const currentReaction = reactionsMap[post.id];
          const extraShares = sharedIds[post.id] ?? 0;
          const isCommentsOpen = openCommentsId === post.id;
          const isExpanded = Boolean(expandedTextIds[post.id]);
          const allComments = [
            ...post.sampleComments,
            ...(userComments[post.id] ?? []),
          ];

          const isLong = post.originalText.length > 180;
          const displayText =
            isLong && !isExpanded
              ? post.originalText.slice(0, 180) + "…"
              : post.originalText;

          return (
            <article
              key={post.id}
              className={`stamp overflow-hidden rounded-2xl border bg-paper shadow-2xs transition ${
                isX
                  ? "border-line hover:border-[#0f1419]"
                  : "border-line hover:border-[#1877F2]/60"
              }`}
            >
              {/* Header: Avatar + Name + Handle + Verified Badge + Platform Badge + 3-Dots */}
              <div className="p-4 pb-3">
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <div className="relative">
                      <img
                        src={post.avatarUrl}
                        alt={post.authorName}
                        width={46}
                        height={46}
                        className="size-11.5 shrink-0 rounded-full border border-line object-cover"
                      />
                      <span
                        className={`absolute -bottom-0.5 -end-0.5 grid size-4.5 place-items-center rounded-full text-[9px] font-black text-white ${
                          isX ? "bg-[#0f1419]" : "bg-[#1877F2]"
                        }`}
                      >
                        {isX ? "𝕏" : "f"}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <h3 className="truncate text-sm font-extrabold text-ink hover:underline">
                          {post.authorName}
                        </h3>

                        {/* Verified Badge: Blue, Gold or Gray (Official Government) */}
                        <span
                          title={post.verified === "gray" ? tr("حساب حكومي / سياسي رسمي") : tr("حساب موثّق")}
                          className={`inline-flex size-3.5 shrink-0 items-center justify-center rounded-full text-[9px] font-black text-white ${
                            post.verified === "gold"
                              ? "bg-amber-500"
                              : post.verified === "gray"
                                ? "bg-slate-500"
                                : "bg-[#1d9bf0]"
                          }`}
                        >
                          ✓
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-semibold text-muted">
                        <span dir="ltr" className="font-mono text-ink/75">{post.authorHandle}</span>
                        <span>·</span>
                        <span>{post.publishedAgo}</span>
                      </div>

                      <span className="mt-0.5 inline-block rounded-md bg-surface px-1.5 py-0.2 text-[10px] font-bold text-ink">
                        {trv(post.authorRole)}
                      </span>
                    </div>
                  </div>

                  {/* Platform Brand Pill */}
                  <span
                    className={`inline-flex shrink-0 items-center gap-1 rounded-xl px-2.5 py-1 text-[11px] font-extrabold text-white shadow-2xs ${
                      isX ? "bg-[#0f1419]" : "bg-[#1877F2]"
                    }`}
                  >
                    {isX ? "𝕏 إكس" : "فيسبوك"}
                  </span>
                </div>

                {/* Tweet / Post Content Body */}
                <div className="mt-3">
                  <p
                    dir="auto"
                    className="whitespace-pre-line text-sm font-semibold leading-relaxed text-ink"
                  >
                    {displayText}
                  </p>
                  {isLong ? (
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedTextIds((prev) => ({
                          ...prev,
                          [post.id]: !prev[post.id],
                        }))
                      }
                      className="mt-1 text-xs font-extrabold text-primary-ink hover:underline"
                    >
                      {isExpanded ? tr("عرض أقل") : tr("... عرض المزيد")}
                    </button>
                  ) : null}
                </div>

                {/* Trend Tag Pill + Translate Button */}
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line/60 pt-2.5">
                  {post.trendTag ? (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTrendTag(
                          selectedTrendTag === post.trendTag ? "" : post.trendTag || "",
                        );
                        setShowTrendsPanel(true);
                      }}
                      className="rounded-full bg-primary-soft px-2.5 py-0.5 text-xs font-extrabold text-primary-ink hover:brightness-95"
                    >
                      {post.trendTag}
                    </button>
                  ) : <span />}

                  {/* زر ترجمة التغريدة / المنشور للعربية */}
                  <button
                    type="button"
                    onClick={() =>
                      setTranslatedIds((prev) => ({
                        ...prev,
                        [post.id]: !prev[post.id],
                      }))
                    }
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-extrabold transition ${
                      isTranslated
                        ? "bg-primary text-[#111827] shadow-2xs"
                        : "bg-surface text-ink hover:bg-primary-soft"
                    }`}
                  >
                    <span>🌐</span>
                    <span>
                      {isTranslated
                        ? tr("إخفاء الترجمة")
                        : isX
                          ? tr("ترجمة التغريدة للعربية")
                          : tr("ترجمة المنشور للعربية")}
                    </span>
                  </button>
                </div>

                {/* Inline Arabic Translation Box */}
                {isTranslated ? (
                  <div className="mt-2.5 rounded-xl border border-primary-deep/50 bg-primary-soft/45 p-3 text-xs font-bold leading-relaxed text-ink">
                    <div className="mb-1 flex items-center justify-between text-[10px] font-extrabold text-primary-ink">
                      <span>✨ {tr("ترجمة فورية معتمدة · رهط بوست")}</span>
                      <span>
                        {post.originalLang === "he"
                          ? tr("من العبرية")
                          : post.originalLang === "tr"
                            ? tr("من التركية")
                            : post.originalLang === "en"
                              ? tr("من الإنجليزية")
                              : tr("عربي")}
                      </span>
                    </div>
                    <p dir="rtl">{post.translatedAr}</p>
                  </div>
                ) : null}

                {/* Optional Embedded Link Preview Card */}
                {post.linkPreview ? (
                  <a
                    href={post.linkPreview.url || (isX ? `https://x.com/${post.authorHandle.replace("@", "")}` : "#")}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 block overflow-hidden rounded-xl border border-line bg-surface/60 transition hover:bg-surface"
                  >
                    <div className="p-3">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-muted">
                        {post.linkPreview.domain}
                      </span>
                      <p className="line-clamp-1 text-xs font-extrabold text-ink">
                        {post.linkPreview.title}
                      </p>
                      <p className="mt-0.5 line-clamp-1 text-[11px] font-semibold text-muted">
                        {post.linkPreview.description}
                      </p>
                    </div>
                  </a>
                ) : null}
              </div>

              {/* Engagement Stats Bar */}
              <div className="flex items-center justify-between border-t border-line/80 px-4 py-2 text-xs font-bold text-muted">
                <div className="flex items-center gap-1.5">
                  {isX ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold">
                      <span className="text-rose-500">❤️</span>
                      <span className="font-extrabold text-ink">
                        {post.likes + (currentReaction ? 1 : 0)}
                      </span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <span className="flex items-center -space-x-1 rtl:space-x-reverse">
                        <span className="grid size-4.5 place-items-center rounded-full bg-[#1877F2] text-[10px] text-white">
                          👍
                        </span>
                        <span className="grid size-4.5 place-items-center rounded-full bg-rose-500 text-[10px] text-white">
                          ❤️
                        </span>
                      </span>
                      <span className="font-extrabold text-ink">
                        {post.likes + (currentReaction ? 1 : 0)}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-3 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setOpenCommentsId(isCommentsOpen ? "" : post.id)}
                    className="hover:underline"
                  >
                    {allComments.length} {isX ? tr("رد") : tr("تعليق")}
                  </button>
                  <span>·</span>
                  <span>{post.shares + extraShares} {isX ? tr("إعادة نشر") : tr("مشاركة")}</span>
                  <span>·</span>
                  <span>{post.views} {tr("مشاهدة")}</span>
                </div>
              </div>

              {/* Action Buttons Bar */}
              <div className="grid grid-cols-3 border-t border-line px-2 py-1 text-xs font-extrabold text-muted">
                {/* Like / Reaction Button */}
                <div className="group relative flex justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      setReactionsMap((prev) => {
                        if (prev[post.id]) {
                          const c = { ...prev };
                          delete c[post.id];
                          return c;
                        }
                        return { ...prev, [post.id]: { emoji: isX ? "❤️" : "👍", count: 1 } };
                      });
                    }}
                    className={`flex min-h-10 w-full items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface ${
                      currentReaction ? (isX ? "text-rose-500" : "text-[#1877F2]") : ""
                    }`}
                  >
                    <span>{currentReaction?.emoji || (isX ? "🤍" : "👍")}</span>
                    <span>{currentReaction ? (isX ? tr("أعجبك") : tr("أعجبك")) : (isX ? tr("إعجاب") : tr("أعجبني"))}</span>
                  </button>

                  {!isX ? (
                    <div className="pointer-events-none absolute bottom-full mb-1 flex scale-90 items-center gap-1 rounded-full border border-line bg-paper px-2 py-1 opacity-0 shadow-xl transition-all duration-150 group-hover:pointer-events-auto group-hover:scale-100 group-hover:opacity-100">
                      {REACTION_CHOICES.map((r) => (
                        <button
                          key={r.label}
                          type="button"
                          onClick={() =>
                            setReactionsMap((prev) => ({
                              ...prev,
                              [post.id]: { emoji: r.emoji, count: 1 },
                            }))
                          }
                          className="text-base transition hover:scale-130"
                          title={r.label}
                        >
                          {r.emoji}
                        </button>
                      ))}
                    </div>
                  ) : null}
                </div>

                {/* Comment / Reply Button */}
                <button
                  type="button"
                  onClick={() => setOpenCommentsId(isCommentsOpen ? "" : post.id)}
                  className={`flex min-h-10 items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface ${
                    isCommentsOpen ? "text-[#1877F2]" : ""
                  }`}
                >
                  <span>💬</span>
                  <span>{isX ? tr("رد") : tr("تعليق")}</span>
                </button>

                {/* Share / Repost Button */}
                <button
                  type="button"
                  onClick={() => {
                    setSharedIds((prev) => ({
                      ...prev,
                      [post.id]: (prev[post.id] ?? 0) + 1,
                    }));
                    if (typeof navigator !== "undefined" && navigator.share) {
                      void navigator
                        .share({
                          title: `${post.authorName} (${post.authorHandle})`,
                          text: post.translatedAr || post.originalText,
                          url: window.location.href,
                        })
                        .catch(() => {});
                    } else {
                      void navigator.clipboard?.writeText(window.location.href);
                      alert(tr("تم نسخ رابط التغريدة / المنشور بنجاح ✓"));
                    }
                  }}
                  className="flex min-h-10 items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface"
                >
                  <span>{isX ? "🔁" : "↗️"}</span>
                  <span>{isX ? tr("إعادة نشر") : tr("مشاركة")}</span>
                </button>
              </div>

              {/* Expandable Comments Drawer */}
              {isCommentsOpen ? (
                <div className="border-t border-line bg-surface/40 p-3.5">
                  <div className="space-y-2">
                    {allComments.map((c, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs">
                        <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary-soft text-[10px] font-extrabold text-primary-ink">
                          {c.author.slice(0, 1)}
                        </span>
                        <div className="flex-1 rounded-2xl bg-paper p-2.5 shadow-2xs">
                          <div className="flex items-center justify-between font-extrabold text-ink">
                            <span>{c.author}</span>
                            <span className="text-[10px] font-semibold text-muted">
                              {c.time}
                            </span>
                          </div>
                          <p className="mt-1 font-semibold text-ink/90">{c.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Comment Input Form */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const txt = commentDraft.trim();
                      if (!txt) return;
                      setUserComments((prev) => ({
                        ...prev,
                        [post.id]: [
                          ...(prev[post.id] ?? []),
                          { author: "زائر من رهط", text: txt, time: "الآن" },
                        ],
                      }));
                      setCommentDraft("");
                    }}
                    className="mt-3 flex gap-2"
                  >
                    <input
                      type="text"
                      value={commentDraft}
                      onChange={(e) => setCommentDraft(e.target.value)}
                      placeholder={isX ? tr("اكتب ردك على التغريدة…") : tr("اكتب تعليقك على المنشور…")}
                      className="field min-h-9 flex-1 rounded-full px-4 text-xs font-bold"
                    />
                    <button
                      type="submit"
                      className={`rounded-full px-4 py-1.5 text-xs font-extrabold text-white transition ${
                        isX ? "bg-[#0f1419] hover:bg-black" : "bg-[#1877F2] hover:bg-[#1d4ed8]"
                      }`}
                    >
                      {isX ? tr("رد") : tr("إرسال")}
                    </button>
                  </form>
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </section>
  );
}
