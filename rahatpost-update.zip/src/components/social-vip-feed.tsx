import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useSiteSettings } from "@/lib/site-settings/context";
import { tr, trv } from "@/lib/i18n/core";

export interface SocialVipPostItem {
  id: string;
  platform: "x" | "facebook";
  authorName: string;
  authorHandle: string;
  authorRole: string;
  category: "politicians" | "celebrities" | "sports" | "local";
  avatarUrl: string;
  verified: "blue" | "gold" | "gray";
  publishedAgo: string;
  originalLang: "he" | "en" | "ar";
  originalText: string;
  translatedAr: string;
  trendTag?: string;
  likes: number;
  commentsCount: number;
  shares: number;
  views: string;
  linkPreview?: {
    title: string;
    description: string;
    domain: string;
    imageUrl?: string;
    url?: string;
  };
  sampleComments: { author: string; text: string; time: string; avatar?: string }[];
}

export interface LocalTrackedFigure {
  id: string;
  name: string;
  fbUrl: string;
  role: string;
  category: "local" | "politicians" | "community";
  autoPublish: boolean;
  avatarUrl?: string;
  lastChecked?: string;
}

export interface TrendTopicItem {
  rank: number;
  scope: "global" | "local";
  hashtag: string;
  categoryLabel: string;
  postsCount: string;
  summaryAr: string;
  isHot?: boolean;
}

export interface SocialHubConfig {
  vipSectionEnabled: boolean; // Controls both /social page visibility and homepage widget
  defaultTrendScope: "local" | "global";
  showTrendsDrawerOpen: boolean;
  fbPageName: string;
  fbPageUrl: string;
  fbPageId: string;
  fbAutoPublish: boolean;
  tiktokHandle: string;
  telegramChannel: string;
}

function fromBase64UrlSafe(b64u: string): string {
  try {
    const b64 = b64u.replace(/-/g, "+").replace(/_/g, "/");
    const pad = b64.length % 4 === 0 ? "" : "=".repeat(4 - (b64.length % 4));
    const bin = typeof atob === "function" ? atob(b64 + pad) : "";
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch {
    return "";
  }
}

export function toBase64UrlSafe(str: string): string {
  try {
    const bytes = new TextEncoder().encode(str);
    let bin = "";
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  } catch {
    return "";
  }
}

export function parseSocialHubConfig(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): SocialHubConfig {
  const item = (quickLinks ?? []).find((q) => q.id === "socialhubcfg");
  let vipSectionEnabled = false;
  let defaultTrendScope: "local" | "global" = "local";
  let showTrendsDrawerOpen = false;
  let fbPageName = "رهط بوست - Rahat Post";
  let fbPageUrl = "https://www.facebook.com/rahatpost";
  let fbPageId = "";
  let fbAutoPublish = true;
  let tiktokHandle = "@rahatpost";
  let telegramChannel = "https://t.me/rahatpost";

  if (item) {
    const raw = `${item.title ?? ""}|${item.subtitle ?? ""}`;
    for (const part of raw.split("|")) {
      const p = part.trim();
      if (p.startsWith("vip:")) vipSectionEnabled = p.slice(4) === "1";
      else if (p.startsWith("scope:")) {
        const v = p.slice(6);
        if (v === "global" || v === "local") defaultTrendScope = v;
      } else if (p.startsWith("open:")) showTrendsDrawerOpen = p.slice(5) === "1";
      else if (p.startsWith("fbauto:")) fbAutoPublish = p.slice(7) !== "0";
      else if (p.startsWith("fbid:")) fbPageId = p.slice(5);
      else if (p.startsWith("tt:")) tiktokHandle = p.slice(3) || tiktokHandle;
    }
    if (item.url && item.url.startsWith("/__shcfg?")) {
      const jsonStr = fromBase64UrlSafe(item.url.slice(9));
      if (jsonStr) {
        try {
          const parsed = JSON.parse(jsonStr);
          if (typeof parsed.fbPageName === "string" && parsed.fbPageName) fbPageName = parsed.fbPageName;
          if (typeof parsed.fbPageUrl === "string" && parsed.fbPageUrl) fbPageUrl = parsed.fbPageUrl;
          if (typeof parsed.telegramChannel === "string" && parsed.telegramChannel)
            telegramChannel = parsed.telegramChannel;
        } catch {
          /* ignore */
        }
      }
    }
  }

  return {
    vipSectionEnabled,
    defaultTrendScope,
    showTrendsDrawerOpen,
    fbPageName,
    fbPageUrl,
    fbPageId,
    fbAutoPublish,
    tiktokHandle,
    telegramChannel,
  };
}

export function parseCustomVipPosts(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): SocialVipPostItem[] {
  const item = (quickLinks ?? []).find((q) => q.id === "socialvipcustom");
  if (!item?.url?.startsWith("/__svip?")) return [];
  const raw = fromBase64UrlSafe(item.url.slice(8) + (item.subtitle && item.subtitle !== "vip" ? item.subtitle : ""));
  if (!raw) return [];
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export const DEFAULT_LOCAL_FIGURES: LocalTrackedFigure[] = [
  {
    id: "fig-rahat-muni",
    name: "بلدية رهط - الصفحة الرسمية",
    fbUrl: "https://www.facebook.com/RahatMunicipality",
    role: "إدارة البلدية والمشاريع العامة",
    category: "local",
    autoPublish: true,
  },
  {
    id: "fig-matnas-rahat",
    name: "المركز الجماهيري رهط",
    fbUrl: "https://www.facebook.com/matnas.rahat",
    role: "فعاليات ثقافية وشبابية",
    category: "community",
    autoPublish: true,
  },
  {
    id: "fig-mansour-abbas",
    name: "د. منصور عباس - Mansour Abbas",
    fbUrl: "https://www.facebook.com/MansourAbbasOfficial",
    role: "عضو كنيست · شؤون النقب والمجتمع",
    category: "politicians",
    autoPublish: true,
  },
  {
    id: "fig-negev-sports",
    name: "نادي هبوعيل أبناء رهط",
    fbUrl: "https://www.facebook.com/rahat.football",
    role: "رياضة وكرة القدم المحلية",
    category: "local",
    autoPublish: true,
  },
];

export function parseLocalTrackedFigures(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
): LocalTrackedFigure[] {
  const item = (quickLinks ?? []).find((q) => q.id === "socialfigures");
  if (!item?.url?.startsWith("/__sfig?")) return DEFAULT_LOCAL_FIGURES;
  const raw = fromBase64UrlSafe(item.url.slice(8) + (item.subtitle && item.subtitle !== "fig" ? item.subtitle : ""));
  if (!raw) return DEFAULT_LOCAL_FIGURES;
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) && arr.length > 0 ? arr : DEFAULT_LOCAL_FIGURES;
  } catch {
    return DEFAULT_LOCAL_FIGURES;
  }
}

export function encodeLocalTrackedFigures(
  quickLinks: { id: string; title?: string; subtitle?: string; url?: string }[] | undefined,
  figures: LocalTrackedFigure[],
) {
  const encoded = toBase64UrlSafe(JSON.stringify(figures));
  const otherLinks = (quickLinks ?? []).filter((q) => q.id !== "socialfigures");
  return [
    ...otherLinks,
    {
      id: "socialfigures",
      title: `figures:${figures.length}`,
      subtitle: encoded.slice(180) || "fig",
      url: `/__sfig?${encoded.slice(0, 180)}`,
      emoji: "👥",
    },
  ];
}

export function makeAvatarSvgDataUri(initials: string, bgHex: string, accentHex = "#ffffff"): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${bgHex}"/><stop offset="100%" stop-color="#0f172a"/></linearGradient></defs><rect width="80" height="80" rx="40" fill="url(#g)"/><circle cx="40" cy="40" r="37" fill="none" stroke="${accentHex}" stroke-opacity="0.3" stroke-width="2"/><text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" fill="${accentHex}" font-family="system-ui, sans-serif" font-weight="800" font-size="26">${initials}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const DEFAULT_TREND_TOPICS: TrendTopicItem[] = [
  // Local Trends (رهط والنقب والبلاد)
  {
    rank: 1,
    scope: "local",
    hashtag: "#رهط_بوست",
    categoryLabel: "رهط والنقب · متصدر فيسبوك",
    postsCount: "32.8K تفاعل",
    summaryAr: "تغطية شاملة لأخبار ومشاريع مدينة رهط ومواعيد باصات غاليم والمباريات.",
    isHot: true,
  },
  {
    rank: 2,
    scope: "local",
    hashtag: "#أخبار_النقب",
    categoryLabel: "شؤون محلية وسياسة",
    postsCount: "24.1K منشور",
    summaryAr: "تفاعل واسع مع مشاريع البنية التحتية وتطوير الخدمات في بلدات النقب.",
    isHot: true,
  },
  {
    rank: 3,
    scope: "local",
    hashtag: "#بلدية_رهط",
    categoryLabel: "خدمات ومشاريع المدينة",
    postsCount: "18.3K منشور",
    summaryAr: "بيانات مشاريع الشوارع والمناوبات الطبية وتطوير المرافق العامة.",
    isHot: true,
  },
  {
    rank: 4,
    scope: "local",
    hashtag: "#هبوعيل_بئر_السبع",
    categoryLabel: "رياضة محلية · ليغات هعل",
    postsCount: "16.7K منشور",
    summaryAr: "تحليلات جماهير الكرة في رهط والجنوب لمباريات الدوري الممتاز.",
  },
  {
    rank: 5,
    scope: "local",
    hashtag: "#طقس_رهط_والنقب",
    categoryLabel: "أحوال جوية ومطر",
    postsCount: "12.4K منشور",
    summaryAr: "متابعة توقعات الطقس وهطول الأمطار في منطقة بئر السبع ورهط.",
  },
  // Global Trends (التريند العالمي)
  {
    rank: 1,
    scope: "global",
    hashtag: "#ChampionsLeague",
    categoryLabel: "تريند عالمي · رياضة",
    postsCount: "480K تغريدة ومنشور",
    summaryAr: "أصداء مواجهات دوري أبطال أوروبا وتألق كبار أندية العالم.",
    isHot: true,
  },
  {
    rank: 2,
    scope: "global",
    hashtag: "#AI_Innovation",
    categoryLabel: "تكنولوجيا وذكاء اصطناعي",
    postsCount: "310K منشور",
    summaryAr: "ثورة أدوات الفيديو والترجمة الفورية بالذكاء الاصطناعي في المنصات.",
    isHot: true,
  },
  {
    rank: 3,
    scope: "global",
    hashtag: "#MiddleEastNews",
    categoryLabel: "أخبار سياسية دولية",
    postsCount: "590K تفاعل",
    summaryAr: "متابعة المستجدات الإقليمية وتصريحات القادة والدبلوماسيين.",
    isHot: true,
  },
  {
    rank: 4,
    scope: "global",
    hashtag: "#TechTrends2026",
    categoryLabel: "ابتكارات واقتصاد رقمي",
    postsCount: "195K منشور",
    summaryAr: "تقنيات الهواتف الذكية وتطبيقات المستقبل والتجارة الإلكترونية.",
  },
];

export const DEFAULT_VIP_POSTS: SocialVipPostItem[] = [
  {
    id: "vip-1",
    platform: "facebook",
    authorName: "بلدية رهط - الصفحة الرسمية",
    authorHandle: "@RahatMunicipality",
    authorRole: "مؤسسة رسمية · بلدية رهط",
    category: "local",
    avatarUrl: makeAvatarSvgDataUri("رهط", "#0e8f47", "#f2c94c"),
    verified: "gold",
    publishedAgo: "منذ 25 دقيقة",
    originalLang: "ar",
    originalText:
      "أهلنا الكرام في مدينة رهط، نواصل على مدار الساعة تنفيذ مشاريع تعبيد الشوارع وتوسعة شبكة الإنارة الذكية في الأحياء الجديدة، إلى جانب تهيئة المرافق العامة لخدمة أهالينا. نرحب بجميع ملاحظاتكم وبلاغاتكم عبر مركز الخدمات البلدي 106.",
    translatedAr:
      "أهلنا الكرام في مدينة رهط، نواصل على مدار الساعة تنفيذ مشاريع تعبيد الشوارع وتوسعة شبكة الإنارة الذكية في الأحياء الجديدة، إلى جانب تهيئة المرافق العامة لخدمة أهالينا. نرحب بجميع ملاحظاتكم وبلاغاتكم عبر مركز الخدمات البلدي 106.",
    trendTag: "#بلدية_رهط",
    likes: 1240,
    commentsCount: 148,
    shares: 195,
    views: "26.4K",
    linkPreview: {
      title: "دليل بلدية رهط والخدمات البلدية ومركز 106",
      description: "طرق دفع الأرنونا والمياه، التواصل مع قسم الجباية، وأرقام البلاغات البلدية عبر منصة رهط بوست.",
      domain: "rahatpost.com",
    },
    sampleComments: [
      { author: "أبو سند الهزيل", text: "بارك الله في جهودكم، نأمل الإسراع في إنارة المدخل الشمالي للحي.", time: "منذ 15 د" },
      { author: "محمد القريناوي", text: "خطوة ممتازة لخدمة المدينة، كل التقدير.", time: "منذ 8 د" },
    ],
  },
  {
    id: "vip-2",
    platform: "facebook",
    authorName: "د. منصور عباس - Mansour Abbas",
    authorHandle: "@MansourAbbasOfficial",
    authorRole: "عضو كنيست · شؤون النقب",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("مع", "#0f766e", "#f2c94c"),
    verified: "blue",
    publishedAgo: "منذ ساعة",
    originalLang: "ar",
    originalText:
      "قضايا النقب ورهط والقرى المعترف بها وغير المعترف بها تظل في صدارة أولوياتنا البرلمانية. نطالب بزيادة الميزانيات المخصصة للتعليم ومراكز الطوارئ والربط الكامل بشبكات المواصلات العامة.",
    translatedAr:
      "قضايا النقب ورهط والقرى المعترف بها وغير المعترف بها تظل في صدارة أولوياتنا البرلمانية. نطالب بزيادة الميزانيات المخصصة للتعليم ومراكز الطوارئ والربط الكامل بشبكات المواصلات العامة.",
    trendTag: "#أخبار_النقب",
    likes: 2180,
    commentsCount: 312,
    shares: 240,
    views: "48.2K",
    linkPreview: {
      title: "متابعة أخبار ومطالب النقب والقرى العربية",
      description: "تغطية حية لأبرز الملفات التنموية والميزانيات على منصة رهط بوست.",
      domain: "rahatpost.com",
    },
    sampleComments: [
      { author: "سالم العطاونة", text: "الأهم متابعة التنفيذ الميداني للمشاريع.", time: "منذ 40 د" },
    ],
  },
  {
    id: "vip-3",
    platform: "x",
    authorName: "Yair Lapid - יאיר לפיד",
    authorHandle: "@yairlapid",
    authorRole: "رئيس المعارضة · سياسي",
    category: "politicians",
    avatarUrl: makeAvatarSvgDataUri("YL", "#1d4ed8", "#ffffff"),
    verified: "gray",
    publishedAgo: "منذ ساعتين",
    originalLang: "he",
    originalText:
      "השקעה בתשתיות, בחינוך ובתעסוקה בנגב ובכלל החברה היא המפתח לצמיחה כלכלית אמיתית. עלינו לפעול בדחיפות להורדת יוקר המחיה ולמתן מענה לכלל האזרחים.",
    translatedAr:
      "إن الاستثمار في البنية التحتية والتعليم والتشغيل في النقب والمجتمع بأسره هو المفتاح لنمو اقتصادي حقيقي. يجب أن نعمل بشكل عاجل لخفض غلاء المعيشة وتوفير الحلول لجميع المواطنين.",
    trendTag: "#رهط_بوست",
    likes: 3410,
    commentsCount: 540,
    shares: 388,
    views: "112K",
    sampleComments: [
      { author: "محلل اقتصادي", text: "ملف خفض غلاء المعيشة يتصدر اهتمامات الشارع هذا الشهر.", time: "منذ ساعة" },
    ],
  },
  {
    id: "vip-4",
    platform: "facebook",
    authorName: "المركز الجماهيري رهط",
    authorHandle: "@matnas.rahat",
    authorRole: "مؤسسة مجتمعية وثقافية",
    category: "local",
    avatarUrl: makeAvatarSvgDataUri("م ج", "#7c3aed", "#fde047"),
    verified: "blue",
    publishedAgo: "منذ 3 ساعات",
    originalLang: "ar",
    originalText:
      "يسرنا دعوة شباب وطلاب مدينة رهط للمشاركة في الأسبوع الثقافي ودورات البرمجة والذكاء الاصطناعي والتطوير الذاتي في قاعات المركز الجماهيري. التسجيل مفتوح مجاناً عبر الرابط المرفق.",
    translatedAr:
      "يسرنا دعوة شباب وطلاب مدينة رهط للمشاركة في الأسبوع الثقافي ودورات البرمجة والذكاء الاصطناعي والتطوير الذاتي في قاعات المركز الجماهيري. التسجيل مفتوح مجاناً عبر الرابط المرفق.",
    trendTag: "#رهط_بوست",
    likes: 890,
    commentsCount: 94,
    shares: 110,
    views: "19.8K",
    sampleComments: [
      { author: "خالد الزيادنة", text: "دورات مفيدة ومطلوبة لأبنائنا، كل التوفيق.", time: "منذ ساعتين" },
    ],
  },
  {
    id: "vip-5",
    platform: "x",
    authorName: "Fabrizio Romano",
    authorHandle: "@FabrizioRomano",
    authorRole: "صحفي رياضي عالمي",
    category: "sports",
    avatarUrl: makeAvatarSvgDataUri("FR", "#0284c7", "#ffffff"),
    verified: "blue",
    publishedAgo: "منذ 4 ساعات",
    originalLang: "en",
    originalText:
      "🚨⚽️ UEFA Champions League action continues with historic clashes! Top European clubs are already scouting the next generation of football talents. Here we go! 🔥",
    translatedAr:
      "🚨⚽️ إثارة دوري أبطال أوروبا تتواصل مع مواجهات تاريخية! الأندية الأوروبية الكبرى تراقب بالفعل الجيل القادم من مواهب كرة القدم العالمية. ترقبوا الإثارة! 🔥",
    trendTag: "#ChampionsLeague",
    likes: 54100,
    commentsCount: 3890,
    shares: 7200,
    views: "2.1M",
    sampleComments: [
      { author: "رياضة رهط", text: "مباريات الليلة لا تقبل القسمة على اثنين!", time: "منذ ساعتين" },
    ],
  },
  {
    id: "vip-6",
    platform: "facebook",
    authorName: "محمد صلاح - Mohamed Salah",
    authorHandle: "@momosalah",
    authorRole: "نجم كرة قدم عالمي",
    category: "sports",
    avatarUrl: makeAvatarSvgDataUri("MS", "#b91c1c", "#fde047"),
    verified: "blue",
    publishedAgo: "منذ 5 ساعات",
    originalLang: "en",
    originalText:
      "Great team spirit and another important step forward! Thanks to all fans for the incredible love and energy. 🔴⚽️",
    translatedAr:
      "روح جماعية رائعة وخطوة مهمة جديدة إلى الأمام! شكراً لجميع الجماهير على الدعم والطاقة التي لا توصف. 🔴⚽️",
    trendTag: "#ChampionsLeague",
    likes: 98400,
    commentsCount: 9120,
    shares: 12400,
    views: "3.9M",
    sampleComments: [
      { author: "عشاق الكرة في رهط", text: "فخر العرب دائماً!", time: "منذ 3 ساعات" },
    ],
  },
];

export function SocialStoriesCarousel({
  figures,
  onSelectStory,
}: {
  figures: LocalTrackedFigure[];
  onSelectStory: (name: string, role: string) => void;
}) {
  const stories = useMemo(() => {
    return [
      {
        id: "st-rp",
        name: "رهط بوست",
        sub: "موجز اليوم",
        avatar: "/icons/icon-192.png",
        ring: "from-amber-400 via-primary to-emerald-500",
        unread: true,
      },
      ...figures.map((f, i) => ({
        id: f.id,
        name: f.name.split("-")[0]?.trim() || f.name,
        sub: f.role.split("·")[0]?.trim() || "تحديث جديد",
        avatar: f.avatarUrl || makeAvatarSvgDataUri(f.name.slice(0, 2), i % 2 === 0 ? "#1877f2" : "#0e8f47"),
        ring: i % 2 === 0 ? "from-[#1877f2] via-sky-400 to-[#1877f2]" : "from-emerald-500 via-amber-400 to-primary",
        unread: true,
      })),
      {
        id: "st-weather",
        name: "طقس رهط",
        sub: "أمطار وغيوم",
        avatar: makeAvatarSvgDataUri("🌧️", "#0369a1", "#ffffff"),
        ring: "from-sky-400 to-blue-600",
        unread: false,
      },
    ];
  }, [figures]);

  return (
    <div className="rounded-2xl border border-line bg-paper p-3 shadow-2xs">
      <div className="mb-2 flex items-center justify-between px-1 text-xs font-extrabold text-ink">
        <span className="flex items-center gap-1.5">
          <span className="text-[#1877F2]">📱</span>
          <span>قصص وتحديثات مباشرة (Facebook Stories & Updates)</span>
        </span>
        <span className="text-[11px] font-semibold text-muted">اضغط للمشاهدة</span>
      </div>
      <div className="scroll-row flex gap-3 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {stories.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => onSelectStory(s.name, s.sub)}
            className="group flex w-18 shrink-0 flex-col items-center text-center transition hover:scale-105"
          >
            <div className={`relative p-0.5 rounded-full bg-gradient-to-tr ${s.ring} shadow-xs`}>
              <div className="rounded-full bg-paper p-0.5">
                <img
                  src={s.avatar}
                  alt={s.name}
                  width={48}
                  height={48}
                  className="size-12 rounded-full object-cover"
                />
              </div>
              <span className="absolute -bottom-0.5 -end-0.5 grid size-4 place-items-center rounded-full bg-[#1877F2] text-[9px] text-white ring-1 ring-paper">
                +
              </span>
            </div>
            <span className="mt-1.5 line-clamp-1 text-[11px] font-extrabold text-ink group-hover:text-[#1877F2]">
              {s.name}
            </span>
            <span className="line-clamp-1 text-[9.5px] font-semibold text-muted">{s.sub}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function SocialVipFeedAndTrendsSection({
  forceShowForAdminPreview = false,
  isFullPage = false,
}: {
  forceShowForAdminPreview?: boolean;
  isFullPage?: boolean;
}) {
  const st = useSiteSettings();
  const hubCfg = useMemo(() => parseSocialHubConfig(st.quickLinks), [st.quickLinks]);
  const customPosts = useMemo(() => parseCustomVipPosts(st.quickLinks), [st.quickLinks]);
  const localFigures = useMemo(() => parseLocalTrackedFigures(st.quickLinks), [st.quickLinks]);

  const [trendScope, setTrendScope] = useState<"local" | "global">(hubCfg.defaultTrendScope);
  const [showTrendsPanel, setShowTrendsPanel] = useState<boolean>(hubCfg.showTrendsDrawerOpen || isFullPage);
  const [selectedTrendTag, setSelectedTrendTag] = useState<string>("");
  const [platformFilter, setPlatformFilter] = useState<"all" | "facebook" | "x" | "local" | "politicians" | "celebrities">("all");
  const [translatedIds, setTranslatedIds] = useState<Record<string, boolean>>({});
  const [reactionsMap, setReactionsMap] = useState<Record<string, { emoji: string; count: number }>>({});
  const [sharedIds, setSharedIds] = useState<Record<string, number>>({});
  const [openCommentsId, setOpenCommentsId] = useState<string>("");
  const [expandedTextIds, setExpandedTextIds] = useState<Record<string, boolean>>({});
  const [userComments, setUserComments] = useState<Record<string, { author: string; text: string; time: string; avatar?: string }[]>>({});
  const [commentDraft, setCommentDraft] = useState<string>("");
  const [activeStoryViewer, setActiveStoryViewer] = useState<{ name: string; role: string } | null>(null);

  useEffect(() => {
    setTrendScope(hubCfg.defaultTrendScope);
  }, [hubCfg.defaultTrendScope]);

  // If hidden in admin settings and not in full page or admin preview, stay hidden!
  if (!hubCfg.vipSectionEnabled && !forceShowForAdminPreview && !isFullPage) {
    return null;
  }

  const allPosts = [...customPosts, ...DEFAULT_VIP_POSTS];
  const filteredPosts = allPosts.filter((p) => {
    if (selectedTrendTag && p.trendTag !== selectedTrendTag) return false;
    if (platformFilter === "facebook") return p.platform === "facebook";
    if (platformFilter === "x") return p.platform === "x";
    if (platformFilter === "local") return p.category === "local";
    if (platformFilter === "politicians") return p.category === "politicians" || p.category === "local";
    if (platformFilter === "celebrities") return p.category === "celebrities" || p.category === "sports";
    return true;
  });

  const activeTrends = DEFAULT_TREND_TOPICS.filter((t) => t.scope === trendScope);

  const REACTION_CHOICES = [
    { label: "أعجبني", emoji: "👍", color: "text-[#1877F2]" },
    { label: "أحببته", emoji: "❤️", color: "text-rose-500" },
    { label: "أدعمه", emoji: "🥰", color: "text-amber-500" },
    { label: "أضحكني", emoji: "😆", color: "text-amber-500" },
    { label: "أذهلني", emoji: "😮", color: "text-amber-500" },
    { label: "أحزنني", emoji: "😢", color: "text-amber-600" },
  ];

  return (
    <section
      id="social-vip-section"
      className="space-y-4"
      aria-labelledby="social-vip-heading"
    >
      {/* Top Facebook Stories / Reels Carousel */}
      <SocialStoriesCarousel
        figures={localFigures}
        onSelectStory={(name, role) => setActiveStoryViewer({ name, role })}
      />

      {/* Story Viewer Modal */}
      {activeStoryViewer ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="relative w-full max-w-sm overflow-hidden rounded-3xl border-2 border-primary bg-gradient-to-b from-[#1877f2] via-[#0f172a] to-black p-5 text-white shadow-2xl">
            <button
              type="button"
              onClick={() => setActiveStoryViewer(null)}
              className="absolute top-4 start-4 grid size-8 place-items-center rounded-full bg-white/20 text-white hover:bg-white/30"
            >
              ✕
            </button>
            <div className="mt-6 flex items-center gap-3">
              <span className="grid size-12 place-items-center rounded-full bg-white text-xl text-[#1877F2] font-black">
                {activeStoryViewer.name.slice(0, 1)}
              </span>
              <div>
                <p className="text-base font-extrabold">{activeStoryViewer.name}</p>
                <p className="text-xs text-white/70">{activeStoryViewer.role} · مباشر</p>
              </div>
            </div>
            <div className="my-6 rounded-2xl bg-white/10 p-4 text-center">
              <p className="text-sm font-bold leading-relaxed">
                متابعة حية لأحدث تصريحات ومنشورات {activeStoryViewer.name} عبر منصة وتطبيق رهط بوست.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveStoryViewer(null)}
              className="w-full rounded-2xl bg-primary py-2.5 text-xs font-extrabold text-[#111827]"
            >
              إغلاق القصة
            </button>
          </div>
        </div>
      ) : null}

      {/* Modern Facebook What's On Your Mind Card */}
      <div className="stamp rounded-2xl border border-line bg-paper p-3.5 shadow-2xs">
        <div className="flex items-center gap-3">
          <img
            src="/icons/icon-192.png"
            alt="Rahat Post"
            width={40}
            height={40}
            className="size-10 rounded-full border border-primary-deep/40 object-cover"
          />
          <Link
            to="/submit"
            className="flex-1 rounded-full border border-line bg-surface/75 px-4 py-2.5 text-start text-xs font-bold text-muted transition hover:border-primary-deep hover:bg-surface"
          >
            {tr("ماذا يدور في رهط والنقب اليوم؟ شارك خبراً أو تحديثاً مجاناً…")}
          </Link>
          <button
            type="button"
            onClick={() => setShowTrendsPanel((v) => !v)}
            className="inline-flex items-center gap-1.5 rounded-full bg-primary-soft px-3 py-2 text-xs font-extrabold text-primary-ink transition hover:brightness-95"
          >
            <span>🔥</span>
            <span className="hidden sm:inline">{tr("التريند")}</span>
          </button>
        </div>
      </div>

      {/* Header Bar with Title + Scope Toggle (محلي vs عالمي) */}
      <div className="stamp flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line bg-paper p-3.5 shadow-2xs">
        <div className="flex items-center gap-2.5">
          <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-[#1877F2] text-base font-black text-white shadow-2xs">
            f
          </span>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 id="social-vip-heading" className="text-base font-extrabold text-ink sm:text-lg">
                {tr("تواصل اجتماعي · المشاهير والسياسيون")}
              </h2>
              <span className="rounded-full bg-[#1877F2]/10 px-2 py-0.5 text-[10px] font-extrabold text-[#1877F2]">
                قالب فيسبوك تريند
              </span>
            </div>
            <p className="text-[11px] font-semibold text-muted">
              {tr("متابعة منشورات وتغريدات الشخصيات المحلية والعالمية مع الترجمة والتفاعل المباشر")}
            </p>
          </div>
        </div>

        {/* Global / Local Trend Toggle Switch */}
        <div className="flex items-center gap-1.5">
          <div className="inline-flex rounded-xl border border-line bg-surface p-0.5 text-xs font-extrabold">
            <button
              type="button"
              onClick={() => {
                setTrendScope("local");
                setShowTrendsPanel(true);
              }}
              className={`rounded-lg px-3 py-1.5 transition ${
                trendScope === "local"
                  ? "bg-[#1877F2] text-white shadow-2xs"
                  : "text-muted hover:text-ink"
              }`}
            >
              📍 {tr("تريند محلي (رهط والنقب)")}
            </button>
            <button
              type="button"
              onClick={() => {
                setTrendScope("global");
                setShowTrendsPanel(true);
              }}
              className={`rounded-lg px-3 py-1.5 transition ${
                trendScope === "global"
                  ? "bg-[#1877F2] text-white shadow-2xs"
                  : "text-muted hover:text-ink"
              }`}
            >
              🌍 {tr("تريند عالمي")}
            </button>
          </div>
        </div>
      </div>

      {/* Expandable Trends Drawer */}
      {showTrendsPanel ? (
        <div className="rounded-2xl border border-primary-deep/40 bg-gradient-to-br from-primary-soft/40 via-surface to-paper p-3.5 shadow-xs">
          <div className="mb-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🔥</span>
              <h3 className="text-xs font-extrabold text-ink">
                {trendScope === "local"
                  ? tr("أبرز مواضيع التريند في رهط والنقب والبلاد:")
                  : tr("أبرز مواضيع التريند العالمي المتداولة الآن:")}
              </h3>
            </div>
            {selectedTrendTag ? (
              <button
                type="button"
                onClick={() => setSelectedTrendTag("")}
                className="rounded-full bg-ink px-2.5 py-0.5 text-[10px] font-extrabold text-paper"
              >
                ✕ {tr("إلغاء فلتر")} {selectedTrendTag}
              </button>
            ) : null}
          </div>

          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
            {activeTrends.map((t) => {
              const active = selectedTrendTag === t.hashtag;
              return (
                <button
                  key={t.hashtag}
                  type="button"
                  onClick={() => setSelectedTrendTag(active ? "" : t.hashtag)}
                  className={`flex flex-col justify-between rounded-xl border p-2.5 text-start transition ${
                    active
                      ? "border-primary-deep bg-primary text-[#111827] shadow-xs"
                      : "border-line bg-paper hover:border-primary-deep"
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-[9.5px] font-bold opacity-75">
                      <span>#{t.rank} · {trv(t.categoryLabel)}</span>
                      {t.isHot ? <span className="text-amber-600">🔥 رائج</span> : null}
                    </div>
                    <p dir="auto" className="mt-1 text-xs font-extrabold">
                      {t.hashtag}
                    </p>
                    <p className="mt-0.5 line-clamp-2 text-[10.5px] font-semibold opacity-80">
                      {trv(t.summaryAr)}
                    </p>
                  </div>
                  <p className="mt-2 text-[10px] font-extrabold text-[#1877F2]">
                    📊 {t.postsCount}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      ) : null}

      {/* Filter Tabs (الكل، فيسبوك، إكس، شخصيات رهط، سياسيون، مشاهير) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {[
          { id: "all", label: "الكل 🌐" },
          { id: "facebook", label: "📘 فيسبوك (Facebook)" },
          { id: "local", label: "📍 شخصيات ومؤسسات رهط والنقب" },
          { id: "x", label: "𝕏 إكس (تويتر)" },
          { id: "politicians", label: "🏛️ سياسيون" },
          { id: "celebrities", label: "⭐ مشاهير ورياضة" },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setPlatformFilter(tab.id as typeof platformFilter)}
            className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-extrabold transition ${
              platformFilter === tab.id
                ? "bg-[#1877F2] text-white shadow-xs"
                : "border border-line bg-paper text-ink hover:border-primary-deep"
            }`}
          >
            {tr(tab.label)}
          </button>
        ))}
      </div>

      {/* Facebook Stream Feed Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        {filteredPosts.map((post) => {
          const isTranslated = Boolean(translatedIds[post.id]);
          const currentReaction = reactionsMap[post.id];
          const extraShares = sharedIds[post.id] ?? 0;
          const isCommentsOpen = openCommentsId === post.id;
          const isExpanded = Boolean(expandedTextIds[post.id]);
          const allComments = [
            ...post.sampleComments,
            ...(userComments[post.id] ?? []),
          ];

          const isLong = post.originalText.length > 170;
          const displayText =
            isLong && !isExpanded
              ? post.originalText.slice(0, 170) + "…"
              : post.originalText;

          return (
            <article
              key={post.id}
              className="stamp overflow-hidden rounded-2xl border border-line bg-paper shadow-2xs transition hover:border-[#1877F2]/60"
            >
              {/* Facebook Header: Avatar + Name + Verified Badge + Timestamp + Globe Privacy Icon + 3 Dots */}
              <div className="p-4 pb-3">
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <div className="relative">
                      <img
                        src={post.avatarUrl}
                        alt={post.authorName}
                        width={44}
                        height={44}
                        className="size-11 shrink-0 rounded-full border border-line object-cover"
                      />
                      <span className="absolute -bottom-0.5 -end-0.5 grid size-4 place-items-center rounded-full bg-[#1877F2] text-[9px] text-white">
                        {post.platform === "x" ? "𝕏" : "f"}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <h3 className="truncate text-sm font-extrabold text-ink hover:text-[#1877F2]">
                          {post.authorName}
                        </h3>
                        <span
                          title={tr("حساب موثّق")}
                          className={`inline-flex size-3.5 shrink-0 items-center justify-center rounded-full text-[9px] font-black text-white ${
                            post.verified === "gold"
                              ? "bg-amber-500"
                              : post.verified === "gray"
                                ? "bg-slate-500"
                                : "bg-[#1877F2]"
                          }`}
                        >
                          ✓
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-[11px] font-semibold text-muted">
                        <span>{post.publishedAgo}</span>
                        <span>·</span>
                        <span title={tr("منشور عام للجميع")}>🌐</span>
                        <span>·</span>
                        <span className="rounded-md bg-surface px-1.5 py-0.2 text-[10px] font-bold text-ink">
                          {trv(post.authorRole)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 3-dots Menu Button */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        void navigator.clipboard?.writeText(
                          `${post.authorName}: ${post.originalText}\nالمصدر: منصة رهط بوست https://rahatpost.com/social`,
                        );
                        alert(tr("تم نسخ رابط ورسالة المنشور بنجاح ✓"));
                      }}
                      className="grid size-8 place-items-center rounded-full text-muted hover:bg-surface hover:text-ink"
                      title={tr("خيارات ومشاركة المنشور")}
                    >
                      •••
                    </button>
                  </div>
                </div>

                {/* Facebook Post Body Text */}
                <div className="mt-3">
                  <p
                    dir="auto"
                    className="whitespace-pre-line text-sm font-semibold leading-relaxed text-ink"
                  >
                    {displayText}
                  </p>
                  {isLong ? (
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedTextIds((prev) => ({
                          ...prev,
                          [post.id]: !prev[post.id],
                        }))
                      }
                      className="mt-1 text-xs font-extrabold text-[#1877F2] hover:underline"
                    >
                      {isExpanded ? tr("عرض أقل") : tr("... عرض المزيد")}
                    </button>
                  ) : null}
                </div>

                {/* Trend Tag Pill + Translate Button */}
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line/60 pt-2.5">
                  {post.trendTag ? (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTrendTag(
                          selectedTrendTag === post.trendTag ? "" : post.trendTag || "",
                        );
                        setShowTrendsPanel(true);
                      }}
                      className="rounded-full bg-[#1877F2]/10 px-2.5 py-0.5 text-xs font-extrabold text-[#1877F2] hover:bg-[#1877F2]/20"
                    >
                      {post.trendTag}
                    </button>
                  ) : <span />}

                  <button
                    type="button"
                    onClick={() =>
                      setTranslatedIds((prev) => ({
                        ...prev,
                        [post.id]: !prev[post.id],
                      }))
                    }
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-extrabold transition ${
                      isTranslated
                        ? "bg-primary text-[#111827]"
                        : "bg-surface text-ink hover:bg-primary-soft"
                    }`}
                  >
                    <span>🌐</span>
                    <span>
                      {isTranslated ? tr("إخفاء الترجمة") : tr("ترجمة إلى العربية")}
                    </span>
                  </button>
                </div>

                {/* Inline Arabic Translation Box */}
                {isTranslated ? (
                  <div className="mt-2.5 rounded-xl border border-primary-deep/50 bg-primary-soft/45 p-3 text-xs font-bold leading-relaxed text-ink">
                    <div className="mb-1 flex items-center justify-between text-[10px] font-extrabold text-primary-ink">
                      <span>✨ {tr("ترجمة فورية معتمدة · رهط بوست")}</span>
                      <span>
                        {post.originalLang === "he"
                          ? tr("من العبرية")
                          : post.originalLang === "en"
                            ? tr("من الإنجليزية")
                            : tr("عربي")}
                      </span>
                    </div>
                    <p dir="rtl">{post.translatedAr}</p>
                  </div>
                ) : null}

                {/* Embedded Rich Link Preview Card (Facebook Style) */}
                {post.linkPreview ? (
                  <Link
                    to="/news"
                    className="mt-3 block overflow-hidden rounded-xl border border-line bg-surface/60 transition hover:bg-surface"
                  >
                    <div className="p-3">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-muted">
                        {post.linkPreview.domain}
                      </span>
                      <p className="line-clamp-1 text-xs font-extrabold text-ink">
                        {post.linkPreview.title}
                      </p>
                      <p className="mt-0.5 line-clamp-1 text-[11px] font-semibold text-muted">
                        {post.linkPreview.description}
                      </p>
                    </div>
                  </Link>
                ) : null}
              </div>

              {/* Engagement Stats Line (👍 ❤️ 1.4K · 98 تعليق · 42 مشاركة) */}
              <div className="flex items-center justify-between border-t border-line/80 px-4 py-2 text-xs font-bold text-muted">
                <div className="flex items-center gap-1.5">
                  <span className="flex items-center -space-x-1 rtl:space-x-reverse">
                    <span className="grid size-4.5 place-items-center rounded-full bg-[#1877F2] text-[10px] text-white">
                      👍
                    </span>
                    <span className="grid size-4.5 place-items-center rounded-full bg-rose-500 text-[10px] text-white">
                      ❤️
                    </span>
                    <span className="grid size-4.5 place-items-center rounded-full bg-amber-400 text-[10px] text-white">
                      🥰
                    </span>
                  </span>
                  <span className="font-extrabold text-ink">
                    {post.likes + (currentReaction ? 1 : 0)}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setOpenCommentsId(isCommentsOpen ? "" : post.id)}
                    className="hover:underline"
                  >
                    {allComments.length} {tr("تعليق")}
                  </button>
                  <span>·</span>
                  <span>{post.shares + extraShares} {tr("مشاركة")}</span>
                  <span>·</span>
                  <span>{post.views} {tr("مشاهدة")}</span>
                </div>
              </div>

              {/* Facebook Action Buttons Bar: [👍 أعجبني] [💬 تعليق] [↗️ مشاركة] */}
              <div className="grid grid-cols-3 border-t border-line px-2 py-1 text-xs font-extrabold text-muted">
                {/* Like / Reaction Button with Popover */}
                <div className="group relative flex justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      setReactionsMap((prev) => {
                        if (prev[post.id]) {
                          const c = { ...prev };
                          delete c[post.id];
                          return c;
                        }
                        return { ...prev, [post.id]: { emoji: "👍", count: 1 } };
                      });
                    }}
                    className={`flex min-h-10 w-full items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface ${
                      currentReaction ? "text-[#1877F2]" : ""
                    }`}
                  >
                    <span>{currentReaction?.emoji || "👍"}</span>
                    <span>{currentReaction ? tr("أعجبك") : tr("أعجبني")}</span>
                  </button>

                  {/* Reaction Selector Tooltip on Hover */}
                  <div className="pointer-events-none absolute bottom-full mb-1 flex scale-90 items-center gap-1 rounded-full border border-line bg-paper px-2 py-1 opacity-0 shadow-xl transition-all duration-150 group-hover:pointer-events-auto group-hover:scale-100 group-hover:opacity-100">
                    {REACTION_CHOICES.map((r) => (
                      <button
                        key={r.label}
                        type="button"
                        onClick={() =>
                          setReactionsMap((prev) => ({
                            ...prev,
                            [post.id]: { emoji: r.emoji, count: 1 },
                          }))
                        }
                        className="text-base transition hover:scale-130"
                        title={r.label}
                      >
                        {r.emoji}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Comment Button */}
                <button
                  type="button"
                  onClick={() => setOpenCommentsId(isCommentsOpen ? "" : post.id)}
                  className={`flex min-h-10 items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface ${
                    isCommentsOpen ? "text-[#1877F2]" : ""
                  }`}
                >
                  <span>💬</span>
                  <span>{tr("تعليق")}</span>
                </button>

                {/* Share Button */}
                <button
                  type="button"
                  onClick={() => {
                    setSharedIds((prev) => ({
                      ...prev,
                      [post.id]: (prev[post.id] ?? 0) + 1,
                    }));
                    if (typeof navigator !== "undefined" && navigator.share) {
                      void navigator
                        .share({
                          title: `${post.authorName} عبر رهط بوست`,
                          text: post.translatedAr || post.originalText,
                          url: window.location.href,
                        })
                        .catch(() => {});
                    } else {
                      void navigator.clipboard?.writeText(window.location.href);
                      alert(tr("تم نسخ رابط المنشور للمشاركة ✓"));
                    }
                  }}
                  className="flex min-h-10 items-center justify-center gap-1.5 rounded-xl transition hover:bg-surface"
                >
                  <span>↗️</span>
                  <span>{tr("مشاركة")}</span>
                </button>
              </div>

              {/* Expandable Comments Drawer */}
              {isCommentsOpen ? (
                <div className="border-t border-line bg-surface/40 p-3.5">
                  <div className="space-y-2">
                    {allComments.map((c, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs">
                        <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary-soft text-[10px] font-extrabold text-primary-ink">
                          {c.author.slice(0, 1)}
                        </span>
                        <div className="flex-1 rounded-2xl bg-paper p-2.5 shadow-2xs">
                          <div className="flex items-center justify-between font-extrabold text-ink">
                            <span>{c.author}</span>
                            <span className="text-[10px] font-semibold text-muted">
                              {c.time}
                            </span>
                          </div>
                          <p className="mt-1 font-semibold text-ink/90">{c.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Comment Input Form */}
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const txt = commentDraft.trim();
                      if (!txt) return;
                      setUserComments((prev) => ({
                        ...prev,
                        [post.id]: [
                          ...(prev[post.id] ?? []),
                          { author: "زائر من رهط", text: txt, time: "الآن" },
                        ],
                      }));
                      setCommentDraft("");
                    }}
                    className="mt-3 flex gap-2"
                  >
                    <input
                      type="text"
                      value={commentDraft}
                      onChange={(e) => setCommentDraft(e.target.value)}
                      placeholder={tr("اكتب تعليقك على المنشور…")}
                      className="field min-h-9 flex-1 rounded-full px-4 text-xs font-bold"
                    />
                    <button
                      type="submit"
                      className="rounded-full bg-[#1877F2] px-4 py-1.5 text-xs font-extrabold text-white transition hover:bg-[#1d4ed8]"
                    >
                      {tr("إرسال")}
                    </button>
                  </form>
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </section>
  );
}
