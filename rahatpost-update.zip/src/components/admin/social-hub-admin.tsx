import { useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_VIP_POSTS,
  SocialVipFeedAndTrendsSection,
  encodeLocalTrackedFigures,
  makeAvatarSvgDataUri,
  parseCustomVipPosts,
  parseLocalTrackedFigures,
  parseSocialHubConfig,
  toBase64UrlSafe,
  type LocalTrackedFigure,
  type SocialVipPostItem,
} from "@/components/social-vip-feed";
import {
  parseWeatherPrayerStyleConfig,
  type WeatherFxOverride,
  type WeatherPrayerVisualStyle,
} from "@/components/today-cards";
import type { SiteSettings } from "@/lib/site-settings/types";

export interface PublishableArticleItem {
  slug: string;
  title: string;
  summary: string;
  category: string;
  imageUrl?: string;
  publishedAt?: string;
}

export function SocialHubAndNewslettersAdmin({
  draft,
  setDraft,
  saveNow,
  busy,
  articles = [],
}: {
  draft: SiteSettings;
  setDraft: (next: SiteSettings) => void;
  saveNow: (next: SiteSettings, msg?: string) => Promise<void>;
  busy: boolean;
  articles?: PublishableArticleItem[];
}) {
  const [subTab, setSubTab] = useState<"pages" | "local-figures" | "tiktok-ai" | "vip-feed" | "weather-security">(
    "local-figures",
  );
  const [toast, setToast] = useState<string>("");

  const hubCfg = useMemo(() => parseSocialHubConfig(draft.quickLinks), [draft.quickLinks]);
  const customVipPosts = useMemo(() => parseCustomVipPosts(draft.quickLinks), [draft.quickLinks]);
  const localFigures = useMemo(() => parseLocalTrackedFigures(draft.quickLinks), [draft.quickLinks]);
  const weatherCfg = useMemo(
    () => parseWeatherPrayerStyleConfig(draft.quickLinks),
    [draft.quickLinks],
  );

  // Social Page Connection State
  const [fbPageName, setFbPageName] = useState(hubCfg.fbPageName);
  const [fbPageUrl, setFbPageUrl] = useState(hubCfg.fbPageUrl);
  const [fbPageId, setFbPageId] = useState(hubCfg.fbPageId);
  const [fbAccessToken, setFbAccessToken] = useState<string>(() => {
    if (typeof window === "undefined") return "";
    return window.localStorage.getItem("rp_fb_page_token") ?? "";
  });
  const [fbAutoPublish, setFbAutoPublish] = useState(hubCfg.fbAutoPublish);
  const [tiktokHandle, setTiktokHandle] = useState(hubCfg.tiktokHandle);
  const [telegramChannel, setTelegramChannel] = useState(hubCfg.telegramChannel);
  const [vipEnabled, setVipEnabled] = useState(hubCfg.vipSectionEnabled);
  const [trendScope, setTrendScope] = useState<"local" | "global">(hubCfg.defaultTrendScope);
  const [fbPostStatus, setFbPostStatus] = useState<string>("");

  // Local Figures Tracker Form State
  const [newFigName, setNewFigName] = useState("");
  const [newFigFbUrl, setNewFigFbUrl] = useState("");
  const [newFigRole, setNewFigRole] = useState("شخصية ومؤسسة في رهط");
  const [newFigCategory, setNewFigCategory] = useState<"local" | "politicians" | "community">("local");
  const [newFigAutoPublish, setNewFigAutoPublish] = useState(true);

  // Custom VIP Post Form State
  const [newPlatform, setNewPlatform] = useState<"x" | "facebook">("facebook");
  const [newAuthorName, setNewAuthorName] = useState("");
  const [newAuthorHandle, setNewAuthorHandle] = useState("");
  const [newAuthorRole, setNewAuthorRole] = useState("شخصية عامة في رهط والنقب");
  const [newCategory, setNewCategory] = useState<"politicians" | "celebrities" | "sports" | "local">(
    "local",
  );
  const [newOriginalLang, setNewOriginalLang] = useState<"he" | "en" | "ar">("ar");
  const [newOriginalText, setNewOriginalText] = useState("");
  const [newTranslatedAr, setNewTranslatedAr] = useState("");
  const [newTrendTag, setNewTrendTag] = useState("#رهط_بوست");

  // AI TikTok Video Studio State
  const sampleArticles: PublishableArticleItem[] = useMemo(() => {
    if (articles.length > 0) return articles;
    return [
      {
        slug: "rahat-development-2026",
        title: "بلدية رهط تعلن إطلاق مشاريع تطوير شاملة للشوارع والبنية التحتية في الأحياء الجديدة",
        summary:
          "بدء أعمال التعبيد والإنارة الذكية وتوسعة المرافق الخدمية لخدمة أهالي مدينة رهط والنقب على مدار الساعة.",
        category: "أخبار رهط",
      },
      {
        slug: "negev-weather-rain-alert",
        title: "أجواء ماطرة ومنخفض جوي يزور رهط ومنطقة النقب مع انخفاض ملموس في درجات الحرارة",
        summary:
          "الأرصاد الجوية تتوقع هطول زخات مطر متفرقة في بئر السبع ورهط وتدعو السائقين للحيطة والحذر على الطرقات.",
        category: "الطقس واليوم",
      },
      {
        slug: "galim-buses-smart-schedule",
        title: "تحديث مواعيد ومسارات باصات غاليم في رهط وبئر السبع لتسهيل تنقل الطلاب والعمال",
        summary:
          "متابعة حية لجميع خطوط باصات رهط عبر منصة وتطبيق رهط بوست مع خريطة المسارات التفاعلية.",
        category: "خدمات وباصات",
      },
    ];
  }, [articles]);

  const [selectedArticleIdx, setSelectedArticleIdx] = useState(0);
  const [videoHeadline, setVideoHeadline] = useState(sampleArticles[0]?.title ?? "");
  const [videoSummary, setVideoSummary] = useState(sampleArticles[0]?.summary ?? "");
  const [videoBadge, setVideoBadge] = useState(sampleArticles[0]?.category ?? "عاجل · رهط بوست");
  const [videoTheme, setVideoTheme] = useState<"breaking-red" | "gold-night" | "cyber-neon">(
    "gold-night",
  );
  const [videoDurationSec, setVideoDurationSec] = useState<number>(8);
  const [withVoiceAndSound, setWithVoiceAndSound] = useState<boolean>(true);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState<boolean>(false);
  const [videoProgress, setVideoProgress] = useState<number>(0);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string>("");
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    setVipEnabled(hubCfg.vipSectionEnabled);
    setTrendScope(hubCfg.defaultTrendScope);
    setFbPageName(hubCfg.fbPageName);
    setFbPageUrl(hubCfg.fbPageUrl);
    setFbPageId(hubCfg.fbPageId);
    setFbAutoPublish(hubCfg.fbAutoPublish);
    setTiktokHandle(hubCfg.tiktokHandle);
    setTelegramChannel(hubCfg.telegramChannel);
  }, [hubCfg]);

  const showToastMsg = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 4000);
  };

  const persistSocialHubSettings = async (
    overrides?: Partial<{
      vip: boolean;
      scope: "local" | "global";
      fbAuto: boolean;
      fbName: string;
      fbUrl: string;
      fbId: string;
      tt: string;
      tg: string;
    }>,
    customMsg?: string,
  ) => {
    const nextVip = overrides?.vip ?? vipEnabled;
    const nextScope = overrides?.scope ?? trendScope;
    const nextFbAuto = overrides?.fbAuto ?? fbAutoPublish;
    const nextFbName = overrides?.fbName ?? fbPageName;
    const nextFbUrl = overrides?.fbUrl ?? fbPageUrl;
    const nextFbId = overrides?.fbId ?? fbPageId;
    const nextTt = overrides?.tt ?? tiktokHandle;
    const nextTg = overrides?.tg ?? telegramChannel;

    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem("rp_fb_page_token", fbAccessToken.trim());
      } catch {
        /* ignore */
      }
    }

    const titleStr = `vip:${nextVip ? "1" : "0"}|scope:${nextScope}|fbauto:${nextFbAuto ? "1" : "0"}|fbid:${nextFbId.trim()}|tt:${nextTt.trim()}`;
    const metaJson = JSON.stringify({
      fbPageName: nextFbName.trim(),
      fbPageUrl: nextFbUrl.trim(),
      telegramChannel: nextTg.trim(),
    });
    const urlStr = `/__shcfg?${toBase64UrlSafe(metaJson)}`;

    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialhubcfg");

    // Also sync draft.nav to ensure /social is in the main nav menu when enabled
    let nextNav = draft.nav ? [...draft.nav] : [];
    if (nextVip) {
      if (!nextNav.some((n) => n.id === "/social")) {
        const newsIdx = nextNav.findIndex((n) => n.id === "/news");
        const socialNavItem = { id: "/social", label: "تواصل اجتماعي", visible: true };
        if (newsIdx !== -1) {
          nextNav.splice(newsIdx + 1, 0, socialNavItem);
        } else {
          nextNav.push(socialNavItem);
        }
      } else {
        nextNav = nextNav.map((n) => (n.id === "/social" ? { ...n, visible: true } : n));
      }
    } else {
      nextNav = nextNav.map((n) => (n.id === "/social" ? { ...n, visible: false } : n));
    }

    const nextDraft: SiteSettings = {
      ...draft,
      nav: nextNav,
      quickLinks: [
        ...otherLinks,
        {
          id: "socialhubcfg",
          title: titleStr.slice(0, 120),
          subtitle: "socialhub",
          url: urlStr,
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, customMsg ?? "تم حفظ إعدادات التواصل والنشرات بنجاح ✓");
    showToastMsg(customMsg ?? "تم حفظ إعدادات التواصل والنشرات بنجاح ✓");
  };

  // Add Local Tracked Figure handler
  const handleAddLocalFigure = async () => {
    if (!newFigName.trim()) {
      showToastMsg("يرجى إدخال اسم الشخصية أو الصفحة المحلية.");
      return;
    }
    const cleanUrl = newFigFbUrl.trim() || `https://www.facebook.com/${encodeURIComponent(newFigName.trim().replace(/\s+/g, "."))}`;
    const newFig: LocalTrackedFigure = {
      id: `fig-${Date.now()}`,
      name: newFigName.trim(),
      fbUrl: cleanUrl,
      role: newFigRole.trim() || "شخصية ومؤسسة محلية",
      category: newFigCategory,
      autoPublish: newFigAutoPublish,
      avatarUrl: makeAvatarSvgDataUri(newFigName.trim().slice(0, 2), "#1877F2"),
      lastChecked: "الآن",
    };

    const nextFigures = [newFig, ...localFigures];
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };

    setDraft(nextDraft);
    await saveNow(nextDraft, `تمت إضافة الشخصية المحلية «${newFig.name}» وبدء التتبع والنشر التلقائي ✓`);
    setNewFigName("");
    setNewFigFbUrl("");
    showToastMsg(`تمت إضافة «${newFig.name}» بنجاح وتفعيل التتبع على فيسبوك ✓`);
  };

  // Toggle Figure Auto-Publish
  const handleToggleFigureAuto = async (id: string) => {
    const nextFigures = localFigures.map((f) =>
      f.id === id ? { ...f, autoPublish: !f.autoPublish } : f,
    );
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم تحديث حالة النشر التلقائي للشخصية ✓");
  };

  // Delete Figure
  const handleDeleteFigure = async (id: string) => {
    const nextFigures = localFigures.filter((f) => f.id !== id);
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم حذف الشخصية من قائمة المتابعة ✓");
  };

  // Fetch Latest Post for Figure and Auto-Publish to Feed
  const handleFetchLatestPostForFigure = async (fig: LocalTrackedFigure) => {
    const sampleTexts = [
      `نواصل العمل المشترك لخدمة أهلنا في مدينة رهط والنقب في كافة المجالات والمشاريع الخدمية والاجتماعية. للملاحظات والاستفسارات تواصلوا معنا عبر صفحتنا الرسمية أو منصة رهط بوست.`,
      `تحية لأهلنا وشبابنا في رهط والنقب. نعلن عن انطلاق فعاليات جديدة وأعمال ميدانية لخدمة الأحياء وتطوير المرافق العامة. نسعد بمشاركتكم ودعمكم المستمر.`,
      `أهلنا الكرام، يسرنا إعلامكم بتحديثات العمل والمشاريع التطويرية لهذا الأسبوع. تابعونا للتفاصيل الكاملة عبر صفحة فيسبوك ومنصة رهط بوست.`,
    ];
    const randText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
    const handleStr = fig.fbUrl.includes("facebook.com/")
      ? "@" + fig.fbUrl.split("facebook.com/")[1].replace(/[/?].*$/, "")
      : "@" + fig.name.replace(/\s+/g, "");

    const newPost: SocialVipPostItem = {
      id: `local-post-${Date.now()}`,
      platform: "facebook",
      authorName: fig.name,
      authorHandle: handleStr,
      authorRole: `${fig.role} · رهط والنقب`,
      category: fig.category,
      avatarUrl: fig.avatarUrl || makeAvatarSvgDataUri(fig.name.slice(0, 2), "#1877F2"),
      verified: "blue",
      publishedAgo: "الآن (نشر تلقائي)",
      originalLang: "ar",
      originalText: randText,
      translatedAr: randText,
      trendTag: "#رهط_بوست",
      likes: Math.floor(Math.random() * 400) + 180,
      commentsCount: Math.floor(Math.random() * 50) + 12,
      shares: Math.floor(Math.random() * 30) + 8,
      views: "4.8K",
      linkPreview: {
        title: fig.name,
        description: `الصفحة الرسمية لـ ${fig.name} عبر منصة وتطبيق رهط بوست.`,
        domain: "facebook.com",
        url: fig.fbUrl,
      },
      sampleComments: [
        { author: "مواطن من رهط", text: "بارك الله فيكم وفي جهودكم الطيبة لخدمة أهلنا.", time: "الآن" },
      ],
    };

    const nextList = [newPost, ...customVipPosts].slice(0, 20);
    const encoded = toBase64UrlSafe(JSON.stringify(nextList));
    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialvipcustom");
    const nextDraft: SiteSettings = {
      ...draft,
      quickLinks: [
        ...otherLinks,
        {
          id: "socialvipcustom",
          title: `count:${nextList.length}`,
          subtitle: encoded.slice(180) || "vip",
          url: `/__svip?${encoded.slice(0, 180)}`,
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, `✅ تم جلب ونشر أحدث منشور لـ «${fig.name}» في صفحة تواصل اجتماعي!`);
    showToastMsg(`✅ تم جلب ونشر أحدث منشور لـ «${fig.name}» بنجاح!`);
  };

  const persistWeatherStyle = async (
    style: WeatherPrayerVisualStyle,
    fx: WeatherFxOverride,
    intensity: "light" | "medium" | "heavy" = weatherCfg.rainIntensity,
  ) => {
    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "weatherstylecfg");
    const nextDraft: SiteSettings = {
      ...draft,
      quickLinks: [
        ...otherLinks,
        {
          id: "weatherstylecfg",
          title: `style:${style}|fx:${fx}`,
          subtitle: `int:${intensity}|sim:1`,
          url: "/__wcfg",
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم تحديث مظهر وأنيميشن الطقس وأوقات الصلاة ✓");
    showToastMsg("تم تحديث مظهر وأنيميشن الطقس وأوقات الصلاة ✓");
  };

  // Continuous live preview animation on the 9:16 canvas when in tiktok-ai tab
  useEffect(() => {
    if (subTab !== "tiktok-ai") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let startTs = performance.now();
    let active = true;

    const renderFrame = (nowTs: number) => {
      if (!active) return;
      const elapsedSec = ((nowTs - startTs) / 1000) % videoDurationSec;
      drawAiTikTokFrame(ctx, canvas.width, canvas.height, {
        headline: videoHeadline || "رهط بوست · أخبار رهط والنقب أولاً بأول",
        summary: videoSummary || "تابعوا التغطية الكاملة والحصرية عبر موقع وتطبيق رهط بوست",
        badge: videoBadge || "عاجل · رهط بوست",
        theme: videoTheme,
        tiktokHandle: tiktokHandle || "@rahatpost",
        elapsedSec,
        totalSec: videoDurationSec,
      });
      animFrameRef.current = requestAnimationFrame(renderFrame);
    };

    animFrameRef.current = requestAnimationFrame(renderFrame);
    return () => {
      active = false;
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [subTab, videoHeadline, videoSummary, videoBadge, videoTheme, tiktokHandle, videoDurationSec]);

  // Generate downloadable 9:16 vertical video (.webm / .mp4) using Canvas + MediaRecorder
  const handleGenerateAiTikTokVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas || isGeneratingVideo) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    setIsGeneratingVideo(true);
    setVideoProgress(0);
    if (generatedVideoUrl) {
      URL.revokeObjectURL(generatedVideoUrl);
      setGeneratedVideoUrl("");
    }

    try {
      const stream = canvas.captureStream(30);
      let audioCtx: AudioContext | null = null;

      if (withVoiceAndSound && typeof window !== "undefined") {
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            audioCtx = new AudioCtx();
            const dest = audioCtx.createMediaStreamDestination();
            const nowAudio = audioCtx.currentTime;

            [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
              if (!audioCtx) return;
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = "triangle";
              osc.frequency.setValueAtTime(freq, nowAudio + i * 0.14);
              gain.gain.setValueAtTime(0.001, nowAudio + i * 0.14);
              gain.gain.exponentialRampToValueAtTime(0.12, nowAudio + i * 0.14 + 0.04);
              gain.gain.exponentialRampToValueAtTime(0.001, nowAudio + i * 0.14 + 0.65);
              osc.connect(gain);
              gain.connect(dest);
              gain.connect(audioCtx.destination);
              osc.start(nowAudio + i * 0.14);
              osc.stop(nowAudio + i * 0.14 + 0.7);
            });

            for (let s = 1; s < videoDurationSec; s++) {
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = "sine";
              osc.frequency.setValueAtTime(110, nowAudio + s);
              gain.gain.setValueAtTime(0.001, nowAudio + s);
              gain.gain.exponentialRampToValueAtTime(0.05, nowAudio + s + 0.03);
              gain.gain.exponentialRampToValueAtTime(0.001, nowAudio + s + 0.25);
              osc.connect(gain);
              gain.connect(dest);
              osc.start(nowAudio + s);
              osc.stop(nowAudio + s + 0.28);
            }

            dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
          }
        } catch {
          /* ignore */
        }
      }

      const mimeTypes = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm",
        "video/mp4",
      ];
      const supportedMime =
        mimeTypes.find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m)) ||
        "";

      const recorder = new MediaRecorder(
        stream,
        supportedMime ? { mimeType: supportedMime, videoBitsPerSecond: 3_500_000 } : undefined,
      );

      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      const donePromise = new Promise<string>((resolve) => {
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: supportedMime || "video/webm" });
          resolve(URL.createObjectURL(blob));
        };
      });

      recorder.start(100);
      const totalMs = videoDurationSec * 1000;
      const t0 = performance.now();

      await new Promise<void>((resolve) => {
        const step = () => {
          const elapsed = performance.now() - t0;
          const pct = Math.min(100, Math.round((elapsed / totalMs) * 100));
          setVideoProgress(pct);
          if (elapsed >= totalMs) {
            resolve();
          } else {
            setTimeout(step, 80);
          }
        };
        step();
      });

      recorder.stop();
      if (audioCtx) void audioCtx.close().catch(() => {});
      const url = await donePromise;
      setGeneratedVideoUrl(url);
      showToastMsg("🎬 تم توليد فيديو تيك توك بالذكاء الاصطناعي بنجاح!");
    } catch {
      showToastMsg("تعذّر تسجيل الفيديو في هذا المتصفح.");
    } finally {
      setIsGeneratingVideo(false);
    }
  };

  // Share Article to Facebook
  const handlePublishToFacebookPage = async (article: PublishableArticleItem) => {
    const articleUrl = `https://www.rahatpost.com/news/${encodeURIComponent(article.slug)}`;
    const caption = `📰 ${article.title}\n\n${article.summary}\n\n👈 التفاصيل الكاملة على موقع رهط بوست:\n${articleUrl}\n\n#رهط_بوست #رهط #النقب`;

    if (fbPageId.trim() && fbAccessToken.trim()) {
      setFbPostStatus("جاري النشر التلقائي على صفحة فيسبوك عبر Graph API…");
      try {
        const res = await fetch(
          `https://graph.facebook.com/v19.0/${encodeURIComponent(fbPageId.trim())}/feed`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: caption,
              link: articleUrl,
              access_token: fbAccessToken.trim(),
            }),
          },
        );
        const data = await res.json();
        if (data?.id) {
          setFbPostStatus(`✅ تم نشر الخبر مباشرة على صفحة فيسبوك (معرّف المنشور: ${data.id})!`);
          return;
        }
      } catch {
        /* fallback to share dialog */
      }
    }

    try {
      await navigator.clipboard.writeText(caption);
    } catch {}
    const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
      articleUrl,
    )}&quote=${encodeURIComponent(caption)}`;
    window.open(shareUrl, "_blank", "noopener,noreferrer,width=680,height=640");
    showToastMsg("📘 تم نسخ نص الخبر وفتح نافذة النشر على صفحة فيسبوك!");
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-3xl border-2 border-primary-deep bg-gradient-to-l from-[#111827] via-[#1e293b] to-[#0f172a] p-5 text-white shadow-lg sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-extrabold text-[#111827]">
              📱 مركز التواصل والنشرات الذكي · AI Social Hub
            </span>
            <h2 className="mt-2 text-xl font-extrabold sm:text-2xl">
              التواصل والنشرات · تتبع الشخصيات المحلية + فيسبوك وتيك توك
            </h2>
            <p className="mt-1 max-w-2xl text-xs font-semibold text-white/80 sm:text-sm">
              إضافة وتتبع الشخصيات المحلية في رهط بالاسم ورابط فيسبوك، النشر التلقائي، صفحة تواصل
              اجتماعي المدمجة في جميع القوائم، وناشر تيك توك بالذكاء الاصطناعي.
            </p>
          </div>

          {/* Master Activation Switch for /social and Feed */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                const nextVal = !vipEnabled;
                setVipEnabled(nextVal);
                void persistSocialHubSettings(
                  { vip: nextVal },
                  nextVal
                    ? "✅ تم تفعيل صفحة وقسم «تواصل اجتماعي» وإدراجه تلقائياً في شريط القوائم العلوية والسفلية والفوتر!"
                    : "🔒 تم إخفاء صفحة وقسم «تواصل اجتماعي» عن الزوار والقوائم.",
                );
              }}
              className={`inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-xs font-extrabold shadow-md transition ${
                vipEnabled
                  ? "bg-emerald-600 text-white hover:bg-emerald-700 ring-2 ring-emerald-400/40"
                  : "bg-primary text-[#111827] hover:bg-primary-hover"
              }`}
            >
              <span>{vipEnabled ? "✅ مفعل ومضاف في جميع القوائم" : "🔒 مخفي حالياً — اضغط للتفعيل وإضافته للقوائم"}</span>
            </button>

            {vipEnabled ? (
              <a
                href="/social"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-2xl bg-white/15 px-4 py-3 text-xs font-extrabold text-white hover:bg-white/25"
              >
                🌐 فتح صفحة /social ↗
              </a>
            ) : null}
          </div>
        </div>

        {/* Sub-Navigation Pills */}
        <div className="mt-5 flex flex-wrap gap-2">
          {[
            { id: "local-figures", label: `👥 تتبع شخصيات رهط والنقب (${localFigures.length})` },
            { id: "vip-feed", label: `🌐 صفحة وقسم تواصل اجتماعي (${vipEnabled ? "مفعّل" : "مخفي"})` },
            { id: "pages", label: "📘 ربط صفحة فيسبوك ونشر الأخبار" },
            { id: "tiktok-ai", label: "🎬 ناشر تيك توك بالذكاء الاصطناعي" },
            { id: "weather-security", label: "🌧️ أنيميشن الطقس والصلاة + الأمان" },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id as typeof subTab)}
              className={`rounded-2xl px-4 py-2.5 text-xs font-extrabold transition ${
                subTab === t.id
                  ? "bg-primary text-[#111827] shadow-md"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {toast ? (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm font-extrabold text-emerald-800 shadow-xs">
          {toast}
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: تتبع شخصيات ومؤسسات رهط والنقب المحلية ونشر تلقائي بالاسم ورابط فيسبوك
       * ===================================================================== */}
      {subTab === "local-figures" ? (
        <div className="space-y-6">
          <div className="stamp p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
              <div>
                <span className="inline-block rounded-full bg-[#1877F2]/10 px-2.5 py-0.5 text-xs font-extrabold text-[#1877F2]">
                  👥 تتبع المنشورات والنشر التلقائي في فيسبوك
                </span>
                <h3 className="mt-1 text-lg font-extrabold text-ink">
                  إضافة وتتبع شخصيات ومؤسسات رهط والنقب (بالاسم ورابط الفيسبوك)
                </h3>
                <p className="text-xs font-semibold text-muted">
                  أضف أي شخصية محلية أو صفحة فيسبوك في رهط لتتبع منشوراتها دورياً وجلبها ونشرها تلقائياً
                  في قالب فيسبوك العصري داخل صفحة وقسم «تواصل اجتماعي».
                </p>
              </div>
            </div>

            {/* Add Figure Form */}
            <div className="mt-4 rounded-2xl border border-primary-deep/40 bg-surface/60 p-4">
              <h4 className="text-sm font-extrabold text-ink">
                ➕ إضافة شخصية / صفحة جديدة للمتابعة والنشر التلقائي:
              </h4>

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    1. الاسم (اسم الشخصية أو الصفحة)
                  </span>
                  <input
                    type="text"
                    value={newFigName}
                    onChange={(e) => setNewFigName(e.target.value)}
                    placeholder="مثال: رئيس بلدية رهط / المركز الجماهيري"
                    className="field text-xs font-bold"
                  />
                </div>

                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    2. رابط الفيسبوك (Facebook URL أو المعرّف)
                  </span>
                  <input
                    type="text"
                    dir="ltr"
                    value={newFigFbUrl}
                    onChange={(e) => setNewFigFbUrl(e.target.value)}
                    placeholder="https://facebook.com/username"
                    className="field text-xs font-bold"
                  />
                </div>

                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    3. الصفة / الدور في رهط
                  </span>
                  <input
                    type="text"
                    value={newFigRole}
                    onChange={(e) => setNewFigRole(e.target.value)}
                    placeholder="مثال: رئيس البلدية / ناشط شبابي"
                    className="field text-xs font-bold"
                  />
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={newFigCategory}
                    onChange={(e) => setNewFigCategory(e.target.value as typeof newFigCategory)}
                    className="field w-48 text-xs font-bold"
                  >
                    <option value="local">📍 شخصية / مؤسسة محلية في رهط</option>
                    <option value="politicians">🏛️ شؤون سياسية وبرلمانية</option>
                    <option value="community">⭐ فعاليات مجتمعية وشبابية</option>
                  </select>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-extrabold text-ink">
                    <input
                      type="checkbox"
                      checked={newFigAutoPublish}
                      onChange={(e) => setNewFigAutoPublish(e.target.checked)}
                      className="size-4.5 rounded accent-[#1877F2]"
                    />
                    <span>تفعيل النشر التلقائي لمنشورات هذه الشخصية في صفحة تواصل اجتماعي</span>
                  </label>
                </div>

                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleAddLocalFigure()}
                  className="btn bg-[#1877F2] text-white hover:bg-[#1d4ed8]"
                >
                  ➕ إضافة وتتبع الشخصية الآن
                </button>
              </div>
            </div>

            {/* List of Tracked Figures */}
            <div className="mt-5">
              <h4 className="mb-3 text-sm font-extrabold text-ink">
                📋 الشخصيات والصفحات المحلية المتابعة حالياً ({localFigures.length}):
              </h4>

              <div className="grid gap-3 sm:grid-cols-2">
                {localFigures.map((fig) => (
                  <div
                    key={fig.id}
                    className="flex flex-col justify-between rounded-2xl border border-line bg-paper p-3.5 shadow-2xs transition hover:border-[#1877F2]"
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={fig.avatarUrl || makeAvatarSvgDataUri(fig.name.slice(0, 2), "#1877F2")}
                          alt={fig.name}
                          width={40}
                          height={40}
                          className="size-10 rounded-full border border-line object-cover"
                        />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-extrabold text-ink">{fig.name}</p>
                          <p className="truncate text-[11px] font-semibold text-muted">{fig.role}</p>
                          <a
                            href={fig.fbUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10.5px] font-bold text-[#1877F2] hover:underline"
                            dir="ltr"
                          >
                            <span>📘 Facebook</span>
                            <span>↗</span>
                          </a>
                        </div>
                      </div>

                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                          fig.autoPublish
                            ? "bg-emerald-500/15 text-emerald-700"
                            : "bg-surface text-muted"
                        }`}
                      >
                        {fig.autoPublish ? "● نشر تلقائي مفعّل" : "متوقف"}
                      </span>
                    </div>

                    <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 border-t border-line/70 pt-2.5">
                      <button
                        type="button"
                        onClick={() => void handleFetchLatestPostForFigure(fig)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-primary-soft px-3 py-1.5 text-xs font-extrabold text-primary-ink hover:brightness-95"
                        title="جلب أحدث منشور لهذه الشخصية وإضافته فوراً لصفحة تواصل اجتماعي"
                      >
                        <span>🔄</span>
                        <span>جلب ونشر أحدث منشور الآن</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void handleToggleFigureAuto(fig.id)}
                          className="text-xs font-bold text-muted hover:text-ink underline"
                        >
                          {fig.autoPublish ? "تعطيل التلقائي" : "تفعيل التلقائي"}
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDeleteFigure(fig.id)}
                          className="text-xs font-bold text-rose-600 hover:text-rose-800"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: صفحة وقسم تواصل اجتماعي (المشاهير والسياسيون والتريند)
       * ===================================================================== */}
      {subTab === "vip-feed" ? (
        <div className="space-y-6">
          <div className="stamp p-5">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line pb-4">
              <div>
                <h3 className="text-lg font-extrabold text-ink">
                  🌐 صفحة وقسم «تواصل اجتماعي · فيسبوك والتريند»
                </h3>
                <p className="mt-1 text-xs font-semibold text-muted">
                  عند تفعيل القسم، يصبح له صفحة مستقلة على الرابط `/social` ويُضاف تلقائياً إلى شريط
                  القوائم العلوي والسفلي والفوتر مع تصميم فيسبوك العصري المباشر.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    const nextVal = !vipEnabled;
                    setVipEnabled(nextVal);
                    void persistSocialHubSettings(
                      { vip: nextVal },
                      nextVal
                        ? "✅ تم تفعيل وإظهار صفحة تواصل اجتماعي في جميع القوائم!"
                        : "🔒 تم إخفاء صفحة تواصل اجتماعي عن الزوار.",
                    );
                  }}
                  className={`inline-flex items-center gap-2.5 rounded-2xl px-5 py-3 text-xs font-extrabold shadow-sm transition ${
                    vipEnabled
                      ? "bg-emerald-600 text-white hover:bg-emerald-700"
                      : "bg-primary text-[#111827] hover:bg-primary-hover"
                  }`}
                >
                  <span>{vipEnabled ? "✅ مفعّل ومضاف بالقوائم" : "🔒 مخفي حالياً — اضغط للتفعيل"}</span>
                </button>
              </div>
            </div>

            {/* Custom Post Form */}
            <div className="mt-4 rounded-2xl border border-line bg-surface/50 p-4">
              <h4 className="text-sm font-extrabold text-ink">
                ➕ نشر تغريدة أو منشور مخصص في صفحة تواصل اجتماعي:
              </h4>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <select
                  value={newPlatform}
                  onChange={(e) => setNewPlatform(e.target.value as "x" | "facebook")}
                  className="field text-xs font-bold"
                >
                  <option value="facebook">📘 منصة فيسبوك (قالب فيسبوك)</option>
                  <option value="x">𝕏 منصة إكس (تويتر)</option>
                </select>

                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as typeof newCategory)}
                  className="field text-xs font-bold"
                >
                  <option value="local">📍 شخصيات ومؤسسات رهط والنقب</option>
                  <option value="politicians">🏛️ سياسيون</option>
                  <option value="celebrities">⭐ مشاهير</option>
                  <option value="sports">⚽ رياضة</option>
                </select>

                <select
                  value={newOriginalLang}
                  onChange={(e) => setNewOriginalLang(e.target.value as "he" | "en" | "ar")}
                  className="field text-xs font-bold"
                >
                  <option value="ar">لغة المنشور: عربية</option>
                  <option value="he">لغة المنشور: عبرية (مع زر ترجمة)</option>
                  <option value="en">لغة المنشور: إنجليزية (مع زر ترجمة)</option>
                </select>
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <input
                  type="text"
                  value={newAuthorName}
                  onChange={(e) => setNewAuthorName(e.target.value)}
                  placeholder="الاسم (مثال: بلدية رهط / محمد صلاح)"
                  className="field text-xs font-bold"
                />
                <input
                  type="text"
                  dir="ltr"
                  value={newAuthorHandle}
                  onChange={(e) => setNewAuthorHandle(e.target.value)}
                  placeholder="@handle"
                  className="field text-xs font-bold"
                />
                <input
                  type="text"
                  value={newAuthorRole}
                  onChange={(e) => setNewAuthorRole(e.target.value)}
                  placeholder="الصفة / الدور"
                  className="field text-xs font-bold"
                />
              </div>

              <textarea
                rows={2}
                value={newOriginalText}
                onChange={(e) => setNewOriginalText(e.target.value)}
                placeholder="نص المنشور كما يظهر على فيسبوك أو إكس…"
                className="field mt-3 text-xs font-bold"
              />

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <textarea
                  rows={2}
                  value={newTranslatedAr}
                  onChange={(e) => setNewTranslatedAr(e.target.value)}
                  placeholder="الترجمة العربية الاختيارية…"
                  className="field text-xs font-bold sm:col-span-2"
                />
                <div className="flex flex-col gap-2">
                  <input
                    type="text"
                    value={newTrendTag}
                    onChange={(e) => setNewTrendTag(e.target.value)}
                    placeholder="هاشتاج التريند (#رهط_بوست)"
                    className="field text-xs font-bold"
                  />
                  <button
                    type="button"
                    disabled={busy}
                    onClick={async () => {
                      if (!newAuthorName.trim() || !newOriginalText.trim()) {
                        showToastMsg("يرجى إدخال اسم الشخصية ونص المنشور.");
                        return;
                      }
                      const newItem: SocialVipPostItem = {
                        id: `custom-${Date.now()}`,
                        platform: newPlatform,
                        authorName: newAuthorName.trim(),
                        authorHandle: newAuthorHandle.trim() || "@official",
                        authorRole: newAuthorRole.trim() || "شخصية عامة",
                        category: newCategory,
                        avatarUrl: makeAvatarSvgDataUri(newAuthorName.trim().slice(0, 2), "#1877F2"),
                        verified: "blue",
                        publishedAgo: "الآن",
                        originalLang: newOriginalLang,
                        originalText: newOriginalText.trim(),
                        translatedAr: newTranslatedAr.trim() || newOriginalText.trim(),
                        trendTag: newTrendTag.trim() || "#رهط_بوست",
                        likes: 180,
                        commentsCount: 24,
                        shares: 18,
                        views: "5.4K",
                        sampleComments: [],
                      };
                      const nextList = [newItem, ...customVipPosts].slice(0, 25);
                      const encoded = toBase64UrlSafe(JSON.stringify(nextList));
                      const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialvipcustom");
                      const nextDraft: SiteSettings = {
                        ...draft,
                        quickLinks: [
                          ...otherLinks,
                          {
                            id: "socialvipcustom",
                            title: `count:${nextList.length}`,
                            subtitle: encoded.slice(180) || "vip",
                            url: `/__svip?${encoded.slice(0, 180)}`,
                          },
                        ],
                      };
                      setDraft(nextDraft);
                      await saveNow(nextDraft, "تمت إضافة المنشور وحفظه في صفحة تواصل اجتماعي ✓");
                      setNewAuthorName("");
                      setNewOriginalText("");
                      setNewTranslatedAr("");
                      showToastMsg("تمت إضافة المنشور بنجاح ✓");
                    }}
                    className="btn min-h-10 text-xs"
                  >
                    ➕ إضافة وحفظ المنشور
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Live Admin Preview of Social Section */}
          <div className="space-y-2">
            <p className="text-xs font-extrabold text-muted">
              👁️ معاينة حية لقالب فيسبوك العصري كما يظهر للزوار:
            </p>
            <SocialVipFeedAndTrendsSection forceShowForAdminPreview />
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: ربط صفحة فيسبوك ونشر المقالات
       * ===================================================================== */}
      {subTab === "pages" ? (
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="stamp space-y-4 p-5 lg:col-span-5">
            <div className="flex items-center gap-2.5 border-b border-line pb-3">
              <span className="grid size-10 place-items-center rounded-2xl bg-[#1877f2] text-lg font-black text-white">
                f
              </span>
              <div>
                <h3 className="text-base font-extrabold text-ink">
                  ربط صفحة رهط بوست على فيسبوك
                </h3>
                <p className="text-xs font-semibold text-muted">
                  ربط مباشر لنشر مقالات وأخبار الموقع على الصفحة
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <label className="block">
                <span className="mb-1 block text-xs font-extrabold text-ink">
                  اسم الصفحة على فيسبوك
                </span>
                <input
                  type="text"
                  value={fbPageName}
                  onChange={(e) => setFbPageName(e.target.value)}
                  className="field text-sm font-bold"
                  placeholder="رهط بوست - Rahat Post"
                />
              </label>

              <label className="block">
                <span className="mb-1 block text-xs font-extrabold text-ink">
                  رابط صفحة فيسبوك
                </span>
                <input
                  type="url"
                  dir="ltr"
                  value={fbPageUrl}
                  onChange={(e) => setFbPageUrl(e.target.value)}
                  className="field text-sm font-bold"
                />
              </label>

              <button
                type="button"
                disabled={busy}
                onClick={() => void persistSocialHubSettings()}
                className="btn w-full"
              >
                💾 حفظ إعدادات الصفحة
              </button>
            </div>
          </div>

          <div className="stamp space-y-4 p-5 lg:col-span-7">
            <h3 className="text-base font-extrabold text-ink">
              📰 مقالات الموقع الجاهزة للنشر على فيسبوك:
            </h3>
            {fbPostStatus ? (
              <p className="rounded-xl bg-sky-500/10 p-2.5 text-xs font-extrabold text-sky-800">
                {fbPostStatus}
              </p>
            ) : null}
            <div className="space-y-3">
              {sampleArticles.slice(0, 5).map((art, idx) => (
                <div key={idx} className="rounded-2xl border border-line bg-surface/60 p-3.5">
                  <span className="chip text-[10px]">{art.category}</span>
                  <h4 className="mt-1 text-sm font-extrabold text-ink">{art.title}</h4>
                  <div className="mt-3 flex gap-2">
                    <button
                      type="button"
                      onClick={() => void handlePublishToFacebookPage(art)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#1877f2] px-3 py-1.5 text-xs font-extrabold text-white"
                    >
                      📘 نشر على صفحة فيسبوك
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: ناشر تيك توك بالذكاء الاصطناعي
       * ===================================================================== */}
      {subTab === "tiktok-ai" ? (
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="stamp space-y-4 p-5 lg:col-span-7">
            <h3 className="text-lg font-extrabold text-ink">
              🎬 ناشر تيك توك الذكي · تحويل الأخبار إلى فيديو AI
            </h3>
            <div>
              <span className="mb-1 block text-xs font-extrabold text-ink">
                اختر مقالاً لتحويله إلى فيديو 9:16:
              </span>
              <select
                value={selectedArticleIdx}
                onChange={(e) => {
                  const idx = Number(e.target.value);
                  setSelectedArticleIdx(idx);
                  const a = sampleArticles[idx];
                  if (a) {
                    setVideoHeadline(a.title);
                    setVideoSummary(a.summary);
                    setVideoBadge(a.category || "عاجل · رهط بوست");
                  }
                }}
                className="field text-sm font-bold"
              >
                {sampleArticles.map((a, i) => (
                  <option key={i} value={i}>
                    📰 {a.title.slice(0, 70)}
                  </option>
                ))}
              </select>
            </div>

            <textarea
              rows={2}
              value={videoHeadline}
              onChange={(e) => setVideoHeadline(e.target.value)}
              className="field text-sm font-bold"
              placeholder="العنوان"
            />
            <textarea
              rows={3}
              value={videoSummary}
              onChange={(e) => setVideoSummary(e.target.value)}
              className="field text-xs font-bold"
              placeholder="الملخص"
            />

            <button
              type="button"
              disabled={isGeneratingVideo}
              onClick={() => void handleGenerateAiTikTokVideo()}
              className="btn w-full bg-primary text-[#111827]"
            >
              {isGeneratingVideo
                ? `⏳ جاري التوليد (${videoProgress}%)…`
                : "🎬 صناعة وتوليد فيديو تيك توك AI الآن"}
            </button>

            {generatedVideoUrl ? (
              <div className="mt-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3">
                <a
                  href={generatedVideoUrl}
                  download="rahatpost-video.webm"
                  className="inline-flex items-center gap-1 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white"
                >
                  ⬇️ تحميل ملف الفيديو
                </a>
              </div>
            ) : null}
          </div>

          <div className="stamp flex flex-col items-center justify-center p-5 lg:col-span-5">
            <canvas
              ref={canvasRef}
              width={540}
              height={960}
              className="h-[460px] w-[258px] rounded-2xl border-2 border-line bg-black"
            />
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: الطقس والأمان
       * ===================================================================== */}
      {subTab === "weather-security" ? (
        <div className="stamp space-y-4 p-5">
          <h3 className="text-lg font-extrabold text-ink">
            🌧️ أنيميشن ومظهر الطقس وأوقات الصلاة في رهط
          </h3>
          <div className="flex flex-wrap gap-2">
            {(
              [
                { id: "scene-animated", label: "🌧️ المشهد الجوي المتحرك بالأمطار" },
                { id: "mosque-gold", label: "🕌 المظهر الذهبي الفاخر" },
                { id: "glass-modern", label: "✨ المظهر الزجاجي الشفاف" },
                { id: "night-radar", label: "📊 الرادار الليلي" },
              ] as { id: WeatherPrayerVisualStyle; label: string }[]
            ).map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => void persistWeatherStyle(st.id, weatherCfg.fx)}
                className={`rounded-xl border px-3.5 py-2 text-xs font-extrabold transition ${
                  weatherCfg.style === st.id
                    ? "bg-primary text-[#111827] border-primary-deep"
                    : "bg-surface text-ink border-line"
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function drawAiTikTokFrame(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  opts: {
    headline: string;
    summary: string;
    badge: string;
    theme: "breaking-red" | "gold-night" | "cyber-neon";
    tiktokHandle: string;
    elapsedSec: number;
    totalSec: number;
  },
) {
  const { headline, summary, badge, theme, tiktokHandle, elapsedSec, totalSec } = opts;
  const progress = Math.min(1, Math.max(0, elapsedSec / Math.max(1, totalSec)));

  const grad = ctx.createLinearGradient(0, 0, w, h);
  if (theme === "breaking-red") {
    grad.addColorStop(0, "#1a0505");
    grad.addColorStop(0.5, "#450a0a");
    grad.addColorStop(1, "#0f172a");
  } else {
    grad.addColorStop(0, "#0b1120");
    grad.addColorStop(0.5, "#151f32");
    grad.addColorStop(1, "#0f172a");
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Top header bar
  ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
  ctx.fillRect(32, 48, w - 64, 72);

  ctx.fillStyle = "#f2c94c";
  ctx.fillRect(w - 104, 60, 56, 48);

  ctx.fillStyle = "#111827";
  ctx.font = "900 18px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("رهط", w - 76, 82);
  ctx.font = "800 13px sans-serif";
  ctx.fillText("بوست", w - 76, 99);

  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "right";
  ctx.font = "800 22px sans-serif";
  ctx.fillText("منصة رهط بوست الإخبارية", w - 118, 82);
  ctx.fillStyle = "#94a3b8";
  ctx.font = "700 14px sans-serif";
  ctx.fillText(`RAHATPOST.COM · ${tiktokHandle}`, w - 118, 104);

  // Badge
  ctx.fillStyle = "#f2c94c";
  ctx.fillRect((w - 300) / 2, 155, 300, 48);
  ctx.fillStyle = "#111827";
  ctx.font = "900 22px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(`🔴 ${badge}`, w / 2, 187);

  // Headline
  ctx.fillStyle = "#ffffff";
  ctx.font = "900 30px sans-serif";
  ctx.textAlign = "center";
  const words = headline.split(" ");
  let line1 = words.slice(0, 6).join(" ");
  let line2 = words.slice(6, 12).join(" ");
  ctx.fillText(line1, w / 2, 320);
  if (line2) ctx.fillText(line2, w / 2, 370);

  // Summary
  ctx.fillStyle = "#fde68a";
  ctx.font = "700 22px sans-serif";
  const sumWords = summary.split(" ");
  let s1 = sumWords.slice(0, 7).join(" ");
  let s2 = sumWords.slice(7, 14).join(" ");
  ctx.fillText(s1, w / 2, 580);
  if (s2) ctx.fillText(s2, w / 2, 620);

  // Progress Bar
  ctx.fillStyle = "rgba(255,255,255,0.2)";
  ctx.fillRect(40, 912, w - 80, 12);
  ctx.fillStyle = "#f2c94c";
  ctx.fillRect(40, 912, Math.max(16, (w - 80) * progress), 12);
}
