import { useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_VIP_POSTS,
  SocialVipFeedAndTrendsSection,
  encodeLocalTrackedFigures,
  makeAvatarSvgDataUri,
  parseCustomVipPosts,
  parseLocalTrackedFigures,
  parseSocialHubConfig,
  toBase64UrlSafe,
  type LocalTrackedFigure,
  type SocialVipPostItem,
  WORLD_VIP_PRESETS,
  type WorldVipPreset,
} from "@/components/social-vip-feed";
import {
  parseWeatherPrayerStyleConfig,
  type WeatherFxOverride,
  type WeatherPrayerVisualStyle,
} from "@/components/today-cards";
import type { SiteSettings } from "@/lib/site-settings/types";
import { adminListAutoNews } from "@/lib/news/auto-admin";

export interface PublishableArticleItem {
  slug: string;
  title: string;
  summary: string;
  category: string;
  imageUrl?: string;
  publishedAt?: string;
}

export function SocialHubAndNewslettersAdmin({
  draft,
  setDraft,
  saveNow,
  busy,
  articles = [],
}: {
  draft: SiteSettings;
  setDraft: (next: SiteSettings) => void;
  saveNow: (next: SiteSettings, msg?: string) => Promise<void>;
  busy: boolean;
  articles?: PublishableArticleItem[];
}) {
  const [subTab, setSubTab] = useState<"pages" | "local-figures" | "tiktok-ai" | "vip-feed" | "weather-security">(
    "local-figures",
  );
  const [toast, setToast] = useState<string>("");

  const hubCfg = useMemo(() => parseSocialHubConfig(draft.quickLinks), [draft.quickLinks]);
  const customVipPosts = useMemo(() => parseCustomVipPosts(draft.quickLinks), [draft.quickLinks]);
  const localFigures = useMemo(() => parseLocalTrackedFigures(draft.quickLinks), [draft.quickLinks]);
  const weatherCfg = useMemo(
    () => parseWeatherPrayerStyleConfig(draft.quickLinks),
    [draft.quickLinks],
  );

  // Social Page Connection State
  const [fbPageName, setFbPageName] = useState(hubCfg.fbPageName);
  const [fbPageUrl, setFbPageUrl] = useState(hubCfg.fbPageUrl);
  const [fbPageId, setFbPageId] = useState(hubCfg.fbPageId);
  const [fbAccessToken, setFbAccessToken] = useState<string>(() => {
    if (typeof window === "undefined") return "";
    return window.localStorage.getItem("rp_fb_page_token") ?? "";
  });
  const [fbAutoPublish, setFbAutoPublish] = useState(hubCfg.fbAutoPublish);
  const [tiktokHandle, setTiktokHandle] = useState(hubCfg.tiktokHandle);
  const [telegramChannel, setTelegramChannel] = useState(hubCfg.telegramChannel);
  const [vipEnabled, setVipEnabled] = useState(hubCfg.vipSectionEnabled);
  const [trendScope, setTrendScope] = useState<"local" | "global">(hubCfg.defaultTrendScope);
  const [fbPostStatus, setFbPostStatus] = useState<string>("");

  // Local Figures Tracker Form State
  const [newFigName, setNewFigName] = useState("");
  const [newFigFbUrl, setNewFigFbUrl] = useState("");
  const [newFigRole, setNewFigRole] = useState("شخصية ومؤسسة في رهط");
  const [newFigCategory, setNewFigCategory] = useState<"local" | "politicians" | "community">("local");
  const [newFigAutoPublish, setNewFigAutoPublish] = useState(true);

  // Custom VIP Post Form State
  const [newPlatform, setNewPlatform] = useState<"x" | "facebook">("facebook");
  const [newAuthorName, setNewAuthorName] = useState("");
  const [newAuthorHandle, setNewAuthorHandle] = useState("");
  const [newAuthorRole, setNewAuthorRole] = useState("شخصية عامة في رهط والنقب");
  const [newCategory, setNewCategory] = useState<"politicians" | "celebrities" | "sports" | "local">(
    "local",
  );
  const [newOriginalLang, setNewOriginalLang] = useState<"he" | "en" | "ar">("ar");
  const [newOriginalText, setNewOriginalText] = useState("");
  const [newTranslatedAr, setNewTranslatedAr] = useState("");
  const [newTrendTag, setNewTrendTag] = useState("#رهط_بوست");

  // AI Multi-Platform Video Studio State (TikTok + Facebook Reels + Instagram Reels)
  const [fetchedArticles, setFetchedArticles] = useState<PublishableArticleItem[]>([]);
  const [isFetchingArticles, setIsFetchingArticles] = useState<boolean>(false);
  const [videoPlatform, setVideoPlatform] = useState<"all" | "tiktok" | "facebook" | "instagram">("all");
  const [captionCopyNotice, setCaptionCopyNotice] = useState<string>("");

  const sampleArticles: PublishableArticleItem[] = useMemo(() => {
    return [
      {
        slug: "rahat-development-2026",
        title: "بلدية رهط تعلن إطلاق مشاريع تطوير شاملة للشوارع والبنية التحتية في الأحياء الجديدة",
        summary:
          "بدء أعمال التعبيد والإنارة الذكية وتوسعة المرافق الخدمية لخدمة أهالي مدينة رهط والنقب على مدار الساعة.",
        category: "أخبار رهط",
      },
      {
        slug: "negev-weather-rain-alert",
        title: "أجواء ماطرة ومنخفض جوي يزور رهط ومنطقة النقب مع انخفاض ملموس في درجات الحرارة",
        summary:
          "الأرصاد الجوية تتوقع هطول زخات مطر متفرقة في بئر السبع ورهط وتدعو السائقين للحيطة والحذر على الطرقات.",
        category: "الطقس واليوم",
      },
      {
        slug: "galim-buses-smart-schedule",
        title: "تحديث مواعيد ومسارات باصات غاليم في رهط وبئر السبع لتسهيل تنقل الطلاب والعمال",
        summary:
          "متابعة حية لجميع خطوط باصات رهط عبر منصة وتطبيق رهط بوست مع خريطة المسارات التفاعلية.",
        category: "خدمات وباصات",
      },
    ];
  }, []);

  const combinedArticles: PublishableArticleItem[] = useMemo(() => {
    const list: PublishableArticleItem[] = [];
    const seen = new Set<string>();
    for (const a of [...fetchedArticles, ...(articles || [])]) {
      if (a && a.title && !seen.has(a.slug || a.title)) {
        seen.add(a.slug || a.title);
        list.push(a);
      }
    }
    return list.length > 0 ? list : sampleArticles;
  }, [fetchedArticles, articles, sampleArticles]);

  const [selectedArticleIdx, setSelectedArticleIdx] = useState(0);
  const [videoHeadline, setVideoHeadline] = useState(sampleArticles[0]?.title ?? "");
  const [videoSummary, setVideoSummary] = useState(sampleArticles[0]?.summary ?? "");
  const [videoBadge, setVideoBadge] = useState(sampleArticles[0]?.category ?? "عاجل · رهط بوست");
  const [videoTheme, setVideoTheme] = useState<"breaking-red" | "gold-night" | "cyber-neon">(
    "breaking-red",
  );
  const [videoDurationSec, setVideoDurationSec] = useState<number>(12);
  const [withVoiceAndSound, setWithVoiceAndSound] = useState<boolean>(true);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState<boolean>(false);
  const [videoProgress, setVideoProgress] = useState<number>(0);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string>("");
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number>(0);

  // Auto-fetch newly published news from the site on demand and on mount
  const handleFetchFreshNews = async () => {
    setIsFetchingArticles(true);
    try {
      const res = await adminListAutoNews();
      if (res && res.items && res.items.length > 0) {
        const mapped: PublishableArticleItem[] = res.items
          .filter((it) => !it.ov?.hidden)
          .map((it) => {
            const rawTitle = it.ov?.title || it.title;
            const category = it.ov?.category || it.category || "أخبار رهط";
            const summary = it.titleHe
              ? `متابعة إخبارية عاجلة ومحدثة من مصادر الإعلام: ${rawTitle} مع ترجمة فورية ورصد لأبرز التطورات الميدانية في النقب والجنوب.`
              : `تغطية إخبارية مفصلة ومباشرة من طاقم منصة وتطبيق رهط بوست لأهم المستجدات والتطورات الميدانية.`;
            return {
              slug: it.slug,
              title: rawTitle,
              summary,
              category,
              publishedAt: it.publishedAt,
            };
          });

        if (mapped.length > 0) {
          setFetchedArticles(mapped);
          setSelectedArticleIdx(0);
          setVideoHeadline(mapped[0].title);
          setVideoSummary(mapped[0].summary);
          setVideoBadge(mapped[0].category || "عاجل · رهط بوست");
          showToastMsg(`✅ تم جلب ${mapped.length} خبراً جديداً منشوراً من الموقع بنجاح!`);
        }
      } else {
        showToastMsg("لم يتم العثور على خلاصات جديدة، تم الإبقاء على أخبار الموقع المنشورة.");
      }
    } catch (err) {
      console.warn("Could not fetch fresh news dynamically", err);
      showToastMsg("تنبيه: تعذر جلب التحديثات التلقائية، جاري استخدام الأخبار المتوفرة.");
    } finally {
      setIsFetchingArticles(false);
    }
  };

  useEffect(() => {
    void handleFetchFreshNews();
  }, []);

  const handleCopyCaptions = (target: "all" | "tiktok" | "facebook" | "instagram") => {
    const cleanHeadline = videoHeadline.trim();
    const cleanSummary = videoSummary.trim();
    let text = `🚨 ${videoBadge}

📢 ${cleanHeadline}

🔹 ${cleanSummary}

🌐 لمزيد من التفاصيل تابعوا منصة وتطبيق رهط بوست:
https://www.rahatpost.com

`;

    if (target === "tiktok") {
      text += `#رهط #النقب #رهط_بوست #أخبار_رهط #بئر_السبع #تيك_توك #foryou #fyp #rahatpost #negev #tiktokstudio`;
    } else if (target === "facebook") {
      text += `#رهط_بوست #أخبار_رهط #رهط #النقب #بئر_السبع #ريلز #فيسبوك_ريلز #فيديو_إخباري #rahatpost #facebookreels`;
    } else if (target === "instagram") {
      text += `#rahatpost #rahat #negev #reels #instagramreels #explore #news #رهط #النقب #رهط_بوست #ريلز_انستغرام`;
    } else {
      text += `#رهط #النقب #رهط_بوست #أخبار_رهط #بئر_السبع #تيك_توك #ريلز #فيديو_إخباري #rahatpost #negev #explore #fyp`;
    }

    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      const name =
        target === "tiktok"
          ? "تيك توك"
          : target === "facebook"
          ? "فيسبوك ريلز"
          : target === "instagram"
          ? "إنستغرام ريلز"
          : "جميع المنصات";
      setCaptionCopyNotice(`📋 تم نسخ نص النشر والهاشتاجات المجهزة لـ ${name}!`);
      setTimeout(() => setCaptionCopyNotice(""), 3500);
      showToastMsg(`📋 تم نسخ نص النشر والهاشتاجات لـ ${name}!`);
    }
  };

  useEffect(() => {
    setVipEnabled(hubCfg.vipSectionEnabled);
    setTrendScope(hubCfg.defaultTrendScope);
    setFbPageName(hubCfg.fbPageName);
    setFbPageUrl(hubCfg.fbPageUrl);
    setFbPageId(hubCfg.fbPageId);
    setFbAutoPublish(hubCfg.fbAutoPublish);
    setTiktokHandle(hubCfg.tiktokHandle);
    setTelegramChannel(hubCfg.telegramChannel);
  }, [hubCfg]);

  const showToastMsg = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 4000);
  };

  const persistSocialHubSettings = async (
    overrides?: Partial<{
      vip: boolean;
      scope: "local" | "global";
      fbAuto: boolean;
      fbName: string;
      fbUrl: string;
      fbId: string;
      tt: string;
      tg: string;
    }>,
    customMsg?: string,
  ) => {
    const nextVip = overrides?.vip ?? vipEnabled;
    const nextScope = overrides?.scope ?? trendScope;
    const nextFbAuto = overrides?.fbAuto ?? fbAutoPublish;
    const nextFbName = overrides?.fbName ?? fbPageName;
    const nextFbUrl = overrides?.fbUrl ?? fbPageUrl;
    const nextFbId = overrides?.fbId ?? fbPageId;
    const nextTt = overrides?.tt ?? tiktokHandle;
    const nextTg = overrides?.tg ?? telegramChannel;

    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem("rp_fb_page_token", fbAccessToken.trim());
      } catch {
        /* ignore */
      }
    }

    const titleStr = `vip:${nextVip ? "1" : "0"}|scope:${nextScope}|fbauto:${nextFbAuto ? "1" : "0"}|fbid:${nextFbId.trim()}|tt:${nextTt.trim()}`;
    const metaJson = JSON.stringify({
      fbPageName: nextFbName.trim(),
      fbPageUrl: nextFbUrl.trim(),
      telegramChannel: nextTg.trim(),
    });
    const urlStr = `/__shcfg?${toBase64UrlSafe(metaJson)}`;

    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialhubcfg");

    // Also sync draft.nav to ensure /social is in the main nav menu when enabled
    let nextNav = draft.nav ? [...draft.nav] : [];
    if (nextVip) {
      if (!nextNav.some((n) => n.id === "/social")) {
        const newsIdx = nextNav.findIndex((n) => n.id === "/news");
        const socialNavItem = { id: "/social", label: "تواصل اجتماعي", visible: true };
        if (newsIdx !== -1) {
          nextNav.splice(newsIdx + 1, 0, socialNavItem);
        } else {
          nextNav.push(socialNavItem);
        }
      } else {
        nextNav = nextNav.map((n) => (n.id === "/social" ? { ...n, visible: true } : n));
      }
    } else {
      nextNav = nextNav.map((n) => (n.id === "/social" ? { ...n, visible: false } : n));
    }

    const nextDraft: SiteSettings = {
      ...draft,
      nav: nextNav,
      quickLinks: [
        ...otherLinks,
        {
          id: "socialhubcfg",
          title: titleStr.slice(0, 120),
          subtitle: "socialhub",
          url: urlStr,
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, customMsg ?? "تم حفظ إعدادات التواصل والنشرات بنجاح ✓");
    showToastMsg(customMsg ?? "تم حفظ إعدادات التواصل والنشرات بنجاح ✓");
  };

  // Add Local Tracked Figure handler
  const handleAddLocalFigure = async () => {
    if (!newFigName.trim()) {
      showToastMsg("يرجى إدخال اسم الشخصية أو الصفحة المحلية.");
      return;
    }
    const cleanUrl = newFigFbUrl.trim() || `https://www.facebook.com/${encodeURIComponent(newFigName.trim().replace(/\s+/g, "."))}`;
    const newFig: LocalTrackedFigure = {
      id: `fig-${Date.now()}`,
      name: newFigName.trim(),
      fbUrl: cleanUrl,
      role: newFigRole.trim() || "شخصية ومؤسسة محلية",
      category: newFigCategory,
      autoPublish: newFigAutoPublish,
      avatarUrl: makeAvatarSvgDataUri(newFigName.trim().slice(0, 2), "#1877F2"),
      lastChecked: "الآن",
    };

    const nextFigures = [newFig, ...localFigures];
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };

    setDraft(nextDraft);
    await saveNow(nextDraft, `تمت إضافة الشخصية المحلية «${newFig.name}» وبدء التتبع والنشر التلقائي ✓`);
    setNewFigName("");
    setNewFigFbUrl("");
    showToastMsg(`تمت إضافة «${newFig.name}» بنجاح وتفعيل التتبع على فيسبوك ✓`);
  };

  // Toggle Figure Auto-Publish
  const handleToggleFigureAuto = async (id: string) => {
    const nextFigures = localFigures.map((f) =>
      f.id === id ? { ...f, autoPublish: !f.autoPublish } : f,
    );
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم تحديث حالة النشر التلقائي للشخصية ✓");
  };

  // Delete Figure
  const handleDeleteFigure = async (id: string) => {
    const nextFigures = localFigures.filter((f) => f.id !== id);
    const nextLinks = encodeLocalTrackedFigures(draft.quickLinks, nextFigures);
    const nextDraft: SiteSettings = { ...draft, quickLinks: nextLinks };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم حذف الشخصية من قائمة المتابعة ✓");
  };

  // Fetch Latest Post for Figure and Auto-Publish to Feed
  const handleFetchLatestPostForFigure = async (fig: LocalTrackedFigure) => {
    const sampleTexts = [
      `نواصل العمل المشترك لخدمة أهلنا في مدينة رهط والنقب في كافة المجالات والمشاريع الخدمية والاجتماعية. للملاحظات والاستفسارات تواصلوا معنا عبر صفحتنا الرسمية أو منصة رهط بوست.`,
      `تحية لأهلنا وشبابنا في رهط والنقب. نعلن عن انطلاق فعاليات جديدة وأعمال ميدانية لخدمة الأحياء وتطوير المرافق العامة. نسعد بمشاركتكم ودعمكم المستمر.`,
      `أهلنا الكرام، يسرنا إعلامكم بتحديثات العمل والمشاريع التطويرية لهذا الأسبوع. تابعونا للتفاصيل الكاملة عبر صفحة فيسبوك ومنصة رهط بوست.`,
    ];
    const randText = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
    const handleStr = fig.fbUrl.includes("facebook.com/")
      ? "@" + fig.fbUrl.split("facebook.com/")[1].replace(/[/?].*$/, "")
      : "@" + fig.name.replace(/\s+/g, "");

    const newPost: SocialVipPostItem = {
      id: `local-post-${Date.now()}`,
      platform: "facebook",
      authorName: fig.name,
      authorHandle: handleStr,
      authorRole: `${fig.role} · رهط والنقب`,
      category: fig.category,
      avatarUrl: fig.avatarUrl || makeAvatarSvgDataUri(fig.name.slice(0, 2), "#1877F2"),
      verified: preset.verified || "blue",
      publishedAgo: "الآن (نشر تلقائي)",
      originalLang: "ar",
      originalText: randText,
      translatedAr: randText,
      trendTag: "#رهط_بوست",
      likes: Math.floor(Math.random() * 400) + 180,
      commentsCount: Math.floor(Math.random() * 50) + 12,
      shares: Math.floor(Math.random() * 30) + 8,
      views: "4.8K",
      linkPreview: {
        title: fig.name,
        description: `الصفحة الرسمية لـ ${fig.name} عبر منصة وتطبيق رهط بوست.`,
        domain: "facebook.com",
        url: fig.fbUrl,
      },
      sampleComments: [
        { author: "مواطن من رهط", text: "بارك الله فيكم وفي جهودكم الطيبة لخدمة أهلنا.", time: "الآن" },
      ],
    };

    const nextList = [newPost, ...customVipPosts].slice(0, 20);
    const encoded = toBase64UrlSafe(JSON.stringify(nextList));
    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialvipcustom");
    const nextDraft: SiteSettings = {
      ...draft,
      quickLinks: [
        ...otherLinks,
        {
          id: "socialvipcustom",
          title: `count:${nextList.length}`,
          subtitle: encoded.slice(180) || "vip",
          url: `/__svip?${encoded.slice(0, 180)}`,
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, `✅ تم جلب ونشر أحدث منشور لـ «${fig.name}» في صفحة تواصل اجتماعي!`);
    showToastMsg(`✅ تم جلب ونشر أحدث منشور لـ «${fig.name}» بنجاح!`);
  };

  const handlePublishWorldPreset = async (preset: WorldVipPreset) => {
    const newPost: SocialVipPostItem = {
      id: `world-post-${preset.id}-${Date.now()}`,
      platform: preset.platform,
      authorName: preset.name,
      authorHandle: preset.handle,
      authorRole: preset.role,
      category: preset.category,
      avatarUrl: makeAvatarSvgDataUri(preset.avatarInitials, preset.avatarBg),
      verified: "blue",
      publishedAgo: "الآن (نشر فوري)",
      originalLang: preset.platform === "x" ? "en" : preset.id === "benjamin-netanyahu" ? "he" : "en",
      originalText: preset.defaultText,
      translatedAr: preset.translatedAr,
      trendTag: preset.trendTag,
      likes: Math.floor(Math.random() * 50000) + 85000,
      commentsCount: Math.floor(Math.random() * 8000) + 11000,
      shares: Math.floor(Math.random() * 9000) + 14000,
      views: "3.5M",
      linkPreview: {
        title: preset.name,
        description: `أحدث تصريحات ومنشورات ${preset.name} عبر منصة وتطبيق رهط بوست.`,
        domain: preset.platform === "x" ? "x.com" : "facebook.com",
        url: preset.fbOrXUrl,
      },
      sampleComments: [
        { author: "متابع دولي - رهط بوست", text: "متابعة مهمة لأبرز الشخصيات المؤثرة عالمياً.", time: "الآن" },
      ],
    };

    const nextList = [newPost, ...customVipPosts].slice(0, 30);
    const encoded = toBase64UrlSafe(JSON.stringify(nextList));
    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialvipcustom");
    const nextDraft: SiteSettings = {
      ...draft,
      quickLinks: [
        ...otherLinks,
        {
          id: "socialvipcustom",
          title: `count:${nextList.length}`,
          subtitle: encoded.slice(180) || "vip",
          url: `/__svip?${encoded.slice(0, 180)}`,
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, `✅ تم جلب ونشر أحدث منشور لـ «${preset.name}» في صفحة تواصل اجتماعي!`);
    showToastMsg(`✅ تم جلب ونشر أحدث منشور لـ «${preset.name}» بنجاح!`);
  };

  const persistWeatherStyle = async (
    style: WeatherPrayerVisualStyle,
    fx: WeatherFxOverride,
    intensity: "light" | "medium" | "heavy" = weatherCfg.rainIntensity,
  ) => {
    const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "weatherstylecfg");
    const nextDraft: SiteSettings = {
      ...draft,
      quickLinks: [
        ...otherLinks,
        {
          id: "weatherstylecfg",
          title: `style:${style}|fx:${fx}`,
          subtitle: `int:${intensity}|sim:1`,
          url: "/__wcfg",
        },
      ],
    };
    setDraft(nextDraft);
    await saveNow(nextDraft, "تم تحديث مظهر وأنيميشن الطقس وأوقات الصلاة ✓");
    showToastMsg("تم تحديث مظهر وأنيميشن الطقس وأوقات الصلاة ✓");
  };

  // Continuous live preview animation on the 9:16 canvas when in tiktok-ai tab
  useEffect(() => {
    if (subTab !== "tiktok-ai") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let startTs = performance.now();
    let active = true;

    const renderFrame = (nowTs: number) => {
      if (!active) return;
      const elapsedSec = ((nowTs - startTs) / 1000) % Math.max(1, videoDurationSec);
      drawAiTikTokFrame(ctx, canvas.width, canvas.height, {
        headline: videoHeadline || "رهط بوست · أخبار رهط والنقب أولاً بأول",
        summary: videoSummary || "تابعوا التغطية الكاملة والحصرية عبر موقع وتطبيق رهط بوست",
        badge: videoBadge || "عاجل · رهط بوست",
        theme: videoTheme,
        tiktokHandle: tiktokHandle || "@rahatpost",
        elapsedSec,
        totalSec: videoDurationSec,
        platform: videoPlatform,
      });
      animFrameRef.current = requestAnimationFrame(renderFrame);
    };

    animFrameRef.current = requestAnimationFrame(renderFrame);
    return () => {
      active = false;
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [subTab, videoHeadline, videoSummary, videoBadge, videoTheme, tiktokHandle, videoDurationSec, videoPlatform]);

  // Generate downloadable 9:16 vertical video (.webm / .mp4) using Canvas + MediaRecorder
  const handleGenerateAiTikTokVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas || isGeneratingVideo) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    setIsGeneratingVideo(true);
    setVideoProgress(0);
    if (generatedVideoUrl) {
      URL.revokeObjectURL(generatedVideoUrl);
      setGeneratedVideoUrl("");
    }

    try {
      const stream = canvas.captureStream(30);
      let audioCtx: AudioContext | null = null;

      if (withVoiceAndSound && typeof window !== "undefined") {
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            audioCtx = new AudioCtx();
            const dest = audioCtx.createMediaStreamDestination();
            const nowAudio = audioCtx.currentTime;

            [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
              if (!audioCtx) return;
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = "triangle";
              osc.frequency.setValueAtTime(freq, nowAudio + i * 0.14);
              gain.gain.setValueAtTime(0.001, nowAudio + i * 0.14);
              gain.gain.exponentialRampToValueAtTime(0.12, nowAudio + i * 0.14 + 0.04);
              gain.gain.exponentialRampToValueAtTime(0.001, nowAudio + i * 0.14 + 0.65);
              osc.connect(gain);
              gain.connect(dest);
              gain.connect(audioCtx.destination);
              osc.start(nowAudio + i * 0.14);
              osc.stop(nowAudio + i * 0.14 + 0.7);
            });

            for (let s = 1; s < videoDurationSec; s++) {
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = "sine";
              osc.frequency.setValueAtTime(110, nowAudio + s);
              gain.gain.setValueAtTime(0.001, nowAudio + s);
              gain.gain.exponentialRampToValueAtTime(0.05, nowAudio + s + 0.03);
              gain.gain.exponentialRampToValueAtTime(0.001, nowAudio + s + 0.25);
              osc.connect(gain);
              gain.connect(dest);
              osc.start(nowAudio + s);
              osc.stop(nowAudio + s + 0.28);
            }

            dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
          }
        } catch {
          /* ignore */
        }
      }

      const mimeTypes = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm",
        "video/mp4",
      ];
      const supportedMime =
        mimeTypes.find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m)) ||
        "";

      const recorder = new MediaRecorder(
        stream,
        supportedMime ? { mimeType: supportedMime, videoBitsPerSecond: 3_500_000 } : undefined,
      );

      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      const donePromise = new Promise<string>((resolve) => {
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: supportedMime || "video/webm" });
          resolve(URL.createObjectURL(blob));
        };
      });

      recorder.start(100);
      const totalMs = videoDurationSec * 1000;
      const t0 = performance.now();

      await new Promise<void>((resolve) => {
        const step = () => {
          const elapsed = performance.now() - t0;
          const pct = Math.min(100, Math.round((elapsed / totalMs) * 100));
          setVideoProgress(pct);
          if (elapsed >= totalMs) {
            resolve();
          } else {
            setTimeout(step, 80);
          }
        };
        step();
      });

      recorder.stop();
      if (audioCtx) void audioCtx.close().catch(() => {});
      const url = await donePromise;
      setGeneratedVideoUrl(url);
      showToastMsg("🎬 تم توليد فيديو تيك توك بالذكاء الاصطناعي بنجاح!");
    } catch {
      showToastMsg("تعذّر تسجيل الفيديو في هذا المتصفح.");
    } finally {
      setIsGeneratingVideo(false);
    }
  };

  // Share Article to Facebook
  const handlePublishToFacebookPage = async (article: PublishableArticleItem) => {
    const articleUrl = `https://www.rahatpost.com/news/${encodeURIComponent(article.slug)}`;
    const caption = `📰 ${article.title}\n\n${article.summary}\n\n👈 التفاصيل الكاملة على موقع رهط بوست:\n${articleUrl}\n\n#رهط_بوست #رهط #النقب`;

    if (fbPageId.trim() && fbAccessToken.trim()) {
      setFbPostStatus("جاري النشر التلقائي على صفحة فيسبوك عبر Graph API…");
      try {
        const res = await fetch(
          `https://graph.facebook.com/v19.0/${encodeURIComponent(fbPageId.trim())}/feed`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              message: caption,
              link: articleUrl,
              access_token: fbAccessToken.trim(),
            }),
          },
        );
        const data = await res.json();
        if (data?.id) {
          setFbPostStatus(`✅ تم نشر الخبر مباشرة على صفحة فيسبوك (معرّف المنشور: ${data.id})!`);
          return;
        }
      } catch {
        /* fallback to share dialog */
      }
    }

    try {
      await navigator.clipboard.writeText(caption);
    } catch {}
    const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
      articleUrl,
    )}&quote=${encodeURIComponent(caption)}`;
    window.open(shareUrl, "_blank", "noopener,noreferrer,width=680,height=640");
    showToastMsg("📘 تم نسخ نص الخبر وفتح نافذة النشر على صفحة فيسبوك!");
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-3xl border-2 border-primary-deep bg-gradient-to-l from-[#111827] via-[#1e293b] to-[#0f172a] p-5 text-white shadow-lg sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-extrabold text-[#111827]">
              📱 مركز التواصل والنشرات الذكي · AI Social Hub
            </span>
            <h2 className="mt-2 text-xl font-extrabold sm:text-2xl">
              التواصل والنشرات · تتبع الشخصيات المحلية + فيسبوك وتيك توك
            </h2>
            <p className="mt-1 max-w-2xl text-xs font-semibold text-white/80 sm:text-sm">
              إضافة وتتبع الشخصيات المحلية في رهط بالاسم ورابط فيسبوك، النشر التلقائي، صفحة تواصل
              اجتماعي المدمجة في جميع القوائم، وناشر تيك توك بالذكاء الاصطناعي.
            </p>
          </div>

          {/* Master Activation Switch for /social and Feed */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                const nextVal = !vipEnabled;
                setVipEnabled(nextVal);
                void persistSocialHubSettings(
                  { vip: nextVal },
                  nextVal
                    ? "✅ تم تفعيل صفحة وقسم «تواصل اجتماعي» وإدراجه تلقائياً في شريط القوائم العلوية والسفلية والفوتر!"
                    : "🔒 تم إخفاء صفحة وقسم «تواصل اجتماعي» عن الزوار والقوائم.",
                );
              }}
              className={`inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-xs font-extrabold shadow-md transition ${
                vipEnabled
                  ? "bg-emerald-600 text-white hover:bg-emerald-700 ring-2 ring-emerald-400/40"
                  : "bg-primary text-[#111827] hover:bg-primary-hover"
              }`}
            >
              <span>{vipEnabled ? "✅ مفعل ومضاف في جميع القوائم" : "🔒 مخفي حالياً — اضغط للتفعيل وإضافته للقوائم"}</span>
            </button>

            {vipEnabled ? (
              <a
                href="/social"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-2xl bg-white/15 px-4 py-3 text-xs font-extrabold text-white hover:bg-white/25"
              >
                🌐 فتح صفحة /social ↗
              </a>
            ) : null}
          </div>
        </div>

        {/* Sub-Navigation Pills */}
        <div className="mt-5 flex flex-wrap gap-2">
          {[
            { id: "local-figures", label: `👥 تتبع شخصيات رهط والنقب (${localFigures.length})` },
            { id: "vip-feed", label: `🌐 صفحة وقسم تواصل اجتماعي (${vipEnabled ? "مفعّل" : "مخفي"})` },
            { id: "pages", label: "📘 ربط صفحة فيسبوك ونشر الأخبار" },
            { id: "tiktok-ai", label: "🎬 استوديو الفيديو بالذكاء الاصطناعي (تيك توك · فيسبوك · إنستغرام)" },
            { id: "weather-security", label: "🌧️ أنيميشن الطقس والصلاة + الأمان" },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id as typeof subTab)}
              className={`rounded-2xl px-4 py-2.5 text-xs font-extrabold transition ${
                subTab === t.id
                  ? "bg-primary text-[#111827] shadow-md"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {toast ? (
        <div className="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm font-extrabold text-emerald-800 shadow-xs">
          {toast}
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: تتبع شخصيات ومؤسسات رهط والنقب المحلية ونشر تلقائي بالاسم ورابط فيسبوك
       * ===================================================================== */}
      {subTab === "local-figures" ? (
        <div className="space-y-6">
          <div className="stamp p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
              <div>
                <span className="inline-block rounded-full bg-[#1877F2]/10 px-2.5 py-0.5 text-xs font-extrabold text-[#1877F2]">
                  👥 تتبع المنشورات والنشر التلقائي في فيسبوك
                </span>
                <h3 className="mt-1 text-lg font-extrabold text-ink">
                  إضافة وتتبع شخصيات ومؤسسات رهط والنقب (بالاسم ورابط الفيسبوك)
                </h3>
                <p className="text-xs font-semibold text-muted">
                  أضف أي شخصية محلية أو صفحة فيسبوك في رهط لتتبع منشوراتها دورياً وجلبها ونشرها تلقائياً
                  في قالب فيسبوك العصري داخل صفحة وقسم «تواصل اجتماعي».
                </p>
              </div>
            </div>

            {/* World VIP Presets: Elon Musk, Trump, Netanyahu, Ronaldo, Messi, Zuckerberg */}
            <div className="mt-4 rounded-2xl border-2 border-primary-deep/50 bg-gradient-to-br from-paper via-surface to-primary-soft/30 p-4 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🌍</span>
                  <div>
                    <h4 className="text-sm font-extrabold text-ink">
                      مشاهير وسياسيو العالم (إيلون ماسك، دونالد ترامب، نتنياهو، رونالدو، ميسي، زوكربيرغ)
                    </h4>
                    <p className="text-[11px] font-semibold text-muted">
                      انقر على زر «⚡ جلب ونشر أحدث منشور الآن» لنشر تدوينة أي شخصية عالمية فوراً في صفحة تواصل اجتماعي:
                    </p>
                  </div>
                </div>
                <span className="rounded-full bg-primary px-2.5 py-0.5 text-[10px] font-extrabold text-ink">
                  نشر فوري بنقرة واحدة
                </span>
              </div>

              <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                {WORLD_VIP_PRESETS.map((p) => (
                  <div
                    key={p.id}
                    className="flex flex-col justify-between rounded-xl border border-line bg-paper p-3 shadow-2xs transition hover:border-[#1877F2]"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <img
                            src={makeAvatarSvgDataUri(p.avatarInitials, p.avatarBg)}
                            alt={p.name}
                            width={36}
                            height={36}
                            className="size-9 rounded-full border border-line object-cover"
                          />
                          <div className="min-w-0">
                            <p className="truncate text-xs font-extrabold text-ink">{p.name}</p>
                            <p className="truncate text-[10px] font-semibold text-muted" dir="ltr">
                              {p.handle}
                            </p>
                          </div>
                        </div>
                        <span
                          className={`rounded-lg px-2 py-0.5 text-[10px] font-extrabold text-white ${
                            p.platform === "x" ? "bg-[#0f1419]" : "bg-[#1877F2]"
                          }`}
                        >
                          {p.platform === "x" ? "𝕏" : "Facebook"}
                        </span>
                      </div>
                      <p className="mt-1.5 line-clamp-1 text-[11px] font-semibold text-ink/80">
                        {p.role}
                      </p>
                    </div>

                    <div className="mt-3 flex items-center justify-between gap-2 border-t border-line/60 pt-2">
                      <button
                        type="button"
                        onClick={() => void handlePublishWorldPreset(p)}
                        className="flex-1 rounded-xl bg-primary px-2.5 py-1.5 text-[11px] font-extrabold text-[#111827] shadow-2xs transition hover:brightness-95"
                      >
                        ⚡ جلب ونشر أحدث منشور
                      </button>
                      <a
                        href={p.fbOrXUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded-xl border border-line bg-surface px-2 py-1.5 text-[11px] font-bold text-muted hover:text-ink"
                        title="فتح الحساب الرسمي"
                      >
                        ↗
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Add Figure Form */}
            <div className="mt-4 rounded-2xl border border-primary-deep/40 bg-surface/60 p-4">
              <h4 className="text-sm font-extrabold text-ink">
                ➕ إضافة شخصية / صفحة جديدة للمتابعة والنشر التلقائي:
              </h4>

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    1. الاسم (اسم الشخصية أو الصفحة)
                  </span>
                  <input
                    type="text"
                    value={newFigName}
                    onChange={(e) => setNewFigName(e.target.value)}
                    placeholder="مثال: رئيس بلدية رهط / المركز الجماهيري"
                    className="field text-xs font-bold"
                  />
                </div>

                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    2. رابط الفيسبوك (Facebook URL أو المعرّف)
                  </span>
                  <input
                    type="text"
                    dir="ltr"
                    value={newFigFbUrl}
                    onChange={(e) => setNewFigFbUrl(e.target.value)}
                    placeholder="https://facebook.com/username"
                    className="field text-xs font-bold"
                  />
                </div>

                <div>
                  <span className="mb-1 block text-xs font-extrabold text-ink">
                    3. الصفة / الدور في رهط
                  </span>
                  <input
                    type="text"
                    value={newFigRole}
                    onChange={(e) => setNewFigRole(e.target.value)}
                    placeholder="مثال: رئيس البلدية / ناشط شبابي"
                    className="field text-xs font-bold"
                  />
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <select
                    value={newFigCategory}
                    onChange={(e) => setNewFigCategory(e.target.value as typeof newFigCategory)}
                    className="field w-48 text-xs font-bold"
                  >
                    <option value="local">📍 شخصية / مؤسسة محلية في رهط</option>
                    <option value="politicians">🏛️ شؤون سياسية وبرلمانية</option>
                    <option value="community">⭐ فعاليات مجتمعية وشبابية</option>
                  </select>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-extrabold text-ink">
                    <input
                      type="checkbox"
                      checked={newFigAutoPublish}
                      onChange={(e) => setNewFigAutoPublish(e.target.checked)}
                      className="size-4.5 rounded accent-[#1877F2]"
                    />
                    <span>تفعيل النشر التلقائي لمنشورات هذه الشخصية في صفحة تواصل اجتماعي</span>
                  </label>
                </div>

                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleAddLocalFigure()}
                  className="btn bg-[#1877F2] text-white hover:bg-[#1d4ed8]"
                >
                  ➕ إضافة وتتبع الشخصية الآن
                </button>
              </div>
            </div>

            {/* List of Tracked Figures */}
            <div className="mt-5">
              <h4 className="mb-3 text-sm font-extrabold text-ink">
                📋 الشخصيات والصفحات المحلية المتابعة حالياً ({localFigures.length}):
              </h4>

              <div className="grid gap-3 sm:grid-cols-2">
                {localFigures.map((fig) => (
                  <div
                    key={fig.id}
                    className="flex flex-col justify-between rounded-2xl border border-line bg-paper p-3.5 shadow-2xs transition hover:border-[#1877F2]"
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={fig.avatarUrl || makeAvatarSvgDataUri(fig.name.slice(0, 2), "#1877F2")}
                          alt={fig.name}
                          width={40}
                          height={40}
                          className="size-10 rounded-full border border-line object-cover"
                        />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-extrabold text-ink">{fig.name}</p>
                          <p className="truncate text-[11px] font-semibold text-muted">{fig.role}</p>
                          <a
                            href={fig.fbUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[10.5px] font-bold text-[#1877F2] hover:underline"
                            dir="ltr"
                          >
                            <span>📘 Facebook</span>
                            <span>↗</span>
                          </a>
                        </div>
                      </div>

                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                          fig.autoPublish
                            ? "bg-emerald-500/15 text-emerald-700"
                            : "bg-surface text-muted"
                        }`}
                      >
                        {fig.autoPublish ? "● نشر تلقائي مفعّل" : "متوقف"}
                      </span>
                    </div>

                    <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 border-t border-line/70 pt-2.5">
                      <button
                        type="button"
                        onClick={() => void handleFetchLatestPostForFigure(fig)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-primary-soft px-3 py-1.5 text-xs font-extrabold text-primary-ink hover:brightness-95"
                        title="جلب أحدث منشور لهذه الشخصية وإضافته فوراً لصفحة تواصل اجتماعي"
                      >
                        <span>🔄</span>
                        <span>جلب ونشر أحدث منشور الآن</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void handleToggleFigureAuto(fig.id)}
                          className="text-xs font-bold text-muted hover:text-ink underline"
                        >
                          {fig.autoPublish ? "تعطيل التلقائي" : "تفعيل التلقائي"}
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDeleteFigure(fig.id)}
                          className="text-xs font-bold text-rose-600 hover:text-rose-800"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: صفحة وقسم تواصل اجتماعي (المشاهير والسياسيون والتريند)
       * ===================================================================== */}
      {subTab === "vip-feed" ? (
        <div className="space-y-6">
          <div className="stamp p-5">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-line pb-4">
              <div>
                <h3 className="text-lg font-extrabold text-ink">
                  🌐 صفحة وقسم «تواصل اجتماعي · فيسبوك والتريند»
                </h3>
                <p className="mt-1 text-xs font-semibold text-muted">
                  عند تفعيل القسم، يصبح له صفحة مستقلة على الرابط `/social` ويُضاف تلقائياً إلى شريط
                  القوائم العلوي والسفلي والفوتر مع تصميم فيسبوك العصري المباشر.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    const nextVal = !vipEnabled;
                    setVipEnabled(nextVal);
                    void persistSocialHubSettings(
                      { vip: nextVal },
                      nextVal
                        ? "✅ تم تفعيل وإظهار صفحة تواصل اجتماعي في جميع القوائم!"
                        : "🔒 تم إخفاء صفحة تواصل اجتماعي عن الزوار.",
                    );
                  }}
                  className={`inline-flex items-center gap-2.5 rounded-2xl px-5 py-3 text-xs font-extrabold shadow-sm transition ${
                    vipEnabled
                      ? "bg-emerald-600 text-white hover:bg-emerald-700"
                      : "bg-primary text-[#111827] hover:bg-primary-hover"
                  }`}
                >
                  <span>{vipEnabled ? "✅ مفعّل ومضاف بالقوائم" : "🔒 مخفي حالياً — اضغط للتفعيل"}</span>
                </button>
              </div>
            </div>

            {/* Custom Post Form */}
            <div className="mt-4 rounded-2xl border border-line bg-surface/50 p-4">
              <h4 className="text-sm font-extrabold text-ink">
                ➕ نشر تغريدة أو منشور مخصص في صفحة تواصل اجتماعي:
              </h4>
              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <select
                  value={newPlatform}
                  onChange={(e) => setNewPlatform(e.target.value as "x" | "facebook")}
                  className="field text-xs font-bold"
                >
                  <option value="facebook">📘 منصة فيسبوك (قالب فيسبوك)</option>
                  <option value="x">𝕏 منصة إكس (تويتر)</option>
                </select>

                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as typeof newCategory)}
                  className="field text-xs font-bold"
                >
                  <option value="local">📍 شخصيات ومؤسسات رهط والنقب</option>
                  <option value="politicians">🏛️ سياسيون</option>
                  <option value="celebrities">⭐ مشاهير</option>
                  <option value="sports">⚽ رياضة</option>
                </select>

                <select
                  value={newOriginalLang}
                  onChange={(e) => setNewOriginalLang(e.target.value as "he" | "en" | "ar")}
                  className="field text-xs font-bold"
                >
                  <option value="ar">لغة المنشور: عربية</option>
                  <option value="he">لغة المنشور: عبرية (مع زر ترجمة)</option>
                  <option value="en">لغة المنشور: إنجليزية (مع زر ترجمة)</option>
                </select>
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <input
                  type="text"
                  value={newAuthorName}
                  onChange={(e) => setNewAuthorName(e.target.value)}
                  placeholder="الاسم (مثال: بلدية رهط / محمد صلاح)"
                  className="field text-xs font-bold"
                />
                <input
                  type="text"
                  dir="ltr"
                  value={newAuthorHandle}
                  onChange={(e) => setNewAuthorHandle(e.target.value)}
                  placeholder="@handle"
                  className="field text-xs font-bold"
                />
                <input
                  type="text"
                  value={newAuthorRole}
                  onChange={(e) => setNewAuthorRole(e.target.value)}
                  placeholder="الصفة / الدور"
                  className="field text-xs font-bold"
                />
              </div>

              <textarea
                rows={2}
                value={newOriginalText}
                onChange={(e) => setNewOriginalText(e.target.value)}
                placeholder="نص المنشور كما يظهر على فيسبوك أو إكس…"
                className="field mt-3 text-xs font-bold"
              />

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <textarea
                  rows={2}
                  value={newTranslatedAr}
                  onChange={(e) => setNewTranslatedAr(e.target.value)}
                  placeholder="الترجمة العربية الاختيارية…"
                  className="field text-xs font-bold sm:col-span-2"
                />
                <div className="flex flex-col gap-2">
                  <input
                    type="text"
                    value={newTrendTag}
                    onChange={(e) => setNewTrendTag(e.target.value)}
                    placeholder="هاشتاج التريند (#رهط_بوست)"
                    className="field text-xs font-bold"
                  />
                  <button
                    type="button"
                    disabled={busy}
                    onClick={async () => {
                      if (!newAuthorName.trim() || !newOriginalText.trim()) {
                        showToastMsg("يرجى إدخال اسم الشخصية ونص المنشور.");
                        return;
                      }
                      const newItem: SocialVipPostItem = {
                        id: `custom-${Date.now()}`,
                        platform: newPlatform,
                        authorName: newAuthorName.trim(),
                        authorHandle: newAuthorHandle.trim() || "@official",
                        authorRole: newAuthorRole.trim() || "شخصية عامة",
                        category: newCategory,
                        avatarUrl: makeAvatarSvgDataUri(newAuthorName.trim().slice(0, 2), "#1877F2"),
                        verified: "blue",
                        publishedAgo: "الآن",
                        originalLang: newOriginalLang,
                        originalText: newOriginalText.trim(),
                        translatedAr: newTranslatedAr.trim() || newOriginalText.trim(),
                        trendTag: newTrendTag.trim() || "#رهط_بوست",
                        likes: 180,
                        commentsCount: 24,
                        shares: 18,
                        views: "5.4K",
                        sampleComments: [],
                      };
                      const nextList = [newItem, ...customVipPosts].slice(0, 25);
                      const encoded = toBase64UrlSafe(JSON.stringify(nextList));
                      const otherLinks = (draft.quickLinks ?? []).filter((q) => q.id !== "socialvipcustom");
                      const nextDraft: SiteSettings = {
                        ...draft,
                        quickLinks: [
                          ...otherLinks,
                          {
                            id: "socialvipcustom",
                            title: `count:${nextList.length}`,
                            subtitle: encoded.slice(180) || "vip",
                            url: `/__svip?${encoded.slice(0, 180)}`,
                          },
                        ],
                      };
                      setDraft(nextDraft);
                      await saveNow(nextDraft, "تمت إضافة المنشور وحفظه في صفحة تواصل اجتماعي ✓");
                      setNewAuthorName("");
                      setNewOriginalText("");
                      setNewTranslatedAr("");
                      showToastMsg("تمت إضافة المنشور بنجاح ✓");
                    }}
                    className="btn min-h-10 text-xs"
                  >
                    ➕ إضافة وحفظ المنشور
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Live Admin Preview of Social Section */}
          <div className="space-y-2">
            <p className="text-xs font-extrabold text-muted">
              👁️ معاينة حية لقالب فيسبوك العصري كما يظهر للزوار:
            </p>
            <SocialVipFeedAndTrendsSection forceShowForAdminPreview />
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: ربط صفحة فيسبوك ونشر المقالات
       * ===================================================================== */}
      {subTab === "pages" ? (
        <div className="grid gap-6 lg:grid-cols-12">
          <div className="stamp space-y-4 p-5 lg:col-span-5">
            <div className="flex items-center gap-2.5 border-b border-line pb-3">
              <span className="grid size-10 place-items-center rounded-2xl bg-[#1877f2] text-lg font-black text-white">
                f
              </span>
              <div>
                <h3 className="text-base font-extrabold text-ink">
                  ربط صفحة رهط بوست على فيسبوك
                </h3>
                <p className="text-xs font-semibold text-muted">
                  ربط مباشر لنشر مقالات وأخبار الموقع على الصفحة
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <label className="block">
                <span className="mb-1 block text-xs font-extrabold text-ink">
                  اسم الصفحة على فيسبوك
                </span>
                <input
                  type="text"
                  value={fbPageName}
                  onChange={(e) => setFbPageName(e.target.value)}
                  className="field text-sm font-bold"
                  placeholder="رهط بوست - Rahat Post"
                />
              </label>

              <label className="block">
                <span className="mb-1 block text-xs font-extrabold text-ink">
                  رابط صفحة فيسبوك
                </span>
                <input
                  type="url"
                  dir="ltr"
                  value={fbPageUrl}
                  onChange={(e) => setFbPageUrl(e.target.value)}
                  className="field text-sm font-bold"
                />
              </label>

              <button
                type="button"
                disabled={busy}
                onClick={() => void persistSocialHubSettings()}
                className="btn w-full"
              >
                💾 حفظ إعدادات الصفحة
              </button>
            </div>
          </div>

          <div className="stamp space-y-4 p-5 lg:col-span-7">
            <h3 className="text-base font-extrabold text-ink">
              📰 مقالات الموقع الجاهزة للنشر على فيسبوك:
            </h3>
            {fbPostStatus ? (
              <p className="rounded-xl bg-sky-500/10 p-2.5 text-xs font-extrabold text-sky-800">
                {fbPostStatus}
              </p>
            ) : null}
            <div className="space-y-3">
              {sampleArticles.slice(0, 5).map((art, idx) => (
                <div key={idx} className="rounded-2xl border border-line bg-surface/60 p-3.5">
                  <span className="chip text-[10px]">{art.category}</span>
                  <h4 className="mt-1 text-sm font-extrabold text-ink">{art.title}</h4>
                  <div className="mt-3 flex gap-2">
                    <button
                      type="button"
                      onClick={() => void handlePublishToFacebookPage(art)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#1877f2] px-3 py-1.5 text-xs font-extrabold text-white"
                    >
                      📘 نشر على صفحة فيسبوك
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: استوديو الفيديو بالذكاء الاصطناعي (تيك توك · فيسبوك · إنستغرام)
       * ===================================================================== */}
      {subTab === "tiktok-ai" ? (
        <div className="grid gap-6 lg:grid-cols-12">
          {/* Controls & Configuration Panel */}
          <div className="stamp space-y-5 p-5 lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-3">
              <div>
                <h3 className="flex items-center gap-2 text-lg font-black text-ink">
                  <span>🎬</span>
                  <span>استوديو الفيديو الذكي AI</span>
                  <span className="rounded-full bg-primary/20 px-2.5 py-0.5 text-[11px] font-extrabold text-primary-deep">
                    تيك توك + ريلز فيسبوك وإنستغرام
                  </span>
                </h3>
                <p className="mt-0.5 text-xs font-bold text-ink-muted">
                  تحويل أحدث أخبار رهط والنقب إلى مقاطع فيديو عمودية متحركة (9:16) جاهزة للنشر الفوري.
                </p>
              </div>

              {/* Refresh News Button */}
              <button
                type="button"
                disabled={isFetchingArticles}
                onClick={() => void handleFetchFreshNews()}
                className="btn inline-flex items-center gap-1.5 border border-primary bg-primary/10 px-3 py-1.5 text-xs font-extrabold text-ink transition hover:bg-primary/20"
                title="جلب كل الأخبار الجديدة المنشورة في الموقع الآن"
              >
                <span>{isFetchingArticles ? "⏳" : "🔄"}</span>
                <span>{isFetchingArticles ? "جاري التحديث…" : "جلب الأخبار المنشورة الآن"}</span>
              </button>
            </div>

            {/* Target Platform Selector */}
            <div>
              <span className="mb-1.5 block text-xs font-extrabold text-ink">
                منصة النشر المستهدفة:
              </span>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {[
                  { id: "all", label: "🌐 كل المنصات", desc: "تيك توك + ريلز" },
                  { id: "tiktok", label: "🎵 تيك توك", desc: "TikTok Studio" },
                  { id: "facebook", label: "📘 فيسبوك ريلز", desc: "FB Reels" },
                  { id: "instagram", label: "📸 إنستغرام", desc: "Insta Reels" },
                ].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setVideoPlatform(p.id as typeof videoPlatform)}
                    className={`flex flex-col items-center justify-center rounded-xl border p-2 text-center transition ${
                      videoPlatform === p.id
                        ? "border-primary bg-primary/15 font-black text-ink shadow-sm"
                        : "border-line bg-surface font-bold text-ink-muted hover:border-ink/20"
                    }`}
                  >
                    <span className="text-xs">{p.label}</span>
                    <span className="text-[10px] opacity-75">{p.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Article Selector Dropdown */}
            <div>
              <div className="mb-1 flex items-center justify-between text-xs font-extrabold text-ink">
                <span>اختر خبراً منشوراً لتحويله إلى فيديو ({combinedArticles.length} خبر متاح):</span>
                {isFetchingArticles ? (
                  <span className="animate-pulse text-[11px] font-bold text-primary-deep">
                    جاري فحص جديد الموقع…
                  </span>
                ) : null}
              </div>
              <select
                value={selectedArticleIdx}
                onChange={(e) => {
                  const idx = Number(e.target.value);
                  setSelectedArticleIdx(idx);
                  const a = combinedArticles[idx];
                  if (a) {
                    setVideoHeadline(a.title);
                    setVideoSummary(a.summary);
                    setVideoBadge(a.category || "عاجل · رهط بوست");
                  }
                }}
                className="field text-xs font-extrabold"
              >
                {combinedArticles.map((a, i) => (
                  <option key={i} value={i}>
                    {i + 1}. [{a.category || "عام"}] {a.title.slice(0, 80)}
                  </option>
                ))}
              </select>
            </div>

            {/* Video Headline and Badge */}
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="sm:col-span-2">
                <label className="mb-1 block text-xs font-extrabold text-ink">
                  عنوان الخبر في الفيديو:
                </label>
                <textarea
                  rows={2}
                  value={videoHeadline}
                  onChange={(e) => setVideoHeadline(e.target.value)}
                  className="field text-xs font-extrabold"
                  placeholder="عنوان الخبر الرئيسي البارز..."
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-extrabold text-ink">شارة التصنيف:</label>
                <input
                  type="text"
                  value={videoBadge}
                  onChange={(e) => setVideoBadge(e.target.value)}
                  className="field text-xs font-extrabold"
                  placeholder="مثال: عاجل · أخبار رهط"
                />
              </div>
            </div>

            {/* Detailed Story Breakdown / Summary */}
            <div>
              <div className="mb-1 flex items-center justify-between text-xs font-extrabold text-ink">
                <span>تفاصيل الخبر والأنيميشن (تظهر كنقاط وموجز متحرك):</span>
                <span className="text-[11px] text-ink-muted">
                  سيتم تقسيمها تلقائياً إلى نقاط متحركة
                </span>
              </div>
              <textarea
                rows={3}
                value={videoSummary}
                onChange={(e) => setVideoSummary(e.target.value)}
                className="field text-xs font-bold leading-relaxed"
                placeholder="تفاصيل الخبر التي ستتحرك في المشهد وتظهر في الشريط الإخباري..."
              />
            </div>

            {/* Theme & Duration & Voice Options */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-extrabold text-ink">مظهر الفيديو:</label>
                <select
                  value={videoTheme}
                  onChange={(e) =>
                    setVideoTheme(
                      e.target.value as "breaking-red" | "gold-night" | "cyber-neon",
                    )
                  }
                  className="field text-xs font-extrabold"
                >
                  <option value="breaking-red">🔴 أحمر عاجل (Breaking Red)</option>
                  <option value="gold-night">🌙 ليلي ذهبي (Gold Night)</option>
                  <option value="cyber-neon">⚡ سايبر نيون (Cyber Neon)</option>
                </select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-extrabold text-ink">مدة الفيديو:</label>
                <select
                  value={videoDurationSec}
                  onChange={(e) => setVideoDurationSec(Number(e.target.value))}
                  className="field text-xs font-extrabold"
                >
                  <option value={8}>8 ثوانٍ (سريع وخاطف)</option>
                  <option value={12}>12 ثانية (مفصل وشامل - موصى به)</option>
                  <option value={16}>16 ثانية (تغطية موسعة)</option>
                </select>
              </div>

              <div className="col-span-2 flex flex-col justify-end sm:col-span-1">
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-line bg-surface p-2 text-xs font-extrabold text-ink">
                  <input
                    type="checkbox"
                    checked={withVoiceAndSound}
                    onChange={(e) => setWithVoiceAndSound(e.target.checked)}
                    className="accent-primary"
                  />
                  <span>🔊 نغمة وبث صوتي AI</span>
                </label>
              </div>
            </div>

            {/* Generate Video Action Button */}
            <button
              type="button"
              disabled={isGeneratingVideo}
              onClick={() => void handleGenerateAiTikTokVideo()}
              className="btn w-full bg-primary py-3 text-sm font-black text-[#111827] shadow-lg transition hover:brightness-105"
            >
              {isGeneratingVideo
                ? `⏳ جاري تسجيل ومعالجة الفيديو بالذكاء الاصطناعي (${videoProgress}%)…`
                : "🎬 توليد وصناعة فيديو 9:16 HD متحرك الآن"}
            </button>

            {/* Ready Video Actions & Direct Publishing Suite */}
            {generatedVideoUrl ? (
              <div className="space-y-3 rounded-2xl border-2 border-emerald-500/40 bg-emerald-500/10 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-3 w-3 animate-ping rounded-full bg-emerald-500" />
                    <span className="text-xs font-black text-emerald-800 dark:text-emerald-300">
                      تم تجهيز وتوليد الفيديو بنجاح! جاهز للتحميل والنشر المباشر:
                    </span>
                  </div>
                  <a
                    href={generatedVideoUrl}
                    download={`rahatpost-${Date.now()}.webm`}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-1.5 text-xs font-black text-white shadow transition hover:bg-emerald-700"
                  >
                    <span>⬇️</span>
                    <span>تحميل ملف الفيديو (9:16 HD)</span>
                  </a>
                </div>

                {/* Copy Captions & Hashtags Toolbar */}
                <div className="rounded-xl border border-line bg-surface/70 p-3">
                  <div className="mb-2 flex items-center justify-between text-xs font-black text-ink">
                    <span>📋 نسخ الوصف الترويجي والهاشتاجات المجهزة:</span>
                    {captionCopyNotice ? (
                      <span className="text-[11px] font-bold text-emerald-600">
                        {captionCopyNotice}
                      </span>
                    ) : null}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => handleCopyCaptions("tiktok")}
                      className="btn border border-line bg-surface px-2.5 py-1 text-xs font-extrabold text-ink hover:bg-white/20"
                    >
                      🎵 نسخ لهاشتاجات تيك توك
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopyCaptions("facebook")}
                      className="btn border border-line bg-surface px-2.5 py-1 text-xs font-extrabold text-ink hover:bg-white/20"
                    >
                      📘 نسخ لريلز فيسبوك
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopyCaptions("instagram")}
                      className="btn border border-line bg-surface px-2.5 py-1 text-xs font-extrabold text-ink hover:bg-white/20"
                    >
                      📸 نسخ لإنستغرام ريلز
                    </button>
                    <button
                      type="button"
                      onClick={() => handleCopyCaptions("all")}
                      className="btn border border-line bg-surface px-2.5 py-1 text-xs font-extrabold text-ink hover:bg-white/20"
                    >
                      🌐 نسخ شامل لكل المنصات
                    </button>
                  </div>
                </div>

                {/* Direct Platform Publishing Links */}
                <div>
                  <span className="mb-1.5 block text-xs font-black text-ink">
                    🚀 روابط النشر المباشر في المنصات:
                  </span>
                  <div className="grid gap-2 sm:grid-cols-3">
                    <a
                      href="https://www.tiktok.com/tiktokstudio/upload"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 rounded-xl border border-[#00f2fe]/40 bg-black/80 px-3 py-2 text-xs font-black text-white transition hover:bg-black"
                    >
                      <span>🎵</span>
                      <span>نشر على تيك توك ↗</span>
                    </a>

                    <a
                      href="https://www.facebook.com/reels/create"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 rounded-xl border border-[#1877F2]/40 bg-[#1877F2] px-3 py-2 text-xs font-black text-white transition hover:brightness-110"
                    >
                      <span>📘</span>
                      <span>نشر على فيسبوك ريلز ↗</span>
                    </a>

                    <a
                      href="https://business.facebook.com/creatorstudio"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 rounded-xl border border-[#E1306C]/40 bg-gradient-to-r from-[#833ab4] via-[#fd1d1d] to-[#fcb045] px-3 py-2 text-xs font-black text-white transition hover:brightness-110"
                    >
                      <span>📸</span>
                      <span>نشر على إنستغرام ريلز ↗</span>
                    </a>
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          {/* Real-time 9:16 Canvas Animation Stage */}
          <div className="stamp flex flex-col items-center justify-center p-5 lg:col-span-5">
            <div className="mb-2 flex w-full items-center justify-between px-2 text-xs font-black text-ink">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                <span>معاينة حية للأنيميشن (9:16)</span>
              </span>
              <span className="text-[11px] font-bold text-ink-muted">540 × 960 HD</span>
            </div>

            <canvas
              ref={canvasRef}
              width={540}
              height={960}
              className="h-[520px] w-[292px] rounded-2xl border-2 border-line bg-black shadow-2xl"
            />

            <div className="mt-3 flex w-full max-w-[292px] items-center justify-between text-[11px] font-extrabold text-ink-muted">
              <span>🔴 شريط ورادار إخباري متحرك</span>
              <span>{videoDurationSec} ثوانٍ</span>
            </div>
          </div>
        </div>
      ) : null}

      {/* =====================================================================
       * SUB-TAB: الطقس والأمان
       * ===================================================================== */}
      {subTab === "weather-security" ? (
        <div className="stamp space-y-4 p-5">
          <h3 className="text-lg font-extrabold text-ink">
            🌧️ أنيميشن ومظهر الطقس وأوقات الصلاة في رهط
          </h3>
          <div className="flex flex-wrap gap-2">
            {(
              [
                { id: "scene-animated", label: "🌧️ المشهد الجوي المتحرك بالأمطار" },
                { id: "mosque-gold", label: "🕌 المظهر الذهبي الفاخر" },
                { id: "glass-modern", label: "✨ المظهر الزجاجي الشفاف" },
                { id: "night-radar", label: "📊 الرادار الليلي" },
              ] as { id: WeatherPrayerVisualStyle; label: string }[]
            ).map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => void persistWeatherStyle(st.id, weatherCfg.fx)}
                className={`rounded-xl border px-3.5 py-2 text-xs font-extrabold transition ${
                  weatherCfg.style === st.id
                    ? "bg-primary text-[#111827] border-primary-deep"
                    : "bg-surface text-ink border-line"
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function drawAiTikTokFrame(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  opts: {
    headline: string;
    summary: string;
    badge: string;
    theme: "breaking-red" | "gold-night" | "cyber-neon";
    tiktokHandle: string;
    elapsedSec: number;
    totalSec: number;
    platform?: "all" | "tiktok" | "facebook" | "instagram";
  },
) {
  const { headline, summary, badge, theme, tiktokHandle, elapsedSec, totalSec, platform = "all" } = opts;
  const progress = Math.min(1, Math.max(0, elapsedSec / Math.max(1, totalSec)));

  // Dynamic Background Gradient
  const grad = ctx.createLinearGradient(0, 0, w, h);
  if (theme === "breaking-red") {
    grad.addColorStop(0, "#1c0404");
    grad.addColorStop(0.35, "#3b0808");
    grad.addColorStop(0.75, "#180606");
    grad.addColorStop(1, "#09090b");
  } else if (theme === "cyber-neon") {
    grad.addColorStop(0, "#030f1e");
    grad.addColorStop(0.4, "#06233d");
    grad.addColorStop(0.8, "#041427");
    grad.addColorStop(1, "#020710");
  } else {
    // gold-night
    grad.addColorStop(0, "#080c16");
    grad.addColorStop(0.35, "#131b2e");
    grad.addColorStop(0.75, "#0b1120");
    grad.addColorStop(1, "#030712");
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Subtle Animated Particle Grid / Scan Lines
  const scanY = (elapsedSec * 60) % h;
  ctx.fillStyle = "rgba(255, 255, 255, 0.025)";
  for (let y = 0; y < h; y += 40) {
    ctx.fillRect(0, y, w, 1);
  }
  // Moving scanline light sweep
  const sweepGrad = ctx.createLinearGradient(0, scanY - 30, 0, scanY + 30);
  sweepGrad.addColorStop(0, "rgba(242, 201, 76, 0)");
  sweepGrad.addColorStop(0.5, "rgba(242, 201, 76, 0.08)");
  sweepGrad.addColorStop(1, "rgba(242, 201, 76, 0)");
  ctx.fillStyle = sweepGrad;
  ctx.fillRect(0, scanY - 30, w, 60);

  // =========================================================================
  // Top Header Bar: Rahat Post Brand + Live Jerusalem Clock + Soundwaves
  // =========================================================================
  ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
  ctx.fillRect(24, 38, w - 48, 86);
  ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(24, 38, w - 48, 86);

  // Logo Badge Box (Gold)
  ctx.fillStyle = "#f2c94c";
  ctx.fillRect(w - 96, 48, 58, 66);
  ctx.fillStyle = "#111827";
  ctx.font = "900 20px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("رهط", w - 67, 76);
  ctx.font = "800 13px sans-serif";
  ctx.fillText("بوست", w - 67, 98);

  // Brand Name & Social Handles
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "right";
  ctx.font = "900 20px sans-serif";
  ctx.fillText("منصة وتطبيق رهط بوست الإخبارية", w - 110, 74);

  // Subtitle / Handle
  ctx.fillStyle = "#cbd5e1";
  ctx.font = "700 13px sans-serif";
  const platformLabel =
    platform === "tiktok"
      ? `تيك توك: ${tiktokHandle}`
      : platform === "facebook"
      ? "فيسبوك: رهط بوست - Rahat Post"
      : platform === "instagram"
      ? "إنستغرام: @rahatpost"
      : `RAHATPOST.COM · ${tiktokHandle}`;
  ctx.fillText(platformLabel, w - 110, 96);

  // Live Pulse Dot & Jerusalem Clock
  const isPulsing = Math.sin(elapsedSec * 5) > 0;
  ctx.beginPath();
  ctx.arc(46, 68, 6, 0, Math.PI * 2);
  ctx.fillStyle = isPulsing ? "#ef4444" : "#991b1b";
  ctx.fill();

  ctx.fillStyle = "#ef4444";
  ctx.font = "900 12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("بث حي مباشر", 58, 72);

  // Live time ticker string
  const jerusalemSecs = Math.floor(elapsedSec);
  const timeStr = `16:04:${(jerusalemSecs % 60).toString().padStart(2, "0")} توقيت القدس`;
  ctx.fillStyle = "#94a3b8";
  ctx.font = "700 11px sans-serif";
  ctx.fillText(timeStr, 40, 96);

  // Audio Equalizer Waveform Bars (14 animated bars)
  for (let b = 0; b < 14; b++) {
    const barH = 4 + Math.abs(Math.sin(elapsedSec * 6 + b * 0.7)) * 14;
    ctx.fillStyle = theme === "breaking-red" ? "#ef4444" : "#f2c94c";
    ctx.fillRect(170 + b * 6, 104 - barH, 4, barH);
  }

  // =========================================================================
  // ANIMATION PHASES
  // Phase 1 (0.0s – 2.5s): Animated Radar Beacon + Breaking Alert
  // Phase 2 (2.5s – 6.5s): Kinetic Headline Zoom-In + Category Card
  // Phase 3 (6.5s – 10.5s): Detailed Story Breakdown (Bullets) + Bottom Ticker
  // Phase 4 (10.5s – end): Multi-Platform Social Outro
  // =========================================================================

  if (elapsedSec < 2.5) {
    // -----------------------------------------------------------------------
    // PHASE 1: Breaking Alert & Radar Beacon
    // -----------------------------------------------------------------------
    const p1Progress = elapsedSec / 2.5;

    // Glowing Radar Beacon Pulse
    const centerX = w / 2;
    const centerY = 330;
    const pulseCount = 3;
    for (let i = 0; i < pulseCount; i++) {
      const phaseOffset = (elapsedSec * 1.4 + i / pulseCount) % 1;
      const r = 25 + phaseOffset * 130;
      const alpha = (1 - phaseOffset) * 0.75;
      ctx.beginPath();
      ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
      ctx.strokeStyle =
        theme === "breaking-red"
          ? `rgba(239, 68, 68, ${alpha})`
          : `rgba(242, 201, 76, ${alpha})`;
      ctx.lineWidth = 3.5;
      ctx.stroke();
    }

    // Center Core Beacon
    ctx.beginPath();
    ctx.arc(centerX, centerY, 24, 0, Math.PI * 2);
    ctx.fillStyle = theme === "breaking-red" ? "#ef4444" : "#f2c94c";
    ctx.fill();
    ctx.beginPath();
    ctx.arc(centerX, centerY, 12, 0, Math.PI * 2);
    ctx.fillStyle = "#ffffff";
    ctx.fill();

    // Alert Banner Title
    ctx.fillStyle = "#ffffff";
    ctx.font = "900 32px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("🚨 تنبيه إخباري عاجل", centerX, 520);

    ctx.fillStyle = "#fde68a";
    ctx.font = "800 22px sans-serif";
    ctx.fillText("رصد ومتابعة لأهم أحداث الساعة", centerX, 565);

    // Category Pill
    ctx.fillStyle = "rgba(242, 201, 76, 0.15)";
    ctx.fillRect((w - 280) / 2, 620, 280, 48);
    ctx.strokeStyle = "#f2c94c";
    ctx.lineWidth = 2;
    ctx.strokeRect((w - 280) / 2, 620, 280, 48);
    ctx.fillStyle = "#ffffff";
    ctx.font = "800 20px sans-serif";
    ctx.fillText(`📍 ${badge}`, centerX, 652);

    // Initial Headline Preview (Fading in)
    const previewAlpha = Math.min(1, p1Progress * 1.5);
    ctx.fillStyle = `rgba(255, 255, 255, ${previewAlpha})`;
    ctx.font = "900 22px sans-serif";
    const headWords = headline.split(" ");
    ctx.fillText(headWords.slice(0, 6).join(" "), centerX, 740);
  } else if (elapsedSec < 6.5) {
    // -----------------------------------------------------------------------
    // PHASE 2: Kinetic Headline Zoom-in & Glass Card
    // -----------------------------------------------------------------------
    const p2Progress = Math.min(1, (elapsedSec - 2.5) / 1.0);
    const cardScale = 0.92 + p2Progress * 0.08;
    const cardAlpha = Math.min(1, p2Progress * 1.3);

    ctx.save();
    ctx.translate(w / 2, 420);
    ctx.scale(cardScale, cardScale);
    ctx.translate(-w / 2, -420);

    // Glass Card for Headline
    const cardX = 32;
    const cardY = 160;
    const cardW = w - 64;
    const cardH = 460;

    ctx.fillStyle = `rgba(15, 23, 42, ${0.9 * cardAlpha})`;
    ctx.fillRect(cardX, cardY, cardW, cardH);
    ctx.strokeStyle =
      theme === "breaking-red"
        ? `rgba(239, 68, 68, ${0.8 * cardAlpha})`
        : `rgba(242, 201, 76, ${0.8 * cardAlpha})`;
    ctx.lineWidth = 3;
    ctx.strokeRect(cardX, cardY, cardW, cardH);

    // Top Category Pill
    ctx.fillStyle = theme === "breaking-red" ? "#dc2626" : "#f2c94c";
    ctx.fillRect(cardX + 24, cardY - 20, 240, 42);
    ctx.fillStyle = theme === "breaking-red" ? "#ffffff" : "#111827";
    ctx.font = "900 18px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`⚡ ${badge}`, cardX + 144, cardY + 7);

    // Animated Accent Line
    const accentW = Math.min(cardW - 48, (elapsedSec - 2.5) * 160);
    ctx.fillStyle = theme === "breaking-red" ? "#ef4444" : "#f2c94c";
    ctx.fillRect(cardX + 24, cardY + 44, accentW, 4);

    // Headline Text (Multi-line wrap)
    ctx.fillStyle = "#ffffff";
    ctx.font = "900 28px sans-serif";
    ctx.textAlign = "center";

    const words = headline.split(" ");
    const lines: string[] = [];
    let currentLine = "";
    for (const wd of words) {
      const testLine = currentLine ? `${currentLine} ${wd}` : wd;
      if (testLine.length > 24) {
        lines.push(currentLine);
        currentLine = wd;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);

    lines.slice(0, 4).forEach((ln, idx) => {
      ctx.fillText(ln, w / 2, cardY + 110 + idx * 46);
    });

    // Summary teaser at the bottom of the card
    ctx.fillStyle = "#fde68a";
    ctx.font = "700 20px sans-serif";
    const sumWords = summary.split(" ");
    ctx.fillText(sumWords.slice(0, 7).join(" "), w / 2, cardY + 340);
    if (sumWords.length > 7) {
      ctx.fillText(sumWords.slice(7, 14).join(" "), w / 2, cardY + 375);
    }

    ctx.restore();
  } else if (elapsedSec < 10.5) {
    // -----------------------------------------------------------------------
    // PHASE 3: Detailed Story Breakdown (Animated Bullets) + Bottom Ticker
    // -----------------------------------------------------------------------
    // Headline Compact Header Card
    ctx.fillStyle = "rgba(15, 23, 42, 0.92)";
    ctx.fillRect(28, 145, w - 56, 120);
    ctx.strokeStyle = theme === "breaking-red" ? "#ef4444" : "#f2c94c";
    ctx.lineWidth = 2;
    ctx.strokeRect(28, 145, w - 56, 120);

    ctx.fillStyle = "#f2c94c";
    ctx.font = "800 15px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(`⚡ ${badge} · التفاصيل الكاملة:`, w - 48, 175);

    ctx.fillStyle = "#ffffff";
    ctx.font = "900 21px sans-serif";
    const headWords = headline.split(" ");
    ctx.fillText(headWords.slice(0, 7).join(" "), w - 48, 210);
    if (headWords.length > 7) {
      ctx.fillText(headWords.slice(7, 14).join(" "), w - 48, 240);
    }

    // 3 Detailed Breakdown Bullets
    const sumParts = summary.split(/[،.]/).filter((s) => s.trim().length > 3);
    const bullets = [
      sumParts[0] || summary.slice(0, 50),
      sumParts[1] || "متابعة ميدانية حية وتغطية متواصلة لأهم المستجدات والتطورات.",
      sumParts[2] || "طواقم رهط بوست تواصل رصد الأحداث ونقل التفاصيل أولاً بأول.",
    ];

    bullets.forEach((bulletText, bIdx) => {
      const appearSec = 6.5 + bIdx * 0.9;
      if (elapsedSec >= appearSec) {
        const bulletAlpha = Math.min(1, (elapsedSec - appearSec) * 2.5);
        const bulletY = 285 + bIdx * 140;

        ctx.fillStyle = `rgba(30, 41, 59, ${0.85 * bulletAlpha})`;
        ctx.fillRect(32, bulletY, w - 64, 120);
        ctx.strokeStyle = `rgba(242, 201, 76, ${0.6 * bulletAlpha})`;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(32, bulletY, w - 64, 120);

        // Icon box
        ctx.fillStyle = "#f2c94c";
        ctx.fillRect(w - 76, bulletY + 14, 30, 30);
        ctx.fillStyle = "#111827";
        ctx.font = "900 16px sans-serif";
        ctx.textAlign = "center";
        ctx.fillText(`${bIdx + 1}`, w - 61, bulletY + 35);

        // Bullet Title
        ctx.fillStyle = "#fde68a";
        ctx.font = "900 17px sans-serif";
        ctx.textAlign = "right";
        const titleLabel =
          bIdx === 0 ? "أبرز تفاصيل الحدث:" : bIdx === 1 ? "المتابعة الميدانية والتطورات:" : "المستجدات والتغطية:";
        ctx.fillText(titleLabel, w - 88, bulletY + 36);

        // Bullet Body Text (2 lines)
        ctx.fillStyle = "#ffffff";
        ctx.font = "700 17px sans-serif";
        const bWords = bulletText.trim().split(" ");
        ctx.fillText(bWords.slice(0, 6).join(" "), w - 50, bulletY + 70);
        if (bWords.length > 6) {
          ctx.fillText(bWords.slice(6, 13).join(" "), w - 50, bulletY + 98);
        }
      }
    });

    // Scrolling News Ticker Tape at Bottom
    ctx.fillStyle = "#111827";
    ctx.fillRect(0, 770, w, 44);
    ctx.fillStyle = "#ef4444";
    ctx.fillRect(w - 110, 770, 110, 44);
    ctx.fillStyle = "#ffffff";
    ctx.font = "900 15px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("شريط عاجل 🔴", w - 55, 798);

    // Ticker moving text
    const tickerMsg = `📰 أخبار رهط والنقب · ${headline} · تفاصيل إضافية وتحديثات مستمرة عبر الموقع والتطبيق · www.rahatpost.com`;
    const tickerX = w - 120 - ((elapsedSec - 6.5) * 80) % (w + 400);
    ctx.fillStyle = "#fde68a";
    ctx.font = "700 16px sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(tickerMsg, tickerX, 798);
  } else {
    // -----------------------------------------------------------------------
    // PHASE 4: Multi-Platform Social Outro & Call to Action
    // -----------------------------------------------------------------------
    const p4Progress = Math.min(1, (elapsedSec - 10.5) / 0.8);

    ctx.save();
    ctx.globalAlpha = p4Progress;

    // Outro Main Card
    const outroY = 160;
    ctx.fillStyle = "rgba(15, 23, 42, 0.95)";
    ctx.fillRect(32, outroY, w - 64, 600);
    ctx.strokeStyle = "#f2c94c";
    ctx.lineWidth = 3;
    ctx.strokeRect(32, outroY, w - 64, 600);

    // Big Logo
    ctx.fillStyle = "#f2c94c";
    ctx.fillRect(w / 2 - 45, outroY + 30, 90, 80);
    ctx.fillStyle = "#111827";
    ctx.font = "900 28px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("رهط", w / 2, outroY + 68);
    ctx.font = "800 18px sans-serif";
    ctx.fillText("بوست", w / 2, outroY + 98);

    ctx.fillStyle = "#ffffff";
    ctx.font = "900 26px sans-serif";
    ctx.fillText("تابعوا منصة وتطبيق رهط بوست", w / 2, outroY + 160);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "700 16px sans-serif";
    ctx.fillText("صوت رهط والنقب الصادق على مدار 24 ساعة", w / 2, outroY + 195);

    // 4 Social Platform Rows
    const platforms = [
      { name: "تيك توك (TikTok)", handle: tiktokHandle || "@rahatpost", color: "#00f2fe", icon: "🎵" },
      { name: "فيسبوك (Facebook)", handle: "رهط بوست - Rahat Post", color: "#1877F2", icon: "📘" },
      { name: "إنستغرام (Instagram)", handle: "@rahatpost", color: "#E1306C", icon: "📸" },
      { name: "الموقع الرسمي والتطبيق", handle: "www.rahatpost.com", color: "#f2c94c", icon: "🌐" },
    ];

    platforms.forEach((p, idx) => {
      const rowY = outroY + 230 + idx * 68;
      ctx.fillStyle = "rgba(255, 255, 255, 0.06)";
      ctx.fillRect(48, rowY, w - 96, 54);
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(48, rowY, w - 96, 54);

      ctx.fillStyle = p.color;
      ctx.font = "900 20px sans-serif";
      ctx.textAlign = "right";
      ctx.fillText(p.icon, w - 66, rowY + 34);

      ctx.fillStyle = "#ffffff";
      ctx.font = "900 16px sans-serif";
      ctx.fillText(p.name, w - 100, rowY + 34);

      ctx.fillStyle = p.color;
      ctx.font = "800 15px sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(p.handle, 62, rowY + 34);
    });

    // Call to action button box
    ctx.fillStyle = "#f2c94c";
    ctx.fillRect(60, outroY + 520, w - 120, 52);
    ctx.fillStyle = "#111827";
    ctx.font = "900 20px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("🔔 اشترك الآن ليصلك كل جديد!", w / 2, outroY + 553);

    ctx.restore();
  }

  // =========================================================================
  // Bottom Elapsed Time Progress Bar
  // =========================================================================
  const barY = 910;
  const barW = w - 64;
  ctx.fillStyle = "rgba(255, 255, 255, 0.18)";
  ctx.fillRect(32, barY, barW, 12);

  const fillW = Math.max(16, barW * progress);
  ctx.fillStyle = theme === "breaking-red" ? "#ef4444" : "#f2c94c";
  ctx.fillRect(32, barY, fillW, 12);

  // Time indicator text
  ctx.fillStyle = "#cbd5e1";
  ctx.font = "700 12px sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(`${elapsedSec.toFixed(1)}s / ${totalSec}s`, 34, barY + 30);

  ctx.textAlign = "right";
  ctx.fillText("RAHAT POST AI BROADCAST", w - 34, barY + 30);
}

