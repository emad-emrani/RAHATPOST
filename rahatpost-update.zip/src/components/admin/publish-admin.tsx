import { useCallback, useEffect, useState } from "react";
import { compress } from "@/components/photo-picker";
import { mediaUrl } from "@/lib/media/types";
import { newsCategories } from "@/lib/news/types";
import { adminListSections } from "@/lib/news/auto-admin";
import { adminSaveStaffNews, adminListStaffNews, adminUpdateStaffNews } from "@/lib/staff-news/api";
import { extractYoutubeId, type StaffNews, type StaffPostType } from "@/lib/staff-news/types";
import { tr, trv } from "@/lib/i18n/core";

function previewEmbedUrl(rawUrl: string): { kind: "video" | "iframe"; src: string } | null {
  const u = rawUrl.trim();
  if (!u) return null;
  if (/\.(mp4|webm|ogg|m3u8)(\?|$)/i.test(u) || u.startsWith("/media/")) {
    return { kind: "video", src: u };
  }
  const ytId = extractYoutubeId(u);
  if (ytId) {
    return { kind: "iframe", src: `https://www.youtube.com/embed/${ytId}?rel=0&playsinline=1` };
  }
  if (/facebook\.com|fb\.watch/i.test(u)) {
    return {
      kind: "iframe",
      src: `https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(u)}&show_text=false&width=640`,
    };
  }
  const tt = u.match(/tiktok\.com\/.*\/video\/(\d+)/i);
  if (tt) {
    return { kind: "iframe", src: `https://www.tiktok.com/embed/v2/${tt[1]}` };
  }
  if (/^https?:\/\//i.test(u)) {
    return { kind: "iframe", src: u };
  }
  return null;
}

/** «نشر مقال / فيديو / بث مباشر» مع إمكانية تثبيت المقال في أعلى الموقع */
export function PublishAdmin() {
  const [items, setItems] = useState<StaffNews[] | null>(null);
  const [categories, setCategories] = useState<string[]>([
    ...newsCategories,
    "أخبار محلية",
    "فيديو",
    "بث مباشر",
  ]);
  const [postType, setPostType] = useState<StaffPostType>("article");
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>(newsCategories[0]);
  const [videoUrl, setVideoUrl] = useState("");
  const [body, setBody] = useState("");
  const [pinned, setPinned] = useState(false);
  const [breaking, setBreaking] = useState(false);
  const [imageKey, setImageKey] = useState("");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState("");
  const [msg, setMsg] = useState("");
  const [editId, setEditId] = useState("");
  const [filterType, setFilterType] = useState<"all" | "pinned" | "video" | "live">("all");

  const refresh = useCallback(async () => {
    const [res, secs] = await Promise.all([
      adminListStaffNews(),
      adminListSections().catch(() => ({ authed: false, sections: [] })),
    ]);
    setItems(res.items);
    if (secs.authed && secs.sections.length) {
      const merged = Array.from(
        new Set([
          ...newsCategories,
          "أخبار محلية",
          "فيديو",
          "بث مباشر",
          ...secs.sections.map((s) => s.name.trim()).filter(Boolean),
        ]),
      );
      setCategories(merged);
    }
    if (!res.authed) setMsg(tr("انتهت الجلسة. سجّل الدخول من جديد."));
    else if (!res.ok) setMsg(tr("تعذّر تحميل المقالات المنشورة."));
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const upload = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return setMsg(tr("اختر ملف صورة."));
    setUploading(true);
    setMsg("");
    try {
      const blob = await compress(file);
      const res = await fetch("/api/media?kind=staff", {
        method: "POST",
        headers: { "content-type": blob.type },
        body: blob,
        credentials: "same-origin",
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        key?: string;
        message?: string;
      };
      if (!res.ok || !data.ok || !data.key) throw new Error(data.message || tr("تعذّر رفع الصورة."));
      setImageKey(data.key);
    } catch (err) {
      setMsg(err instanceof Error ? err.message : tr("تعذّر رفع الصورة."));
    } finally {
      setUploading(false);
    }
  };

  const publish = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg("");
    try {
      const res = await adminSaveStaffNews({
        data: {
          title,
          category,
          body,
          imageKey,
          breaking,
          postType,
          videoUrl: videoUrl.trim(),
          pinned,
          ...(editId ? { id: editId } : {}),
        },
      });
      if (!res.ok) return setMsg(res.message || tr("تعذّر النشر."));
      setTitle("");
      setBody("");
      setVideoUrl("");
      setPinned(false);
      setBreaking(false);
      setImageKey("");
      setEditId("");
      setMsg(
        editId
          ? tr("✓ تم حفظ تعديل المنشور بنجاح!")
          : postType === "live"
            ? tr("✓ تم نشر البث المباشر بنجاح!")
            : postType === "video"
              ? tr("✓ تم نشر الفيديو بنجاح!")
              : tr("✓ تم نشر المقال بنجاح!"),
      );
      await refresh();
    } catch {
      setMsg(tr("تعذّر النشر. حاول مرة أخرى."));
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (n: StaffNews | null) => {
    setEditId(n?.id ?? "");
    setPostType(n?.postType ?? "article");
    setTitle(n?.title ?? "");
    setCategory(n?.category ?? categories[0]);
    setVideoUrl(n?.videoUrl ?? "");
    setBody(n?.body ?? "");
    setImageKey(n?.imageKey ?? "");
    setPinned(Boolean(n?.pinned));
    setBreaking(Boolean(n?.breaking));
    setMsg("");
    if (n) window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const act = async (
    id: string,
    action: "delete" | "breaking-on" | "breaking-off" | "pin-on" | "pin-off",
  ) => {
    if (action === "delete" && !confirm(tr("حذف هذا المنشور نهائياً؟"))) return;
    setBusyId(id);
    try {
      const res = await adminUpdateStaffNews({ data: { id, action } });
      if (!res.ok) setMsg(tr("تعذّر تنفيذ العملية."));
      else if (action === "pin-on") setMsg(tr("📌 تم تثبيت المقال في أعلى الموقع!"));
      else if (action === "pin-off") setMsg(tr("تم إلغاء تثبيت المقال."));
      await refresh();
    } finally {
      setBusyId("");
    }
  };

  const embedPreview = previewEmbedUrl(videoUrl);
  const ytThumb = extractYoutubeId(videoUrl)
    ? `https://i.ytimg.com/vi/${extractYoutubeId(videoUrl)}/hqdefault.jpg`
    : "";

  const visibleItems = (items ?? []).filter((n) => {
    if (filterType === "pinned") return Boolean(n.pinned);
    if (filterType === "video") return n.postType === "video";
    if (filterType === "live") return n.postType === "live";
    return true;
  });

  return (
    <div className="space-y-5">
      <form
        className="stamp border-2 border-primary bg-paper p-4 sm:p-6 shadow-xs flex flex-col gap-4"
        onSubmit={publish}
      >
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-3">
          <div>
            <h2 className="text-lg font-extrabold text-ink sm:text-xl">
              {editId
                ? tr("✏️ تعديل المنشور")
                : tr("✍️ نشر مقال جديد أو فيديو أو بث مباشر")}
            </h2>
            <p className="mt-0.5 text-xs font-semibold text-muted">
              {tr("اختر نوع المنشور (مقال، فيديو، أو بث مباشر)، ويمكنك تثبيته ليظهر في أول الموقع.")}
            </p>
          </div>
          {editId ? (
            <button
              type="button"
              className="btn btn-ghost py-1.5 px-3 text-xs font-extrabold"
              onClick={() => startEdit(null)}
            >
              {tr("إلغاء التعديل")}
            </button>
          ) : null}
        </div>

        {/* 1. Post Type Selector (Article / Video / Live Stream) */}
        <div className="grid grid-cols-3 gap-2.5">
          {[
            {
              id: "article" as const,
              icon: "📰",
              label: "نشر مقال",
              sub: "خبر أو مقال مصور",
              activeCls: "border-2 border-ink bg-primary text-ink",
            },
            {
              id: "video" as const,
              icon: "🎬",
              label: "نشر فيديو",
              sub: "يوتيوب، فيسبوك، تيك توك، MP4",
              activeCls: "border-2 border-ink bg-ink text-primary",
            },
            {
              id: "live" as const,
              icon: "🔴",
              label: "نشر بث مباشر",
              sub: "بث حي مباشر بشارة حمراء",
              activeCls: "border-2 border-[#DC2626] bg-[#DC2626] text-white",
            },
          ].map((t) => {
            const active = postType === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setPostType(t.id);
                  if (t.id === "live" && categories.includes("بث مباشر")) {
                    setCategory("بث مباشر");
                  } else if (t.id === "video" && categories.includes("فيديو")) {
                    setCategory("فيديو");
                  }
                }}
                className={`press flex flex-col items-center justify-center rounded-2xl border p-3 text-center transition ${
                  active
                    ? t.activeCls
                    : "border-line bg-surface/60 text-ink hover:border-primary hover:bg-paper"
                }`}
              >
                <span className="text-2xl leading-none">{t.icon}</span>
                <span className="mt-1.5 text-xs font-extrabold sm:text-sm">{tr(t.label)}</span>
                <span className="mt-0.5 hidden text-[10.5px] font-semibold opacity-80 sm:block">
                  {tr(t.sub)}
                </span>
              </button>
            );
          })}
        </div>

        {/* 2. Title & Category */}
        <div className="grid gap-3 sm:grid-cols-3">
          <label className="block font-bold sm:col-span-2">
            {postType === "live"
              ? tr("عنوان البث المباشر *")
              : postType === "video"
                ? tr("عنوان الفيديو *")
                : tr("عنوان المقال *")}
            <input
              className="field mt-1"
              value={title}
              maxLength={160}
              required
              placeholder={
                postType === "live"
                  ? tr("مثال: بث مباشر من مدينة رهط — تغطية خاصة...")
                  : postType === "video"
                    ? tr("مثال: شاهد بالفيديو: جولة ميدانية في رهط...")
                    : tr("اكتب عنوان المقال أو الخبر...")
              }
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>

          <label className="block font-bold">
            {tr("القسم / التصنيف")}
            <select
              className="field mt-1"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {trv(c)}
                </option>
              ))}
            </select>
          </label>
        </div>

        {/* 3. Video / Live Stream Link Input */}
        <div
          className={`rounded-2xl border p-3.5 space-y-2.5 ${
            postType === "live"
              ? "border-2 border-[#DC2626]/60 bg-[#DC2626]/5"
              : postType === "video"
                ? "border-2 border-primary bg-primary-soft/35"
                : "border-line bg-surface/40"
          }`}
        >
          <label className="block text-sm font-extrabold text-ink">
            {postType === "live"
              ? "🔴 " + tr("رابط البث المباشر * (يوتيوب مباشر، فيسبوك لايف، أو رابط البث)")
              : postType === "video"
                ? "🎬 " + tr("رابط الفيديو * (يوتيوب، فيسبوك، تيك توك، أو رابط ملف MP4)")
                : "🎬 " + tr("إرفاق رابط فيديو أو بث مباشر داخل المقال (اختياري)")}
            <input
              type="url"
              dir="ltr"
              className="field mt-1.5 bg-paper text-sm"
              value={videoUrl}
              required={postType === "video" || postType === "live"}
              placeholder="https://www.youtube.com/watch?v=... أو https://www.facebook.com/..."
              onChange={(e) => setVideoUrl(e.target.value)}
            />
          </label>

          {embedPreview ? (
            <div className="overflow-hidden rounded-xl border border-line bg-black">
              <div className="flex items-center justify-between bg-ink px-3 py-1.5 text-[11px] font-bold text-paper">
                <span>
                  {postType === "live" ? "🔴 معاينة البث المباشر" : "🎬 معاينة مشغّل الفيديو"}
                </span>
                {ytThumb && !imageKey ? (
                  <span className="text-primary">✓ تم جلب صورة غلاف الفيديو تلقائياً</span>
                ) : null}
              </div>
              <div className="aspect-video max-h-60 w-full bg-black">
                {embedPreview.kind === "video" ? (
                  <video src={embedPreview.src} controls className="h-full w-full object-contain" />
                ) : (
                  <iframe
                    src={embedPreview.src}
                    title="preview"
                    className="h-full w-full border-0"
                    allowFullScreen
                  />
                )}
              </div>
            </div>
          ) : null}
        </div>

        {/* 4. Article Body / Video Description */}
        <label className="block font-bold">
          {postType === "article"
            ? tr("نص المقال الكامل *")
            : tr("وصف وتفاصيل إضافية (اختياري — يظهر أسفل مشغّل الفيديو أو البث)")}
          <textarea
            className="field mt-1 min-h-36"
            value={body}
            maxLength={8000}
            required={postType === "article"}
            placeholder={
              postType === "article"
                ? tr("اكتب تفاصيل المقال (افصل بين الفقرات بسطر فارغ)...")
                : tr("اكتب نبذة عن الفيديو أو البث المباشر (اختياري)...")
            }
            onChange={(e) => setBody(e.target.value)}
          />
        </label>

        {/* 5. Cover Image Upload */}
        <div className="rounded-2xl border border-line bg-surface/40 p-3.5 space-y-2">
          <label className="block text-sm font-bold">
            🖼️{" "}
            {postType === "article"
              ? tr("صورة المقال (اختياري)")
              : tr("صورة غلاف مخصصة للفيديو/البث (اختياري — يتم استخدام صورة يوتيوب تلقائياً إن تُركت فارغة)")}
            <input
              type="file"
              accept="image/*"
              className="field mt-1.5 bg-paper"
              disabled={uploading}
              onChange={(e) => upload(e.target.files?.[0])}
            />
          </label>
          {uploading ? (
            <p className="text-xs font-extrabold text-primary-ink">{tr("جاري رفع الصورة…")}</p>
          ) : null}
          {imageKey ? (
            <div className="flex items-center gap-3 pt-1">
              <img
                src={mediaUrl(imageKey)}
                alt=""
                className="size-16 rounded-xl border border-line object-cover"
              />
              <span className="chip">{tr("تم رفع الصورة ✓")}</span>
              <button
                type="button"
                className="btn btn-ghost py-1.5 px-3 text-xs"
                onClick={() => setImageKey("")}
              >
                {tr("إزالة الصورة")}
              </button>
            </div>
          ) : null}
        </div>

        {/* 6. Pin Article & Breaking News Toggles */}
        <div className="grid gap-3 sm:grid-cols-2">
          <label
            className={`flex cursor-pointer items-center gap-3 rounded-2xl border-2 p-3.5 transition ${
              pinned
                ? "border-ink bg-primary/30 text-ink shadow-2xs"
                : "border-line bg-surface/50 text-ink hover:border-primary"
            }`}
          >
            <input
              type="checkbox"
              className="size-5 accent-ink"
              checked={pinned}
              onChange={(e) => setPinned(e.target.checked)}
            />
            <div>
              <span className="block text-sm font-extrabold">
                📌 {tr("تثبيت المقال في أعلى الموقع")}
              </span>
              <span className="block text-xs font-semibold text-muted">
                {tr("يبقى مثبتاً في صدارة الصفحة الرئيسية وأول صفحة الأخبار")}
              </span>
            </div>
          </label>

          <label
            className={`flex cursor-pointer items-center gap-3 rounded-2xl border-2 p-3.5 transition ${
              breaking
                ? "border-alert bg-alert/10 text-ink shadow-2xs"
                : "border-line bg-surface/50 text-ink hover:border-alert/50"
            }`}
          >
            <input
              type="checkbox"
              className="size-5 accent-red-600"
              checked={breaking}
              onChange={(e) => setBreaking(e.target.checked)}
            />
            <div>
              <span className="block text-sm font-extrabold">
                🔥 {tr("نشر كخبر عاجل")}
              </span>
              <span className="block text-xs font-semibold text-muted">
                {tr("يظهر في شريط الأخبار العاجلة البارز أعلى الصفحة الرئيسية")}
              </span>
            </div>
          </label>
        </div>

        <button
          type="submit"
          className="btn py-3.5 text-base font-extrabold"
          disabled={saving || uploading}
        >
          {saving
            ? tr("جاري النشر والحفظ…")
            : editId
              ? tr("💾 حفظ التعديلات")
              : postType === "live"
                ? tr("🔴 نشر البث المباشر الآن")
                : postType === "video"
                  ? tr("🎬 نشر الفيديو الآن")
                  : tr("✍️ نشر المقال الآن")}
        </button>

        {msg ? (
          <p className="rounded-2xl bg-primary-soft px-4 py-2.5 text-sm font-extrabold text-ink">
            {trv(msg)}
          </p>
        ) : null}
      </form>

      {/* Published Articles, Videos & Live Streams Management List */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-extrabold text-ink">
            {tr("المقالات والفيديوهات والبثوث المنشورة")} ({visibleItems.length})
          </h2>
          <div className="flex flex-wrap gap-1.5">
            {[
              { id: "all" as const, label: "الكل" },
              { id: "pinned" as const, label: "📌 المثبّتة" },
              { id: "video" as const, label: "🎬 فيديو" },
              { id: "live" as const, label: "🔴 بث مباشر" },
            ].map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilterType(f.id)}
                className={`rounded-full px-3 py-1 text-xs font-extrabold transition ${
                  filterType === f.id
                    ? "bg-ink text-primary"
                    : "border border-line bg-paper text-ink hover:border-primary"
                }`}
              >
                {tr(f.label)}
              </button>
            ))}
          </div>
        </div>

        {!items ? (
          <p className="stamp p-4 font-semibold">{tr("جاري التحميل…")}</p>
        ) : visibleItems.length === 0 ? (
          <p className="stamp p-4 font-semibold">{tr("لا توجد منشورات في هذا الفلتر بعد.")}</p>
        ) : (
          <ul className="flex flex-col gap-3">
            {visibleItems.map((n) => {
              const ytId = extractYoutubeId(n.videoUrl);
              const thumbUrl = n.imageKey
                ? mediaUrl(n.imageKey)
                : ytId
                  ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`
                  : "";
              return (
                <li
                  key={n.id}
                  className={`stamp p-4 flex flex-col sm:flex-row gap-3.5 transition ${
                    n.pinned ? "border-2 border-primary bg-primary-soft/25" : ""
                  }`}
                >
                  {thumbUrl ? (
                    <img
                      src={thumbUrl}
                      alt=""
                      className="h-24 w-full sm:w-28 shrink-0 rounded-2xl object-cover border border-line"
                    />
                  ) : null}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap gap-1.5">
                      {n.pinned ? (
                        <span className="chip bg-primary text-ink border-primary-deep font-extrabold">
                          📌 {tr("مثبّت في الأعلى")}
                        </span>
                      ) : null}
                      {n.postType === "live" ? (
                        <span className="chip chip-alert">🔴 {tr("بث مباشر")}</span>
                      ) : n.postType === "video" ? (
                        <span className="chip bg-ink text-paper">🎬 {tr("فيديو")}</span>
                      ) : (
                        <span className="chip">📰 {tr("مقال")}</span>
                      )}
                      {n.breaking ? <span className="chip chip-alert">🔥 {tr("عاجل")}</span> : null}
                      <span className="chip">{trv(n.category)}</span>
                      <span className="chip">
                        {n.authorName ? tr("كتبه: {0}", n.authorName) : tr("الإدارة")}
                      </span>
                    </div>

                    <a
                      href={`/news/rp-${n.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-2 block text-base sm:text-lg font-extrabold text-ink underline hover:text-primary-ink"
                    >
                      {trv(n.title)}
                    </a>

                    <p className="mt-0.5 text-xs font-semibold text-muted">
                      {new Date(n.createdAt).toLocaleString("ar-u-nu-latn", {
                        timeZone: "Asia/Jerusalem",
                      })}
                      {n.videoUrl ? ` · 🔗 ${n.videoUrl}` : ""}
                    </p>

                    <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <button
                        type="button"
                        disabled={busyId === n.id}
                        onClick={() => act(n.id, n.pinned ? "pin-off" : "pin-on")}
                        className={`rounded-xl px-3 py-2 text-xs font-extrabold transition ${
                          n.pinned
                            ? "bg-ink text-primary"
                            : "border border-primary-deep bg-primary-soft text-ink hover:bg-primary"
                        }`}
                      >
                        {n.pinned ? "📌 " + tr("إلغاء التثبيت") : "📌 " + tr("تثبيت المقال")}
                      </button>

                      <button
                        type="button"
                        disabled={busyId === n.id}
                        onClick={() => act(n.id, n.breaking ? "breaking-off" : "breaking-on")}
                        className="btn btn-ghost py-2 text-xs font-extrabold"
                      >
                        {n.breaking ? tr("إلغاء العاجل") : "🔥 " + tr("جعله عاجلاً")}
                      </button>

                      <button
                        type="button"
                        onClick={() => startEdit(n)}
                        className="btn btn-ghost py-2 text-xs font-extrabold"
                      >
                        ✏️ {tr("تعديل")}
                      </button>

                      <button
                        type="button"
                        disabled={busyId === n.id}
                        onClick={() => act(n.id, "delete")}
                        className="btn btn-ghost py-2 text-xs font-extrabold text-alert"
                      >
                        🗑️ {tr("حذف")}
                      </button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
