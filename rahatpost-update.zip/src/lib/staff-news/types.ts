export type StaffPostType = "article" | "video" | "live";

export type StaffNewsMeta = {
  postType?: StaffPostType;
  videoUrl?: string;
  pinned?: boolean;
  externalImage?: string;
};

export type StaffNews = {
  id: string;
  title: string;
  category: string;
  body: string;
  imageKey: string;
  breaking: boolean;
  createdAt: string;
  authorId: string;
  /** Writer's name; empty for articles by the owner (password login). */
  authorName: string;
  postType?: StaffPostType;
  videoUrl?: string;
  pinned?: boolean;
};

export type StaffNewsInput = {
  title: string;
  category: string;
  body: string;
  imageKey: string;
  breaking: boolean;
  postType?: StaffPostType;
  videoUrl?: string;
  pinned?: boolean;
};

export const STAFF_NEWS_ID_RE = /^[a-f0-9]{16}$/;
export const STAFF_SLUG_PREFIX = "rp-";
export const STAFF_SOURCE = "رهط بوست";

const META_PREFIX = "<!--rp-meta:";
const META_SUFFIX = "-->";

export function packStaffBodyWithMeta(body: string, meta: StaffNewsMeta): string {
  const cleanBody = unpackStaffBodyAndMeta(body).cleanBody;
  const hasMeta =
    (meta.postType && meta.postType !== "article") ||
    Boolean(meta.videoUrl?.trim()) ||
    Boolean(meta.pinned) ||
    Boolean(meta.externalImage?.trim());
  if (!hasMeta) return cleanBody;
  const payload = JSON.stringify({
    postType: meta.postType || "article",
    videoUrl: meta.videoUrl?.trim() || undefined,
    pinned: Boolean(meta.pinned),
    externalImage: meta.externalImage?.trim() || undefined,
  });
  return `${META_PREFIX}${payload}${META_SUFFIX}\n${cleanBody}`;
}

export function unpackStaffBodyAndMeta(rawBody: string): {
  cleanBody: string;
  meta: StaffNewsMeta;
} {
  const text = String(rawBody ?? "");
  if (!text.startsWith(META_PREFIX)) {
    return { cleanBody: text, meta: { postType: "article", pinned: false } };
  }
  const endIdx = text.indexOf(META_SUFFIX);
  if (endIdx === -1) {
    return { cleanBody: text, meta: { postType: "article", pinned: false } };
  }
  const jsonStr = text.slice(META_PREFIX.length, endIdx);
  const rest = text.slice(endIdx + META_SUFFIX.length).replace(/^\n+/, "");
  try {
    const parsed = JSON.parse(jsonStr) as StaffNewsMeta;
    return {
      cleanBody: rest,
      meta: {
        postType:
          parsed.postType === "video" || parsed.postType === "live"
            ? parsed.postType
            : "article",
        videoUrl: typeof parsed.videoUrl === "string" ? parsed.videoUrl : undefined,
        pinned: Boolean(parsed.pinned),
        externalImage: typeof parsed.externalImage === "string" ? parsed.externalImage : undefined,
      },
    };
  } catch {
    return { cleanBody: rest, meta: { postType: "article", pinned: false } };
  }
}

export function extractYoutubeId(url?: string): string | null {
  if (!url) return null;
  const m = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|live\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/,
  );
  return m ? m[1] : null;
}
