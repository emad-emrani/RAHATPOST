import { randomBytes } from "node:crypto";
import { getSql } from "@/lib/db";
import {
  packStaffBodyWithMeta,
  STAFF_SLUG_PREFIX,
  unpackStaffBodyAndMeta,
  type StaffNews,
  type StaffNewsInput,
} from "./types";

type Row = {
  id: string;
  title: string;
  category: string;
  body: string;
  image_key: string | null;
  breaking: boolean;
  created_at: Date | string;
  author_id: string | null;
  author_name: string | null;
};

const iso = (v: Date | string) => (v instanceof Date ? v.toISOString() : new Date(v).toISOString());

const toItem = (r: Row): StaffNews => {
  const { cleanBody, meta } = unpackStaffBodyAndMeta(r.body);
  return {
    id: r.id,
    title: r.title,
    category: r.category,
    body: cleanBody,
    imageKey: r.image_key ?? "",
    breaking: Boolean(r.breaking),
    createdAt: iso(r.created_at),
    authorId: r.author_id ?? "",
    authorName: r.author_name ?? "",
    postType: meta.postType ?? "article",
    videoUrl: meta.videoUrl ?? "",
    pinned: Boolean(meta.pinned),
  };
};

const COLS = `id, title, category, body, image_key, breaking, created_at, author_id, author_name`;

async function syncPinOverride(id: string, pinned: boolean) {
  try {
    const { saveOverride, loadOverrides } = await import("@/lib/news/overrides.server");
    const slug = `${STAFF_SLUG_PREFIX}${id}`;
    const ovs = await loadOverrides();
    const cur = ovs.items.get(slug);
    await saveOverride({
      slug,
      kind: "news",
      hidden: cur?.hidden ?? false,
      pinned,
      breaking: cur?.breaking ?? null,
      category: cur?.category ?? null,
      title: cur?.title ?? null,
    });
  } catch (e) {
    console.error("[staff-news] syncPinOverride failed", e);
  }
}

/** Newest first (pinned first); `authorId` limits to one writer's articles. */
export async function listStaffNews(limit = 50, authorId?: string): Promise<StaffNews[]> {
  const sql = await getSql();
  const rows = authorId
    ? await sql.query<Row>(
        `select ${COLS} from staff_news where author_id = $1 order by created_at desc limit $2`,
        [authorId, limit],
      )
    : await sql.query<Row>(`select ${COLS} from staff_news order by created_at desc limit $1`, [
        limit,
      ]);
  const list = rows.map(toItem);
  return list.sort(
    (a, b) =>
      Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) ||
      Date.parse(b.createdAt) - Date.parse(a.createdAt),
  );
}

export async function getStaffNews(id: string): Promise<StaffNews | null> {
  const sql = await getSql();
  const rows = await sql.query<Row>(`select ${COLS} from staff_news where id = $1`, [id]);
  return rows[0] ? toItem(rows[0]) : null;
}

export async function createStaffNews(
  input: StaffNewsInput,
  author: { id: string; name: string } | null,
): Promise<string> {
  const sql = await getSql();
  const id = randomBytes(8).toString("hex");
  const packedBody = packStaffBodyWithMeta(input.body, {
    postType: input.postType,
    videoUrl: input.videoUrl,
    pinned: input.pinned,
  });
  await sql`
    insert into staff_news (id, title, category, body, image_key, breaking, author_id, author_name)
    values (${id}, ${input.title}, ${input.category}, ${packedBody}, ${input.imageKey || null},
      ${input.breaking}, ${author?.id || null}, ${author?.name || null})`;
  if (input.pinned) {
    await syncPinOverride(id, true);
  }
  return id;
}

export async function updateStaffNews(id: string, input: StaffNewsInput): Promise<void> {
  const sql = await getSql();
  const old = await getStaffNews(id);
  const packedBody = packStaffBodyWithMeta(input.body, {
    postType: input.postType ?? old?.postType,
    videoUrl: input.videoUrl !== undefined ? input.videoUrl : old?.videoUrl,
    pinned: input.pinned !== undefined ? input.pinned : old?.pinned,
  });
  await sql`
    update staff_news set title = ${input.title}, category = ${input.category}, body = ${packedBody},
      image_key = ${input.imageKey || null}, breaking = ${input.breaking}, updated_at = now()
    where id = ${id}`;
  await syncPinOverride(id, Boolean(input.pinned !== undefined ? input.pinned : old?.pinned));
  if (old?.imageKey && old.imageKey !== input.imageKey) await dropImage(old.imageKey);
}

export async function setStaffBreaking(id: string, breaking: boolean): Promise<void> {
  const sql = await getSql();
  await sql`update staff_news set breaking = ${breaking}, updated_at = now() where id = ${id}`;
}

export async function setStaffPinned(id: string, pinned: boolean): Promise<void> {
  const sql = await getSql();
  const cur = await getStaffNews(id);
  if (!cur) return;
  const packedBody = packStaffBodyWithMeta(cur.body, {
    postType: cur.postType,
    videoUrl: cur.videoUrl,
    pinned,
  });
  await sql`update staff_news set body = ${packedBody}, updated_at = now() where id = ${id}`;
  await syncPinOverride(id, pinned);
}

export async function deleteStaffNews(id: string): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ image_key: string | null }>`
    delete from staff_news where id = ${id} returning image_key`;
  await syncPinOverride(id, false);
  if (rows[0]?.image_key) await dropImage(rows[0].image_key);
}

async function dropImage(key: string) {
  const { deleteMediaFiles } = await import("@/lib/media/storage.server");
  await deleteMediaFiles([key]).catch((e) => console.error("[staff-news] image delete failed", e));
}

/** Content type of a staff-news photo if `key` belongs to a published article (public). */
export async function staffImageType(key: string): Promise<string | null> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`select 1 as n from staff_news where image_key = ${key}`;
  if (!rows.length) return null;
  return key.endsWith(".jpg") ? "image/jpeg" : "image/webp";
}
