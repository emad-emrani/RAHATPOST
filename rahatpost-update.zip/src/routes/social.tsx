import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { SocialVipFeedAndTrendsSection } from "@/components/social-vip-feed";
import { breadcrumbLd, seo } from "@/lib/seo";
import { tr } from "@/lib/i18n/core";

export const Route = createFileRoute("/social")({
  head: () =>
    seo({
      title: tr("تواصل اجتماعي · المشاهير والسياسيون والتريند في رهط والعالم · رهط بوست"),
      description: tr(
        "منصة تواصل اجتماعي في رهط بوست: تابع آخر منشورات وتغريدات الشخصيات والمؤسسات المحلية في رهط والنقب، والسياسيين والمشاهير بتصميم فيسبوك وإكس مع ترجمة فورية والتريند المباشر.",
      ),
      path: "/social",
      keywords: [
        "تواصل اجتماعي رهط",
        "تغريدات المشاهير رهط",
        "سياسيون النقب",
        "تريند رهط اليوم",
        "فيسبوك رهط بوست",
      ],
      jsonLd: [breadcrumbLd([{ name: tr("تواصل اجتماعي"), path: "/social" }])],
    }),
  headers: () => ({
    "Cache-Control": "public, max-age=15, s-maxage=60, stale-while-revalidate=180",
  }),
  component: SocialPage,
});

function SocialPage() {
  return (
    <Shell wide>
      <div className="space-y-4">
        {/* Page Top Title Banner */}
        <div className="rounded-3xl border-2 border-primary-deep/60 bg-gradient-to-l from-[#1877f2] via-[#0f2942] to-[#0f172a] p-5 text-white shadow-lg sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-extrabold text-[#111827]">
                🌐 منصة التواصل والتريند الاجتماعي · Social Feed
              </span>
              <h1 className="mt-2 text-xl font-extrabold sm:text-2xl">
                {tr("تواصل اجتماعي · منشورات وتغريدات المشاهير والسياسيين")}
              </h1>
              <p className="mt-1 max-w-2xl text-xs font-semibold text-white/80 sm:text-sm">
                {tr(
                  "تغطية مستمرة لأحدث منشورات وتغريدات الشخصيات والمؤسسات المحلية في رهط والنقب، وأبرز السياسيين والمشاهير في قالب فيسبوك العصري مع زر الترجمة الفورية والتريند المباشر.",
                )}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="rounded-2xl bg-white/10 px-3.5 py-2 text-xs font-extrabold text-white ring-1 ring-white/20">
                🔵 Facebook + 𝕏 Trends
              </span>
            </div>
          </div>
        </div>

        {/* Facebook Template Feed + Trends + Local Figures Stream */}
        <SocialVipFeedAndTrendsSection isFullPage />
      </div>
    </Shell>
  );
}
