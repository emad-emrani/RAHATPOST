import {
  createRootRoute,
  HeadContent,
  Link,
  Outlet,
  Scripts,
  useLocation,
  useRouterState,
} from "@tanstack/react-router";
import {
  Bus,
  Cpu,
  Globe,
  House,
  MapPin,
  Megaphone,
  Newspaper,
  Plus,
  Siren,
  Sparkles,
  Store,
  Trophy,
  Tv,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { ServiceWorkerRegistration } from "@/components/install-app";
import { SiteAnalytics } from "@/components/analytics";
import appCss from "../styles.css?url";
import { GoogleServices } from "@/components/google-services";
import { getSiteSettings } from "@/lib/site-settings/api";
import { SiteSettingsProvider, useSiteSettings } from "@/lib/site-settings/context";
import { DEFAULT_ADSENSE_PUB, DEFAULT_SETTINGS, themeCss } from "@/lib/site-settings/types";
import { mediaUrl } from "@/lib/media/types";
import { getI18n } from "@/lib/i18n/api";
import { BUILTIN_LANGS, getI18nState, setI18nState, tr, trv, type I18nState } from "@/lib/i18n/core";

const ARABIC_STATE: I18nState = { lang: "ar", dir: "rtl", dict: {}, langs: BUILTIN_LANGS };

const BOT_ICON_MAP: Record<string, LucideIcon> = {
  home: House,
  news: Newspaper,
  tv: Tv,
  trophy: Trophy,
  bus: Bus,
  ad: Megaphone,
  siren: Siren,
  pin: MapPin,
  store: Store,
  globe: Globe,
  cpu: Cpu,
  sparkles: Sparkles,
  plus: Plus,
};

const DEFAULT_BOT_TILES: { icon: string; label: string; to: string }[] = [
  { icon: "home", label: "الرئيسية", to: "/" },
  { icon: "news", label: "الأخبار", to: "/news" },
  { icon: "tv", label: "بث مباريات", to: "/sports-news" },
  { icon: "bus", label: "باصات", to: "/buses" },
  { icon: "ad", label: "حراج", to: "/haraj" },
  { icon: "siren", label: "اليوم", to: "/today" },
];

const NAV_TO_BOT_ITEM: Record<string, { icon: string; label: string; to: string }> = {
  "/": { icon: "home", label: "الرئيسية", to: "/" },
  "/news": { icon: "news", label: "الأخبار", to: "/news" },
  "/buses": { icon: "bus", label: "باصات", to: "/buses" },
  "/directory": { icon: "pin", label: "الدليل", to: "/directory" },
  "/haraj": { icon: "ad", label: "حراج", to: "/haraj" },
  "/today": { icon: "siren", label: "اليوم", to: "/today" },
  "/store": { icon: "store", label: "المتجر", to: "/store" },
};

function fromBase64Url(b64u: string): string {
  try {
    const b64 = b64u.replace(/-/g, "+").replace(/_/g, "/");
    const pad = b64.length % 4 === 0 ? "" : "=".repeat(4 - (b64.length % 4));
    const bin = typeof atob === "function" ? atob(b64 + pad) : "";
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch {
    return "";
  }
}


const SECTION_DICT_ROOT: Record<string, { he: string; en: string }> = {
  "فن و موضة": { he: "אמנות ואופנה", en: "Art & Fashion" },
  "فن وموضة": { he: "אמנות ואופנה", en: "Art & Fashion" },
  "ثقافة وفن": { he: "תרבות ואמנות", en: "Culture & Art" },
  "فن وثقافة": { he: "אמנות ותרבות", en: "Art & Culture" },
  "موضة": { he: "אופנה", en: "Fashion" },
  "فن": { he: "אמנות", en: "Art" },
  "مشاهير": { he: "סלבס ובידור", en: "Celebrities" },
  "الذكاء": { he: "בינה מלאכותית", en: "AI" },
  "ذكاء اصطناعي": { he: "בינה מלאכותית", en: "Artificial Intelligence" },
  "نتفليكس": { he: "נטפליקס", en: "Netflix" },
  "أخبار محلية": { he: "חדשות מקומיות", en: "Local News" },
};

function trSecLabel(raw: string): string {
  if (!raw) return "";
  const trimmed = raw.trim();
  const emojiMatch = trimmed.match(/^([\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\s]+)(.+)$/u);
  const prefix = emojiMatch ? emojiMatch[1] : "";
  const core = (emojiMatch ? emojiMatch[2] : trimmed).trim();
  const lang = getI18nState().lang;
  if (lang === "ar") return trimmed;
  const entry = SECTION_DICT_ROOT[core];
  if (entry && (lang === "he" || lang === "en")) {
    return `${prefix}${entry[lang]}`;
  }
  const byDict = trv(core);
  if (byDict !== core) return `${prefix}${byDict}`;
  return trv(trimmed);
}

function GlobalCustomBottomBar() {
  const st = useSiteSettings();
  const location = useLocation();
  const pathname = location.pathname || "/";

  // Hide on admin, login, reset-password, and app-auth screens
  const isSystemScreen =
    pathname.startsWith("/admin") ||
    pathname.startsWith("/login") ||
    pathname.startsWith("/reset-password") ||
    pathname.startsWith("/app-auth");

  const botItem = (st.quickLinks ?? []).find((q) => q.id === "botbarcfg");
  const cssItem = (st.quickLinks ?? []).find((q) => q.id === "botbarcss");

  const { style, btns } = useMemo(() => {
    if (!botItem || !botItem.url.startsWith("/__bot?")) {
      // Preserve exact order from st.nav if configured, otherwise DEFAULT_BOT_TILES
      const navOrdered = (st.nav ?? [])
        .filter((n) => n.visible)
        .map((n) => NAV_TO_BOT_ITEM[n.id])
        .filter(Boolean);
      return {
        style: "classic",
        btns: navOrdered.length > 0 ? navOrdered : DEFAULT_BOT_TILES,
      };
    }
    const rawStyle = botItem.title.trim();
    const validStyle =
      rawStyle === "floating" ||
      rawStyle === "dark" ||
      rawStyle === "dock" ||
      rawStyle === "minimal" ||
      rawStyle === "neon" ||
      rawStyle === "glass" ||
      rawStyle === "custom" ||
      rawStyle === "hidden"
        ? rawStyle
        : "classic";
    const labels = (botItem.subtitle ?? "").split("|");
    const pairs = botItem.url.slice(7).split("|").filter(Boolean);
    const parsedBtns = pairs.map((p, idx) => {
      const colon = p.indexOf(":");
      const icon = colon > 0 ? p.slice(0, colon) : "home";
      const rawTo = colon > 0 ? p.slice(colon + 1) : p;
      const to = rawTo.replace(/%20/g, " ");
      return {
        icon: icon || "home",
        to: to || "/",
        label: (labels[idx] ?? "").trim() || "زر",
      };
    });
    return {
      style: validStyle,
      btns: parsedBtns.length > 0 ? parsedBtns : DEFAULT_BOT_TILES,
    };
  }, [botItem, st.nav]);

  const customCfg = useMemo(() => {
    let bg = "#111827";
    let fg = "#9ca3af";
    let ab = "#f2c94c";
    let af = "#111827";
    let r = 24;
    let m = 10;
    let rawCss = "";
    if (cssItem) {
      for (const part of (cssItem.title ?? "").split("|")) {
        if (part.startsWith("bg:")) bg = part.slice(3) || bg;
        else if (part.startsWith("fg:")) fg = part.slice(3) || fg;
        else if (part.startsWith("ab:")) ab = part.slice(3) || ab;
        else if (part.startsWith("af:")) af = part.slice(3) || af;
        else if (part.startsWith("r:")) r = Number(part.slice(2)) || 0;
        else if (part.startsWith("m:")) m = Number(part.slice(2)) || 0;
      }
      const b64Part1 = cssItem.url?.startsWith("/__bcss?") ? cssItem.url.slice(8) : "";
      const b64Part2 = cssItem.subtitle && cssItem.subtitle !== "css" ? cssItem.subtitle : "";
      if (b64Part1) rawCss = fromBase64Url(b64Part1 + b64Part2);
    }
    return { bg, fg, ab, af, r, m, rawCss };
  }, [cssItem]);

  if (isSystemScreen) return null;

  const hideLegacyCss = `
    nav.edge-t.fixed.bottom-0:not(.custom-botbar) { display: none !important; }
    nav.custom-botbar:not(#rp-global-bottom-bar) { display: none !important; }
  `;

  if (style === "hidden") {
    return <style>{hideLegacyCss}</style>;
  }

  const userExtraCss = customCfg.rawCss.trim()
    ? customCfg.rawCss.includes("{")
      ? customCfg.rawCss
      : `#rp-global-bottom-bar { ${customCfg.rawCss} }`
    : "";

  const navWrapCls =
    style === "floating"
      ? "custom-botbar fixed inset-x-3 bottom-3 z-40 rounded-full border border-line bg-paper/95 px-2 py-1.5 shadow-xl backdrop-blur-md md:hidden"
      : style === "dark"
        ? "custom-botbar fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#111827]/95 pb-[env(safe-area-inset-bottom)] text-white shadow-xl backdrop-blur-md md:hidden"
        : style === "dock"
          ? "custom-botbar fixed inset-x-2 bottom-2 z-40 rounded-3xl border border-line bg-paper/95 p-1.5 shadow-lg backdrop-blur-md md:hidden"
          : style === "minimal"
            ? "custom-botbar fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden"
            : style === "neon"
              ? "custom-botbar fixed inset-x-3 bottom-3 z-40 rounded-3xl border border-[#f2c94c]/60 bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0f172a] px-2 py-1.5 text-white shadow-[0_10px_30px_rgba(242,201,76,0.25)] backdrop-blur-md md:hidden"
              : style === "glass"
                ? "custom-botbar fixed inset-x-3 bottom-3 z-40 rounded-3xl border border-white/40 bg-white/75 px-2 py-1.5 text-ink shadow-[0_8px_32px_rgba(15,23,42,0.12)] backdrop-blur-xl md:hidden"
                : style === "custom"
                  ? "custom-botbar fixed z-40 px-2 py-1.5 shadow-xl backdrop-blur-md md:hidden"
                  : "custom-botbar edge-t fixed inset-x-0 bottom-0 z-40 bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden";

  const customNavStyle: CSSProperties | undefined =
    style === "custom"
      ? {
          backgroundColor: customCfg.bg,
          color: customCfg.fg,
          borderRadius: `${customCfg.r}px`,
          bottom: `${customCfg.m}px`,
          left: customCfg.m > 0 ? `${customCfg.m}px` : "0px",
          right: customCfg.m > 0 ? `${customCfg.m}px` : "0px",
        }
      : undefined;

  return (
    <>
      <style>{hideLegacyCss + "\n" + userExtraCss}</style>
      <nav
        id="rp-global-bottom-bar"
        className={navWrapCls}
        style={customNavStyle}
        aria-label={tr("التنقل السفلي")}
      >
        <div className="mx-auto flex max-w-xl items-center justify-around">
          {btns.map((item, idx) => {
            const Icon = BOT_ICON_MAP[item.icon] ?? House;
            const cleanLbl = item.label.trim();
            const isGenNews = cleanLbl === "الأخبار" || cleanLbl === "أخبار" || cleanLbl === "أخبار رهط";
            const isCustomSec =
              item.to.includes("?cat=") ||
              item.to.includes("?q=") ||
              (item.to === "/news" && Boolean(cleanLbl) && !isGenNews);
            const resolvedCat = item.to.includes("?cat=")
              ? decodeURIComponent(item.to.split("?cat=")[1] ?? cleanLbl)
              : cleanLbl || decodeURIComponent(item.to.split("?q=")[1] ?? "");
            const hasQuery = isCustomSec;
            const linkTo = (isCustomSec ? "/news" : item.to.split("?")[0] || "/") as "/";
            const linkSearch = isCustomSec ? ({ cat: resolvedCat } as never) : undefined;
            const exact = item.to === "/";
            const isActive = exact
              ? pathname === "/" && !hasQuery
              : pathname === item.to || pathname.startsWith(`${item.to}/`);

            if (style === "custom") {
              return (
                <Link
                  key={`${item.to}-${idx}`}
                  to={linkTo}
                  search={linkSearch}
                  activeOptions={{ exact }}
                  data-active={isActive ? "true" : "false"}
                  className="custom-botbar-item flex flex-1 flex-col items-center justify-center gap-0.5 rounded-2xl py-1.5 text-[11px] font-extrabold transition"
                  style={
                    isActive
                      ? {
                          backgroundColor: customCfg.ab,
                          color: customCfg.af,
                          borderRadius: `${Math.max(8, customCfg.r - 6)}px`,
                        }
                      : { color: customCfg.fg }
                  }
                >
                  <Icon className="size-5" aria-hidden />
                  <span className="truncate">
                    {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
                  </span>
                </Link>
              );
            }
            if (style === "dark" || style === "neon") {
              return (
                <Link
                  key={`${item.to}-${idx}`}
                  to={linkTo}
                  search={linkSearch}
                  activeOptions={{ exact }}
                  className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-bold text-white/70 transition"
                  activeProps={{
                    className:
                      "flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-extrabold text-[#FDB700]",
                  }}
                >
                  <Icon className="size-5" aria-hidden />
                  <span className="truncate">
                    {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
                  </span>
                </Link>
              );
            }
            if (style === "floating" || style === "glass") {
              return (
                <Link
                  key={`${item.to}-${idx}`}
                  to={linkTo}
                  search={linkSearch}
                  activeOptions={{ exact }}
                  className="flex flex-1 flex-col items-center justify-center gap-0.5 rounded-full py-1.5 text-[11px] font-bold text-muted transition"
                  activeProps={{
                    className:
                      "flex flex-1 flex-col items-center justify-center gap-0.5 rounded-full bg-ink py-1.5 text-[11px] font-extrabold text-paper shadow-xs",
                  }}
                >
                  <Icon className="size-4" aria-hidden />
                  <span className="truncate">
                    {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
                  </span>
                </Link>
              );
            }
            if (style === "dock") {
              return (
                <Link
                  key={`${item.to}-${idx}`}
                  to={linkTo}
                  search={linkSearch}
                  activeOptions={{ exact }}
                  className="flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl py-1.5 text-[11px] font-bold text-muted transition"
                  activeProps={{
                    className:
                      "flex flex-1 flex-col items-center justify-center gap-1 rounded-2xl bg-primary py-1.5 text-[11px] font-extrabold text-ink shadow-xs",
                  }}
                >
                  <span className="grid size-8 place-items-center rounded-xl bg-surface/80">
                    <Icon className="size-5" aria-hidden />
                  </span>
                  <span className="truncate">
                    {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
                  </span>
                </Link>
              );
            }
            if (style === "minimal") {
              return (
                <Link
                  key={`${item.to}-${idx}`}
                  to={linkTo}
                  search={linkSearch}
                  activeOptions={{ exact }}
                  className="flex flex-1 flex-col items-center justify-center gap-0.5 border-t-2 border-transparent py-1.5 text-[11px] font-bold text-muted transition"
                  activeProps={{
                    className:
                      "flex flex-1 flex-col items-center justify-center gap-0.5 border-t-2 border-ink py-1.5 text-[11px] font-extrabold text-ink",
                  }}
                >
                  <Icon className="size-4" aria-hidden />
                  <span className="truncate">
                    {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
                  </span>
                </Link>
              );
            }
            return (
              <Link
                key={`${item.to}-${idx}`}
                to={linkTo}
                search={linkSearch}
                activeOptions={{ exact }}
                className="tabbar-link"
              >
                <span className="tab-icon">
                  <Icon className="size-5" aria-hidden />
                </span>
                {item.to === "/haraj" ? trv(st.texts.harajNav) : trSecLabel(item.label)}
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}

export const Route = createRootRoute({
  loader: async ({ location }) => {
    const want = new URLSearchParams(location.searchStr ?? "").get("lang") ?? "";
    const [settings, i18n] = await Promise.all([
      getSiteSettings().catch(() => DEFAULT_SETTINGS),
      getI18n({ data: want }).catch(() => ARABIC_STATE),
    ]);
    setI18nState(i18n);
    return { settings, i18n };
  },
  staleTime: 0,
  headers: () => ({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(self), microphone=(), camera=()",
  }),
  head: ({ loaderData }) => {
    const st = loaderData?.settings ?? DEFAULT_SETTINGS;
    const base = baseHead();
    const gsc = st.google.gscCode;
    const adsensePub = st.google.adsensePub || DEFAULT_ADSENSE_PUB;
    const i18n = loaderData?.i18n ?? ARABIC_STATE;
    const nonDefault = i18n.langs.find((l) => l.isDefault)?.code !== i18n.lang;
    return {
      meta: [
        ...base.meta.map((m) =>
          "name" in m && m.name === "theme-color" ? { ...m, content: st.theme.primary } : m,
        ),
        // Translated views are for visitors; the Arabic pages stay the canonical, indexed ones.
        ...(nonDefault ? [{ name: "robots", content: "noindex, follow" }] : []),
        ...(gsc && gsc !== __SITE_VERIFICATION__.google
          ? [{ name: "google-site-verification", content: gsc }]
          : []),
        { name: "google-adsense-account", content: adsensePub },
        { name: "msapplication-navbutton-color", content: st.theme.primary },
      ],
      links: st.faviconKey
        ? [
            { rel: "icon", href: mediaUrl(st.faviconKey) },
            ...base.links.filter((l) => l.rel !== "icon"),
          ]
        : base.links,
    };
  },
  component: RootComponent,
});

const NO_ADSENSE_PATHS = /^\/(admin|login|reset-password|app-auth|my-|cart|orders|store|haraj|ads|submit)/;

type ParsedMobileAdsConfig = {
  ampAds: boolean;
  enabled: boolean;
  pos: "b" | "t";
  androidAppId: string;
  iosAppId: string;
  bannerAdUnitId: string;
  interstitialAdUnitId: string;
};

function parseRootMobileAdsConfig(
  quickLinks: { id: string; title?: string }[] | undefined,
  adsensePub: string,
): ParsedMobileAdsConfig {
  const sliderItem = (quickLinks ?? []).find((q) => q.id === "slidercfg");
  const titleFlags = sliderItem?.title ?? "";
  const ampAds = !titleFlags.includes("amp:0");
  let enabled = true;
  let pos: "b" | "t" = "b";
  let androidApp = "3347511713";
  let iosApp = "1458002511";
  let bannerUnit = "6300978111";
  let interstitialUnit = "";
  for (const part of titleFlags.split("|")) {
    if (part.startsWith("m:")) {
      const mParts = part.slice(2).split(",");
      if (mParts[0] !== undefined) enabled = mParts[0] !== "0";
      if (mParts[1] === "t" || mParts[1] === "b") pos = mParts[1];
      if (mParts[2]) androidApp = mParts[2];
      if (mParts[3]) iosApp = mParts[3];
      if (mParts[4] !== undefined) bannerUnit = mParts[4];
      if (mParts[5] !== undefined) interstitialUnit = mParts[5];
    }
  }
  const pubDigits = (adsensePub || DEFAULT_ADSENSE_PUB).replace(/[^0-9]/g, "") || "9063892572843254";
  return {
    ampAds,
    enabled,
    pos,
    androidAppId: `ca-app-pub-${pubDigits}~${androidApp}`,
    iosAppId: `ca-app-pub-${pubDigits}~${iosApp}`,
    bannerAdUnitId: bannerUnit ? `ca-app-pub-${pubDigits}/${bannerUnit}` : "",
    interstitialAdUnitId: interstitialUnit ? `ca-app-pub-${pubDigits}/${interstitialUnit}` : "",
  };
}

/**
 * Bridges the Google Mobile Ads SDK (@capacitor-community/admob) inside the Android & iOS
 * Capacitor app, automatically hiding native banners on restricted routes (/store, /haraj, etc.).
 */
function GoogleMobileAdsBridge({
  config,
  allowAdsOnPage,
  pathname,
}: {
  config: ParsedMobileAdsConfig;
  allowAdsOnPage: boolean;
  pathname: string;
}) {
  const initializedRef = useRef(false);
  const bannerVisibleRef = useRef(false);
  const articleVisitsRef = useRef(0);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const win = window as unknown as {
      __GOOGLE_MOBILE_ADS_CONFIG__?: unknown;
      Capacitor?: {
        isNativePlatform?: () => boolean;
        getPlatform?: () => string;
        Plugins?: {
          AdMob?: {
            initialize: (opts?: Record<string, unknown>) => Promise<void>;
            requestTrackingAuthorization?: () => Promise<void>;
            showBanner: (opts: Record<string, unknown>) => Promise<void>;
            hideBanner: () => Promise<void>;
            removeBanner: () => Promise<void>;
            prepareInterstitial?: (opts: Record<string, unknown>) => Promise<void>;
            showInterstitial?: () => Promise<void>;
          };
        };
      };
    };

    win.__GOOGLE_MOBILE_ADS_CONFIG__ = {
      sdk: "Google Mobile Ads SDK v23.6.0",
      plugin: "@capacitor-community/admob",
      ...config,
      allowAdsOnPage,
    };

    const admob = win.Capacitor?.Plugins?.AdMob;
    if (!admob) return;

    let cancelled = false;

    const syncMobileAds = async () => {
      try {
        if (!config.enabled || !allowAdsOnPage || !config.bannerAdUnitId) {
          if (bannerVisibleRef.current) {
            bannerVisibleRef.current = false;
            await admob.hideBanner().catch(() => {});
            await admob.removeBanner().catch(() => {});
          }
          return;
        }

        if (!initializedRef.current) {
          initializedRef.current = true;
          await admob.initialize({ initializeForTesting: false }).catch(() => {});
          if (typeof admob.requestTrackingAuthorization === "function") {
            await admob.requestTrackingAuthorization().catch(() => {});
          }
        }

        if (cancelled) return;

        await admob
          .showBanner({
            adId: config.bannerAdUnitId,
            adSize: "ADAPTIVE_BANNER",
            position: config.pos === "t" ? "TOP_CENTER" : "BOTTOM_CENTER",
            margin: config.pos === "b" ? 56 : 0,
            isTesting: false,
          })
          .then(() => {
            bannerVisibleRef.current = true;
          })
          .catch(() => {});

        // Optional Interstitial Ad on article reads (at most once every 4 articles)
        if (
          config.interstitialAdUnitId &&
          /^\/(news|israel-news)\/[^/]+/.test(pathname) &&
          typeof admob.prepareInterstitial === "function" &&
          typeof admob.showInterstitial === "function"
        ) {
          articleVisitsRef.current += 1;
          if (articleVisitsRef.current % 4 === 0) {
            await admob
              .prepareInterstitial({
                adId: config.interstitialAdUnitId,
                isTesting: false,
              })
              .then(() => admob.showInterstitial?.())
              .catch(() => {});
          }
        }
      } catch {
        /* ignore native bridge errors outside app environment */
      }
    };

    void syncMobileAds();

    return () => {
      cancelled = true;
    };
  }, [
    allowAdsOnPage,
    config.androidAppId,
    config.bannerAdUnitId,
    config.enabled,
    config.interstitialAdUnitId,
    config.iosAppId,
    config.pos,
    pathname,
  ]);

  return null;
}


function isLightHexColor(hex: string): boolean {
  const clean = (hex || "#f2c94c").replace("#", "").trim();
  if (clean.length !== 6) return true;
  const r = parseInt(clean.slice(0, 2), 16) || 242;
  const g = parseInt(clean.slice(2, 4), 16) || 201;
  const b = parseInt(clean.slice(4, 6), 16) || 76;
  // Relative luminance formula
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return lum > 0.55;
}

/**
 * 1) Syncs the phone's top StatusBar (Capacitor Android/iOS + Mobile Browser theme-color)
 *    dynamically with `settings.theme.primary` whenever the theme color changes.
 * 2) Displays a harmonious, modern launch loading screen with the site logo & progress bar
 *    on initial open, handing off cleanly from the native SplashScreen.
 */
function SecurityAndCopyrightShield() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    // 1. Prevent image drag-and-drop theft
    const onDragStart = (e: DragEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && target.tagName === "IMG") {
        e.preventDefault();
      }
    };

    // 2. Append official Rahat Post source attribution when copying article text (> 75 chars)
    const onCopy = (e: ClipboardEvent) => {
      try {
        const target = e.target as HTMLElement | null;
        if (
          target &&
          (target.tagName === "INPUT" ||
            target.tagName === "TEXTAREA" ||
            target.isContentEditable ||
            window.location.pathname.startsWith("/admin"))
        ) {
          return;
        }
        const sel = window.getSelection()?.toString() ?? "";
        if (sel.trim().length > 75 && e.clipboardData) {
          const attribution = `\n\n— المصدر: منصة رهط بوست (Rahat Post) | جميع الحقوق محفوظة © ${new Date().getFullYear()}\n🔗 ${window.location.href}`;
          e.clipboardData.setData("text/plain", sel + attribution);
          e.preventDefault();
        }
      } catch {
        /* ignore */
      }
    };

    document.addEventListener("dragstart", onDragStart);
    document.addEventListener("copy", onCopy);
    return () => {
      document.removeEventListener("dragstart", onDragStart);
      document.removeEventListener("copy", onCopy);
    };
  }, []);

  return null;
}

function AppLaunchSplashAndStatusBarBridge() {
  const st = useSiteSettings();
  const location = useLocation();
  const isRouteLoading = useRouterState({
    select: (s) => s.isLoading || s.status === "pending",
  });
  const [navOverlay, setNavOverlay] = useState(false);
  const [showLaunch, setShowLaunch] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return !sessionStorage.getItem("rp_launch_done");
    } catch {
      return false;
    }
  });
  const [fadingOut, setFadingOut] = useState(false);

  const primaryColor = st.theme?.primary || "#f2c94c";
  const siteName = st.texts?.siteName || "رهط بوست";
  const tagline = st.texts?.tagline || "أخبار وخدمات رهط والنقب في مكان واحد";
  const logoSrc = st.logoKey ? mediaUrl(st.logoKey) : "/icons/icon-192.png";

  // Instant Page Transition Loading Screen (eliminates any perceived freeze between pages)
  useEffect(() => {
    if (isRouteLoading) {
      const tShow = setTimeout(() => setNavOverlay(true), 45);
      const tMax = setTimeout(() => setNavOverlay(false), 2200);
      return () => {
        clearTimeout(tShow);
        clearTimeout(tMax);
      };
    }
    const tHide = setTimeout(() => setNavOverlay(false), 90);
    return () => clearTimeout(tHide);
  }, [isRouteLoading, location.pathname, location.searchStr]);

  // Also trigger immediate visual feedback when tapping internal navigation links on mobile/app
  useEffect(() => {
    if (typeof window === "undefined") return;
    let safetyTimer: ReturnType<typeof setTimeout> | null = null;
    const onDocClick = (e: MouseEvent) => {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)
        return;
      const anchor = (e.target as HTMLElement | null)?.closest?.("a");
      if (!anchor) return;
      const href = anchor.getAttribute("href") || "";
      const targetAttr = anchor.getAttribute("target");
      if (
        !href ||
        targetAttr === "_blank" ||
        href.startsWith("#") ||
        href.startsWith("http") ||
        href.startsWith("mailto:") ||
        href.startsWith("tel:") ||
        href.startsWith("whatsapp:")
      ) {
        return;
      }
      const currentFull = window.location.pathname + window.location.search;
      if (href !== currentFull && href.startsWith("/")) {
        setNavOverlay(true);
        if (safetyTimer) clearTimeout(safetyTimer);
        safetyTimer = setTimeout(() => setNavOverlay(false), 1600);
      }
    };
    document.addEventListener("click", onDocClick, true);
    return () => {
      document.removeEventListener("click", onDocClick, true);
      if (safetyTimer) clearTimeout(safetyTimer);
    };
  }, []);

  // Sync phone StatusBar color (Capacitor Native + Mobile Browser meta theme-color)
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const metas = document.querySelectorAll(
        'meta[name="theme-color"], meta[name="msapplication-navbutton-color"]',
      );
      metas.forEach((m) => m.setAttribute("content", primaryColor));

      const win = window as unknown as {
        Capacitor?: {
          Plugins?: {
            StatusBar?: {
              setBackgroundColor?: (opts: { color: string }) => Promise<void>;
              setStyle?: (opts: { style: "DARK" | "LIGHT" | "DEFAULT" }) => Promise<void>;
              setOverlaysWebView?: (opts: { overlay: boolean }) => Promise<void>;
            };
            SplashScreen?: {
              hide?: (opts?: { fadeOutDuration?: number }) => Promise<void>;
            };
          };
        };
      };
      const statusBar = win.Capacitor?.Plugins?.StatusBar;
      if (statusBar) {
        const isLight = isLightHexColor(primaryColor);
        void statusBar.setOverlaysWebView?.({ overlay: false }).catch(() => {});
        void statusBar.setBackgroundColor?.({ color: primaryColor }).catch(() => {});
        void statusBar.setStyle?.({ style: isLight ? "LIGHT" : "DARK" }).catch(() => {});
      }
      void win.Capacitor?.Plugins?.SplashScreen?.hide?.({ fadeOutDuration: 0 }).catch(() => {});
    } catch {
      /* ignore */
    }
  }, [primaryColor]);

  // Smoothly dismiss launch screen once hydrated
  useEffect(() => {
    if (!showLaunch) return;
    const t1 = setTimeout(() => setFadingOut(true), 280);
    const t2 = setTimeout(() => {
      setShowLaunch(false);
      try {
        sessionStorage.setItem("rp_launch_done", "1");
      } catch {
        /* ignore */
      }
    }, 540);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [showLaunch]);

  const showPageTransitionScreen = (isRouteLoading || navOverlay) && !showLaunch;

  return (
    <>
      <style>{`
        @keyframes rpSplashPulse {
          0%, 100% { transform: scale(1); opacity: 0.35; }
          50% { transform: scale(1.16); opacity: 0.12; }
        }
        @keyframes rpProgressSlide {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        @keyframes rpSpinRing {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      {/* Top 3.5px Theme Status Bar Accent & Instant Route Loading Bar */}
      <div
        aria-hidden
        className="fixed inset-x-0 top-0 z-50 h-1 overflow-hidden transition-colors duration-300"
        style={{ backgroundColor: primaryColor }}
      >
        {isRouteLoading || navOverlay ? (
          <div
            className="h-full w-1/2 bg-ink/55"
            style={{ animation: "rpProgressSlide 0.65s infinite linear" }}
          />
        ) : null}
      </div>

      {/* Smooth Page-to-Page Loading Screen (التخلص من التعليق بين الصفحات بشاشة لودينج) */}
      {showPageTransitionScreen ? (
        <div
          id="rp-page-transition-loader"
          aria-live="polite"
          className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center bg-surface/45 backdrop-blur-[3px] transition-opacity duration-150"
        >
          <div className="flex items-center gap-3 rounded-3xl border border-primary-deep/60 bg-paper/95 px-5 py-3.5 shadow-2xl">
            <div className="relative flex size-11 items-center justify-center">
              <span
                className="absolute inset-0 rounded-full border-3 border-primary/30 border-t-primary-deep"
                style={{ animation: "rpSpinRing 0.65s infinite linear" }}
              />
              <img
                src={logoSrc}
                alt=""
                className="size-8 rounded-full object-cover"
              />
            </div>
            <div className="text-start">
              <p className="text-sm font-extrabold text-ink">{trv(siteName)}</p>
              <p className="text-[11px] font-bold text-muted">{tr("جاري فتح الصفحة…")}</p>
            </div>
          </div>
        </div>
      ) : null}

      {/* Harmonious Initial Launch Splash Overlay */}
      {showLaunch ? (
        <div
          id="rp-app-launch-splash"
          aria-hidden
          className={`fixed inset-0 z-50 flex flex-col items-center justify-center px-6 transition-opacity duration-300 ${
            fadingOut ? "pointer-events-none opacity-0" : "opacity-100"
          }`}
          style={{
            background: `radial-gradient(circle at 50% 38%, ${primaryColor}33 0%, var(--color-surface, #f1f2f4) 72%)`,
            backgroundColor: "var(--color-surface, #f1f2f4)",
          }}
        >
          <div className="relative flex items-center justify-center">
            <span
              className="absolute size-28 rounded-full"
              style={{
                backgroundColor: primaryColor,
                animation: "rpSplashPulse 1.8s infinite ease-in-out",
              }}
            />
            <div
              className="relative flex size-22 items-center justify-center overflow-hidden rounded-3xl bg-paper p-2 shadow-xl"
              style={{ border: `3px solid ${primaryColor}` }}
            >
              <img
                src={logoSrc}
                alt={siteName}
                className="size-full rounded-2xl object-contain"
              />
            </div>
          </div>

          <p className="mt-4 text-xl font-extrabold tracking-tight text-ink">{trv(siteName)}</p>
          <p className="mt-1 max-w-xs text-center text-xs font-bold text-muted">{trv(tagline)}</p>

          <div className="mt-5 h-1.5 w-36 overflow-hidden rounded-full bg-line/70">
            <div
              className="h-full w-2/3 rounded-full"
              style={{
                backgroundColor: primaryColor,
                animation: "rpProgressSlide 1.1s infinite ease-in-out",
              }}
            />
          </div>
        </div>
      ) : null}
    </>
  );
}

function RootComponent() {
  const { settings: loaderSettings, i18n } = Route.useLoaderData();
  const [liveSettings, setLiveSettings] = useState<typeof loaderSettings>(loaderSettings);
  const location = useLocation();
  const pathname = location.pathname || "/";

  useEffect(() => {
    setLiveSettings(loaderSettings);
  }, [loaderSettings]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    // 1. Immediately apply any fresher settings saved in localStorage from /admin (0ms delay)
    try {
      const rawLocal = window.localStorage.getItem("rp_latest_site_settings");
      if (rawLocal) {
        const parsed = JSON.parse(rawLocal);
        if (parsed && typeof parsed === "object" && Array.isArray(parsed.home)) {
          setLiveSettings(parsed);
        }
      }
    } catch {}

    // 2. Proactively update Service Worker so mobile app clears stale rp-v3 caches
    try {
      if ("serviceWorker" in navigator) {
        void navigator.serviceWorker
          .getRegistrations()
          .then((regs) => regs.forEach((r) => void r.update().catch(() => {})))
          .catch(() => {});
      }
    } catch {}

    // 3. Always fetch fresh uncached settings via /api/media?kind=live-settings (bypasses SW & WebView cache)
    let active = true;
    const applyFresh = (fresh: typeof loaderSettings | null | undefined) => {
      if (!active || !fresh || !Array.isArray(fresh.home)) return;
      setLiveSettings((prev) => {
        const prevJson = JSON.stringify(prev);
        const nextJson = JSON.stringify(fresh);
        return prevJson === nextJson ? prev : fresh;
      });
      try {
        window.localStorage.setItem("rp_latest_site_settings", JSON.stringify(fresh));
      } catch {}
    };

    const refreshLive = () => {
      void fetch(`/api/media?kind=live-settings&_t=${Date.now()}`, {
        method: "GET",
        cache: "no-store",
        headers: { "cache-control": "no-cache", pragma: "no-cache" },
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (data?.ok && data?.settings && Array.isArray(data.settings.home)) {
            applyFresh(data.settings);
          } else {
            return getSiteSettings().then((s) => applyFresh(s));
          }
        })
        .catch(() => {
          void getSiteSettings()
            .then((s) => applyFresh(s))
            .catch(() => {});
        });
    };
    refreshLive();

    // Poll every 8s while visible so mobile app reflects admin changes in real time
    const pollTimer = window.setInterval(() => {
      if (document.visibilityState === "visible") refreshLive();
    }, 8000);

    const onCustomUpdate = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && Array.isArray(detail.home)) {
        applyFresh(detail);
      } else {
        refreshLive();
      }
    };
    const onFocusOrVis = () => {
      if (document.visibilityState === "visible") refreshLive();
    };
    window.addEventListener("rp-site-settings-updated", onCustomUpdate);
    window.addEventListener("focus", onFocusOrVis);
    window.addEventListener("resume", refreshLive);
    window.addEventListener("pageshow", refreshLive);
    document.addEventListener("visibilitychange", onFocusOrVis);
    return () => {
      active = false;
      window.clearInterval(pollTimer);
      window.removeEventListener("rp-site-settings-updated", onCustomUpdate);
      window.removeEventListener("focus", onFocusOrVis);
      window.removeEventListener("resume", refreshLive);
      window.removeEventListener("pageshow", refreshLive);
      document.removeEventListener("visibilitychange", onFocusOrVis);
    };
  }, [pathname]);

  const settings = liveSettings ?? loaderSettings;
  setI18nState(i18n);
  const css = themeCss(settings.theme);
  const defLang = i18n.langs.find((l) => l.isDefault)?.code ?? "ar";
  const adsensePub = settings.google.adsensePub || DEFAULT_ADSENSE_PUB;
  const allowAdsOnPage = !NO_ADSENSE_PATHS.test(pathname);
  const mobileAdsCfg = useMemo(
    () => parseRootMobileAdsConfig(settings.quickLinks, adsensePub),
    [settings.quickLinks, adsensePub],
  );
  return (
    <html lang={i18n.lang} dir={i18n.dir} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: '(function(){try{var d=localStorage.getItem("rp_dark_mode");if(d==="1"||d==="true"||d==="dark"){document.documentElement.setAttribute("data-theme","dark");document.documentElement.classList.add("dark");}}catch(e){}})();' }} />
        <script dangerouslySetInnerHTML={{ __html: langRedirectScript(i18n.lang, defLang, i18n.langs.map((l) => l.code)) }} />
        <meta name="google-mobile-ads-android-app-id" content={mobileAdsCfg.androidAppId} />
        <meta name="google-mobile-ads-ios-app-id" content={mobileAdsCfg.iosAppId} />
        {allowAdsOnPage ? (
          <>
            <script
              async
              src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsensePub}`}
              crossOrigin="anonymous"
            />
            {mobileAdsCfg.ampAds ? (
              <script
                async
                custom-element="amp-auto-ads"
                src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js"
              />
            ) : null}
          </>
        ) : (
          <style id="no-adsense-on-route">{`.adsbygoogle, ins.adsbygoogle, amp-auto-ads, [aria-label="إعلان"] { display: none !important; }`}</style>
        )}
        <HeadContent />
        {css ? <style id="site-theme" dangerouslySetInnerHTML={{ __html: css }} /> : null}
      </head>
      <body>
        {allowAdsOnPage && mobileAdsCfg.ampAds ? (
          // @ts-expect-error AMP custom element
          <amp-auto-ads type="adsense" data-ad-client={adsensePub} />
        ) : null}
        <SiteSettingsProvider value={settings}>
          <AppLaunchSplashAndStatusBarBridge />
          <SecurityAndCopyrightShield />
          <PreviewHostBridge />
          <ServiceWorkerRegistration />
          <GoogleMobileAdsBridge
            config={mobileAdsCfg}
            allowAdsOnPage={allowAdsOnPage}
            pathname={pathname}
          />
          <AuthProvider>
            <Outlet />
            <GlobalCustomBottomBar />
          </AuthProvider>
          <SiteAnalytics />
          {allowAdsOnPage ? <GoogleServices /> : null}
        </SiteSettingsProvider>
        <Scripts />
      </body>
    </html>
  );
}

/**
 * Pages are cached per URL, so the server picks the language only from `?lang=`. If the visitor
 * chose another language (cookie) and landed on a URL without it, switch once to the right URL.
 */
function langRedirectScript(lang: string, def: string, codes: string[]) {
  return `(function(){try{var m=document.cookie.match(/(?:^|; )lang=([^;]+)/);var w=m?decodeURIComponent(m[1]):"";var ok=${JSON.stringify(codes)};if(!w||ok.indexOf(w)<0||w===${JSON.stringify(lang)})return;var u=new URL(location.href);if(u.searchParams.has("lang"))return;if(w===${JSON.stringify(def)})return;u.searchParams.set("lang",w);location.replace(u.toString());}catch(e){}})();`;
}

function baseHead() {
  return {
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      // Fallbacks; every public route sets its own title/description/canonical via seo().
      { title: tr("رهط بوست | أخبار رهط والنقب") },
      {
        name: "description",
        content:
          tr("رهط بوست: أخبار رهط والنقب، مواعيد باصات رهط، دليل محلات وخدمات رهط، إعلانات مبوبة وأرقام الطوارئ."),
      },
      { property: "og:locale", content: "ar_AR" },
      ...(__SITE_VERIFICATION__.google
        ? [{ name: "google-site-verification", content: __SITE_VERIFICATION__.google }]
        : []),
      ...(__SITE_VERIFICATION__.bing
        ? [{ name: "msvalidate.01", content: __SITE_VERIFICATION__.bing }]
        : []),
      { name: "theme-color", content: "#F2C94C" },
      // iOS home-screen app: own name, light status bar over the white app bar, standalone.
      { name: "apple-mobile-web-app-title", content: tr("رهط بوست") },
      { name: "apple-mobile-web-app-status-bar-style", content: "default" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "application-name", content: tr("رهط بوست") },
      { name: "format-detection", content: "telephone=no" },
    ],
    links: [
      { rel: "icon", href: "/favicon.ico", sizes: "32x32" },
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "icon", type: "image/png", sizes: "32x32", href: "/icons/favicon-32.png" },
      { rel: "icon", type: "image/png", sizes: "16x16", href: "/icons/favicon-16.png" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", sizes: "180x180", href: "/apple-touch-icon.png" },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1290x2796.png",
        media:
          "(device-width: 430px) and (device-height: 932px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1179x2556.png",
        media:
          "(device-width: 393px) and (device-height: 852px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1170x2532.png",
        media:
          "(device-width: 390px) and (device-height: 844px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1284x2778.png",
        media:
          "(device-width: 428px) and (device-height: 926px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1125x2436.png",
        media:
          "(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-828x1792.png",
        media:
          "(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1242x2688.png",
        media:
          "(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-750x1334.png",
        media:
          "(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-640x1136.png",
        media:
          "(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-2048x2732.png",
        media:
          "(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1668x2388.png",
        media:
          "(device-width: 834px) and (device-height: 1194px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1640x2360.png",
        media:
          "(device-width: 820px) and (device-height: 1180px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
      {
        rel: "apple-touch-startup-image",
        href: "/splash/apple-splash-1536x2048.png",
        media:
          "(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2) and (orientation: portrait)",
      },
    ],
  };
}
