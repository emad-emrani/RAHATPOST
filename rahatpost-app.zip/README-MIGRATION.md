# نسخة احتياطية كاملة لموقع rahatpost.com — دليل النقل إلى استضافة أخرى

> ⚠️ **سرّي:** ملف `database/rahatpost.sql` يحتوي بيانات الأعضاء (البريد الإلكتروني، كلمات المرور المُشفّرة، الجلسات). احتفظ بهذا الملف المضغوط في مكان خاص ومشفّر، ولا ترسله لأحد ولا ترفعه علناً.
> لا يحتوي الملف على أي أسرار (مفاتيح API أو كلمات مرور الخدمات) — فقط أسماء المتغيرات في `env-vars.template`.

## محتويات النسخة
| المجلد/الملف | المحتوى |
|---|---|
| `source/` | الكود المصدري الكامل من فرع main (بدون node_modules وبدون ملفات .env) |
| `database/rahatpost.sql` | نسخة كاملة من قاعدة البيانات (61 جدولاً: البنية + البيانات + الفهارس + المفاتيح) — نسخة PostgreSQL |
| `blob/files/media/` | جميع الصور والملفات المرفوعة (Vercel Blob) |
| `blob/blob-index.csv` | قائمة الملفات وأحجامها وتواريخها |
| `env-vars.template` | أسماء متغيرات البيئة المطلوبة (بدون قيم) |

## 1) المتطلبات على الاستضافة الجديدة
- خادم Node.js الإصدار 22 أو أحدث (VPS مثل Hetzner/DigitalOcean، أو منصّة مثل Render/Railway/Netlify).
- قاعدة بيانات PostgreSQL الإصدار 16 أو أحدث (Neon أو Supabase أو Postgres على نفس الخادم).

## 2) استعادة قاعدة البيانات
```bash
createdb rahatpost
psql "postgres://USER:PASS@HOST:5432/rahatpost" -f database/rahatpost.sql
```
الملف يعمل داخل معاملة واحدة (BEGIN/COMMIT)، وقد جُرّبت استعادته بنجاح.

## 3) الصور والملفات
- الموقع يخزّن الصور في Vercel Blob تحت المسار `media/<key>` (انظر `source/src/lib/media/storage.server.ts`).
- **إن بقيت على Vercel Blob:** ضع `BLOB_READ_WRITE_TOKEN` ولا حاجة لشيء آخر.
- **إن انتقلت كلياً:** ارفع محتوى `blob/files/` إلى مخزن جديد (مثل S3 أو Cloudflare R2) أو إلى مجلد على الخادم، وعدّل الملف `storage.server.ts` ليقرأ ويكتب من هناك (الدوال putMedia / getMedia / deleteMediaFiles فقط).

## 4) متغيرات البيئة
انسخ `env-vars.template` إلى `.env` واملأ القيم من حساباتك (Vercel ← Settings ← Environment Variables، Resend، Google، Facebook، Gemini…). أهمها:
`DATABASE_URL`، `BETTER_AUTH_SECRET` (استخدم نفس القيمة القديمة كي تبقى جلسات الأعضاء صالحة)، `ADMIN_PASSWORD`، `ADMIN_MASTER_EMAIL`، `RESEND_API_KEY`، `VAPID_*` (نفس القيم كي تستمر إشعارات المتصفح)، `GOOGLE_*` و`FACEBOOK_*` لتسجيل الدخول.

## 5) البناء والتشغيل
الإعداد الحالي مضبوط لـ Vercel (`preset: "vercel"` في `vite.config.ts`). على خادم Node عادي غيّره إلى `preset: "node-server"` ثم:
```bash
cd source
npm ci
npm run build          # يبني الموقع ويطبّق ترحيلات قاعدة البيانات
node .output/server/index.mjs    # يعمل على المنفذ 3000 (PORT=3000)
```
يُفضّل تشغيله عبر pm2 أو systemd، ووضع Nginx أو Caddy أمامه لشهادة HTTPS.

## 6) الدومين (DNS في GoDaddy)
- سجل `A` للاسم `@` يشير إلى IP الخادم الجديد، و`CNAME` للاسم `www` إلى `rahatpost.com`.
- أبقِ سجلات البريد (SPF/DKIM الخاصة بـ Resend و `_dmarc`) كما هي.
- حدّث روابط إعادة التوجيه في Google وFacebook OAuth إن تغيّر الدومين.

## 7) بعد النقل
افحص: الصفحة الرئيسية، تسجيل الدخول، /admin، ظهور الصور، إرسال بريد تجريبي، ثم أوقف المشروع القديم على Vercel.
