import { useEffect, useState } from "react";
import { getLang, tr, trv } from "@/lib/i18n/core";

function plural(n: number, one: string, two: string, few: string, many: string) {
  if (n === 1) return one;
  if (n === 2) return two;
  if (n >= 3 && n <= 10) return `${n} ${few}`;
  return `${n} ${many}`;
}

/** Arabic relative time, e.g. «منذ 5 دقائق», «منذ ساعتين», «منذ يومين». */
export function relativeTimeAr(iso: string, now: number): string {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return "";
  const diff = Math.max(0, now - t);
  const min = Math.floor(diff / 60_000);
  if (min < 1) return tr("الآن");
  const lang = getLang();
  if (lang !== "ar") {
    try {
      const rtf = new Intl.RelativeTimeFormat(lang, { numeric: "auto" });
      if (min < 60) return rtf.format(-min, "minute");
      if (min < 1440) return rtf.format(-Math.floor(min / 60), "hour");
      if (min < 43200) return rtf.format(-Math.floor(min / 1440), "day");
      return new Date(t).toLocaleDateString(lang, { timeZone: "Asia/Jerusalem" });
    } catch {
      /* fall through to Arabic */
    }
  }
  if (min < 60) return tr("منذ {0}", plural(min, "دقيقة", "دقيقتين", "دقائق", "دقيقة"));
  const hours = Math.floor(min / 60);
  if (hours < 24) return tr("منذ {0}", plural(hours, "ساعة", "ساعتين", "ساعات", "ساعة"));
  const days = Math.floor(hours / 24);
  if (days < 30) return tr("منذ {0}", plural(days, "يوم", "يومين", "أيام", "يوماً"));
  return new Date(t).toLocaleDateString("ar-u-nu-latn", { timeZone: "Asia/Jerusalem" });
}

/**
 * Starts from the server's reference time (so SSR and hydration match), then
 * switches to the live clock after mount and ticks every minute.
 */
export function useNow(serverNow: number): number {
  const [now, setNow] = useState(serverNow);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 60_000);
    return () => clearInterval(id);
  }, []);
  return now;
}

/** "Source" line for a news item: the publisher, or «من القراء · <poster>» for reader posts. */
export function newsByline(item: { source: string; reader?: { name: string } }): string {
  return item.reader ? tr("من القراء · {0}", item.reader.name) : trv(item.source);
}
