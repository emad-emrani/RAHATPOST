import { createFileRoute, Link } from "@tanstack/react-router";
import { ExternalLink, Globe, MapPin } from "lucide-react";
import { OsmCredit } from "@/components/osm-credit";
import { RevealPhone } from "@/components/phone";
import { Shell } from "@/components/shell";
import { getApprovedEntries } from "@/lib/directory/api";
import { mapsUrl, osmEntries, type DirectoryEntry } from "@/lib/directory/types";
import { breadcrumbLd, localBusinessLd, seo, SITE_URL, snippet } from "@/lib/seo";
import { mediaUrl } from "@/lib/media/types";
import { ReportButton } from "@/components/report";
import { GuideCard } from "@/components/guide";
import { guidesForPlace } from "@/data/guides";
import { tr, trv } from "@/lib/i18n/core";

export const Route = createFileRoute("/directory/$slug")({
  loader: async ({ params }) => {
    let place: DirectoryEntry | undefined;
    if (params.slug.startsWith("biz-")) {
      const approved = await getApprovedEntries();
      place = approved.entries.find((e) => e.slug === params.slug);
    } else {
      place = osmEntries().find((e) => e.slug === params.slug);
    }
    return { place: place ?? null };
  },
  staleTime: 60_000,
  head: ({ loaderData, params }) => {
    const p = loaderData?.place;
    const path = `/directory/${params.slug}`;
    if (!p) {
      return seo({
        title: tr("النشاط غير موجود · دليل رهط"),
        description: tr("هذا النشاط غير موجود في دليل رهط."),
        path,
        robots: "noindex",
      });
    }
    const where = p.address ?? p.area;
    const description =
      snippet(p.description) ||
      snippet(
        tr("{0}: {1} في رهط{2}. الموقع على الخريطة{3}{4} في دليل رهط بوست.", p.name, p.category, where ? ` (${where})` : "", p.phone ? " ورقم الهاتف" : "", p.openingHours ? " وساعات العمل" : ""),
      );
    return seo({
      title: tr("{0} · {1} في رهط | دليل رهط بوست", p.name, p.category),
      description,
      path,
      image: p.photo ? `${SITE_URL}${mediaUrl(p.photo)}` : undefined,
      jsonLd: [
        localBusinessLd({
          ...p,
          path,
          // Owner phones are shown on request only; don't publish them in markup.
          phone: p.source === "osm" ? p.phone : undefined,
        }),
        breadcrumbLd([
          { name: tr("دليل رهط"), path: "/directory" },
          { name: p.name, path },
        ]),
      ],
    });
  },
  component: BusinessPage,
});

function BusinessPage() {
  const { place } = Route.useLoaderData();

  if (!place) {
    return (
      <Shell>
        <p className="stamp p-4 font-semibold">{tr("هذا النشاط غير موجود في الدليل.")}</p>
        <Link to="/directory" className="btn mt-4">
          {tr("رجوع للدليل")}
        </Link>
      </Shell>
    );
  }

  const digits = place.phone?.replace(/[^\d+]/g, "") ?? "";
  const isMobile = /^(05|\+9725)/.test(digits);

  return (
    <Shell>
      <article className="stamp p-4">
        {place.photo ? (
          <a href={mediaUrl(place.photo)} target="_blank" rel="noopener noreferrer">
            <img
              src={mediaUrl(place.photo)}
              alt={tr("صورة {0}", place.name)}
              className="-mx-4 -mt-4 mb-4 aspect-[16/9] w-[calc(100%+2rem)] max-w-none rounded-t-[var(--radius-card)] bg-surface object-cover"
              decoding="async"
            />
          </a>
        ) : null}
        <span className="chip">{trv(place.category)}</span>
        {place.verified ? <span className="chip chip-ink ms-2">{tr("موثّق")}</span> : null}
        <h1 className="mt-3 text-2xl font-bold">{trv(place.name)}</h1>
        {place.altName ? <p className="font-semibold text-muted">{trv(place.altName)}</p> : null}
        {place.address || place.area ? (
          <p className="mt-1 font-semibold">{place.address || place.area}</p>
        ) : null}
        {place.description ? <p className="mt-3 text-lg">{trv(place.description)}</p> : null}
        {place.openingHours ? (
          <p className="mt-3 font-bold">
            {tr("ساعات العمل:")} <span dir="ltr">{trv(place.openingHours)}</span>
          </p>
        ) : null}

        {place.phone ? (
          <div className="mt-4 grid grid-cols-2 gap-2">
            <RevealPhone phone={place.phone} />
            {isMobile ? (
              <a
                className="btn btn-ghost"
                href={`https://wa.me/${digits.startsWith("+") ? digits.slice(1) : `972${digits.slice(1)}`}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {tr("واتساب")}
              </a>
            ) : null}
          </div>
        ) : (
          <p className="mt-4 font-semibold text-muted">{tr("لا يوجد رقم هاتف مسجّل لهذا المكان.")}</p>
        )}

        <a
          className="btn btn-ghost mt-2 w-full"
          href={mapsUrl(place)}
          target="_blank"
          rel="noopener noreferrer"
        >
          <MapPin className="size-4" aria-hidden />
          {tr("الاتجاهات")}
        </a>
        {place.website ? (
          <a
            className="btn btn-ghost mt-2 w-full"
            href={place.website}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Globe className="size-4" aria-hidden />
            {tr("الموقع الإلكتروني")}
          </a>
        ) : null}
        {place.osm ? (
          <a
            className="mt-3 inline-flex items-center gap-1 text-sm font-bold underline decoration-2 underline-offset-4"
            href={place.osm}
            target="_blank"
            rel="noopener noreferrer"
          >
            {tr("عرض أو تصحيح في OpenStreetMap")}
            <ExternalLink className="size-3" aria-hidden />
          </a>
        ) : null}
      </article>
      {guidesForPlace(place.slug).map((g) => (
        <div key={g.slug} className="mt-4">
          <GuideCard guide={g} />
        </div>
      ))}
      {place.source === "osm" ? (
        <Link to="/submit" search={{ mode: "نشاط", name: place.name }} className="btn mt-4 w-full">
          {tr("هذا نشاطي")}
        </Link>
      ) : null}
      {place.source === "osm" ? <OsmCredit /> : null}
      {place.source === "owner" ? (
        <ReportButton type="business" id={place.slug.replace(/^biz-/, "")} />
      ) : null}
    </Shell>
  );
}
