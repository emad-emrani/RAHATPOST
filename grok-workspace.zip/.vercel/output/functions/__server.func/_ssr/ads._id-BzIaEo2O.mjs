import { i as __toESM } from "../_runtime.mjs";
import { p as getClassified } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
import { i as Route$2 } from "./router-ixJDjjVq.mjs";
import { t as RevealPhone } from "./phone-B64Q3X2a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ads._id-BzIaEo2O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdPage() {
	const { id } = Route$2.useParams();
	const ad = getClassified(id);
	const [reported, setReported] = (0, import_react.useState)(false);
	if (!ad) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "stamp p-4 font-semibold",
		children: "هذا الإعلان غير موجود أو انتهت مدته."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/ads",
		className: "btn mt-4",
		children: "رجوع للإعلانات"
	})] });
	const digits = ad.phone.replaceAll("-", "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: ad.quiet ? "stamp-flat p-4" : "stamp p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: ad.quiet ? "chip" : "chip chip-deep",
				children: ad.type
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 text-3xl font-bold",
				children: ad.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold text-muted",
				children: ad.neighborhood
			}),
			ad.price ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xl font-bold",
				children: ad.price
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg",
				children: ad.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RevealPhone, { phone: ad.phone }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn btn-ghost",
					href: `https://wa.me/972${digits.replace(/^0/, "")}`,
					target: "_blank",
					rel: "noreferrer",
					children: "واتساب"
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "btn btn-ghost mt-4",
		onClick: () => setReported(true),
		children: reported ? "وصل البلاغ للمراقبة" : "إبلاغ"
	})] });
}
//#endregion
export { AdPage as component };
