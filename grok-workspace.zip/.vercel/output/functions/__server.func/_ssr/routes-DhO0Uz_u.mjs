import { i as __toESM } from "../_runtime.mjs";
import { a as businesses, c as duty, l as emergency, n as alert, r as articles, s as classifieds } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Phone, s as MapPin } from "../_libs/lucide-react.mjs";
import { n as Shell, t as SectionTitle } from "./shell-DjaVfhUd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DhO0Uz_u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [q, setQ] = (0, import_react.useState)("");
	const query = q.trim();
	const lead = articles.find((item) => item.breaking) ?? articles[0];
	const rest = articles.filter((item) => item.slug !== lead.slug).slice(0, 4);
	const results = (0, import_react.useMemo)(() => {
		if (!query) return null;
		const hay = (value) => value.includes(query);
		return {
			news: articles.filter((item) => hay(item.title) || hay(item.category)),
			places: businesses.filter((item) => hay(item.name) || hay(item.category) || hay(item.neighborhood)),
			ads: classifieds.filter((item) => hay(item.title) || hay(item.type))
		};
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-4 block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "بحث"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field",
			value: q,
			onChange: (event) => setQ(event.target.value),
			placeholder: "ابحث في الأخبار والدليل والإعلانات"
		})]
	}), results ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchResults, {
		query,
		results
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			lead.breaking ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/news/$slug",
				params: { slug: lead.slug },
				className: "stamp press block bg-brand-deep px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip-ink chip",
						children: "عاجل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-lg font-bold",
						children: lead.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold",
						children: lead.time
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stamp p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold text-muted",
						children: "صيدلية الحراسة اليوم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-bold",
						children: duty.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold",
						children: [
							duty.neighborhood,
							" · ",
							duty.hours
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "btn",
							href: `tel:${duty.phone.replaceAll("-", "")}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4",
								"aria-hidden": true
							}), "اتصال"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "btn btn-ghost",
							href: duty.maps,
							target: "_blank",
							rel: "noreferrer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "size-4",
								"aria-hidden": true
							}), "الاتجاهات"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "أرقام تُحفظ",
				to: "/today",
				more: "كل الأرقام"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scroll-row",
				children: emergency.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${item.phone}`,
					className: "stamp press flex w-28 shrink-0 flex-col items-center px-3 py-3 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-2xl font-bold leading-none",
						children: item.phone
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 text-sm font-bold",
						children: item.name
					})]
				}, item.phone))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "باصات غاليم",
				to: "/buses",
				more: "كل المواعيد"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/buses",
				className: "stamp press block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip",
						children: "شركة גלים"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-xl font-bold",
						children: "خطوط المدينة 1 حتى 6، وبئر السبع وما حولها"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: "أحد–خميس: خط 1 من 05:30 حتى 22:00"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "الأخبار",
					to: "/news",
					more: "كل الأخبار"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/news/$slug",
					params: { slug: lead.slug },
					className: "stamp press mb-3 block p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip",
							children: lead.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-2xl font-bold",
							children: lead.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-semibold text-muted",
							children: [
								lead.time,
								" · ",
								lead.source
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "stack-list",
					children: rest.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/news/$slug",
						params: { slug: item.slug },
						className: "block px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-bold text-muted",
							children: [
								item.category,
								" · ",
								item.time
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-bold",
							children: item.title
						})]
					}) }, item.slug))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stamp bg-brand-deep p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "chip",
						children: "تنبيه بلدي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-xl font-bold",
						children: alert.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: alert.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-bold",
						children: alert.until
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "من الدليل",
				to: "/directory",
				more: "كل الدليل"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2",
				children: businesses.filter((item) => item.verified).slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/directory/$slug",
					params: { slug: item.slug },
					className: "stamp press block h-full p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip",
							children: item.category
						}),
						item.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip chip-ink ms-2",
							children: "موثّق"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-lg font-bold",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-muted",
							children: item.neighborhood
						})
					]
				}) }, item.slug))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "آخر الإعلانات",
				to: "/ads",
				more: "كل الإعلانات"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: classifieds.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/ads/$id",
					params: { id: item.id },
					className: "stamp press flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: item.quiet ? "chip" : "chip chip-deep",
							children: item.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-bold",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-muted",
							children: item.neighborhood
						})
					] }), item.price ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 font-bold",
						children: item.price
					}) : null]
				}) }, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-ink/70 md:hidden",
				children: "نسخة عرض بألوان الشعار. أرقام الطوارئ الوطنية حقيقية، وبقية الأرقام نماذج."
			})
		]
	})] });
}
function SearchResults({ query, results }) {
	const empty = results.news.length + results.places.length + results.ads.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-2xl font-bold",
				children: [
					"نتائج «",
					query,
					"»"
				]
			}),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "stamp p-4 font-semibold",
				children: "لا توجد نتيجة. جرّب اسماً أو حياً أو تصنيفاً."
			}) : null,
			results.news.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/news/$slug",
				params: { slug: item.slug },
				className: "stamp press block p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "chip",
					children: item.category
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-bold",
					children: item.title
				})]
			}, item.slug)),
			results.places.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/directory/$slug",
				params: { slug: item.slug },
				className: "stamp press block p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "chip",
					children: item.category
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-bold",
					children: item.name
				})]
			}, item.slug)),
			results.ads.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ads/$id",
				params: { id: item.id },
				className: "stamp press block p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "chip",
					children: item.type
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-bold",
					children: item.title
				})]
			}, item.id))
		]
	});
}
//#endregion
export { Home as component };
