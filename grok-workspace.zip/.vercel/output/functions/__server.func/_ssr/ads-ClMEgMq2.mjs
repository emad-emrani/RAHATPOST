import { i as __toESM } from "../_runtime.mjs";
import { s as classifieds, t as adTypes } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ads-ClMEgMq2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdsPage() {
	const [type, setType] = (0, import_react.useState)("الكل");
	const list = classifieds.filter((item) => type === "الكل" || item.type === type);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-3 text-3xl font-bold",
			children: "الإعلانات"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "scroll-row mb-4",
			children: adTypes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: item === type ? "chip chip-ink shrink-0" : "chip shrink-0 bg-paper",
				onClick: () => setType(item),
				children: item
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ads/$id",
				params: { id: item.id },
				className: item.quiet ? "stamp-flat press block p-4" : "stamp press block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: item.quiet ? "chip" : "chip chip-deep",
						children: item.type
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-xl font-bold",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-muted",
						children: item.neighborhood
					}),
					item.price ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-bold",
						children: item.price
					}) : null
				]
			}) }, item.id))
		})
	] });
}
//#endregion
export { AdsPage as component };
