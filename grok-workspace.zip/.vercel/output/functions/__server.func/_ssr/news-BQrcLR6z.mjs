import { i as __toESM } from "../_runtime.mjs";
import { o as categories, r as articles } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/news-BQrcLR6z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewsPage() {
	const [cat, setCat] = (0, import_react.useState)("الكل");
	const list = articles.filter((item) => cat === "الكل" || item.category === cat);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-3 text-3xl font-bold",
			children: "الأخبار"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "scroll-row mb-4",
			children: ["الكل", ...categories].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: item === cat ? "chip chip-ink shrink-0" : "chip shrink-0 bg-paper",
				onClick: () => setCat(item),
				children: item
			}, item))
		}),
		list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "stamp p-4 font-semibold",
			children: "لا خبر في هذا التصنيف اليوم."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/news/$slug",
				params: { slug: item.slug },
				className: "stamp press block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: item.breaking ? "chip chip-deep" : "chip",
						children: item.breaking ? "عاجل" : item.category
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-xl font-bold",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-semibold text-muted",
						children: [
							item.time,
							" · ",
							item.source
						]
					})
				]
			}) }, item.slug))
		})
	] });
}
//#endregion
export { NewsPage as component };
