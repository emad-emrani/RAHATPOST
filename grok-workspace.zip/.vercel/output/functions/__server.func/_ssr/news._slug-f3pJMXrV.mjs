import { d as getArticle, r as articles } from "./content-B8va05CA.mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
import { n as Route } from "./router-ixJDjjVq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/news._slug-f3pJMXrV.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlePage() {
	const { slug } = Route.useParams();
	const article = getArticle(slug);
	if (!article) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "stamp p-4 font-semibold",
		children: "هذا الخبر غير موجود."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/news",
		className: "btn mt-4",
		children: "رجوع للأخبار"
	})] });
	const related = articles.filter((item) => item.slug !== article.slug).slice(0, 3);
	const share = encodeURIComponent(`${article.title}\nرهط بوست`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "stamp p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: article.breaking ? "chip chip-deep" : "chip",
					children: article.breaking ? "عاجل" : article.category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-bold",
					children: article.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-semibold text-muted",
					children: [
						article.time,
						" · ",
						article.source
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-col gap-3 text-lg",
					children: article.body.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "btn",
				href: `https://t.me/share/url?url=https://rahatpost.com/news/${article.slug}&text=${share}`,
				target: "_blank",
				rel: "noreferrer",
				children: "تليجرام"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "btn btn-ghost",
				href: `https://wa.me/?text=${share}%0Ahttps://rahatpost.com/news/${article.slug}`,
				target: "_blank",
				rel: "noreferrer",
				children: "واتساب"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 mb-3 text-xl font-bold",
			children: "ذات صلة"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/news/$slug",
				params: { slug: item.slug },
				className: "stamp press block px-4 py-3 font-bold",
				children: item.title
			}) }, item.slug))
		})
	] });
}
//#endregion
export { ArticlePage as component };
