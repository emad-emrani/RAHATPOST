import { i as __toESM } from "../_runtime.mjs";
import { f as getBusiness } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as MapPin } from "../_libs/lucide-react.mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
import { r as Route$1 } from "./router-ixJDjjVq.mjs";
import { t as RevealPhone } from "./phone-B64Q3X2a.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/directory._slug-CsxCBcT4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BusinessPage() {
	const { slug } = Route$1.useParams();
	const place = getBusiness(slug);
	const [claimed, setClaimed] = (0, import_react.useState)(false);
	if (!place) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "stamp p-4 font-semibold",
		children: "هذا النشاط غير موجود في الدليل."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/directory",
		className: "btn mt-4",
		children: "رجوع للدليل"
	})] });
	const digits = place.phone.replaceAll("-", "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "stamp p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "chip",
				children: place.category
			}),
			place.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "chip chip-ink ms-2",
				children: "موثّق"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "chip ms-2",
				children: "بانتظار التوثيق"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 text-3xl font-bold",
				children: place.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold text-muted",
				children: place.neighborhood
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-lg",
				children: place.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-bold",
				children: [
					place.open ? "مفتوح" : "مغلق الآن",
					" · ",
					place.hours
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RevealPhone, { phone: place.phone }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "btn btn-ghost",
					href: `https://wa.me/972${digits.replace(/^0/, "")}`,
					target: "_blank",
					rel: "noreferrer",
					children: "واتساب"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: "btn btn-ghost mt-2 w-full",
				href: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${place.name} رهط`)}`,
				target: "_blank",
				rel: "noreferrer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
					className: "size-4",
					"aria-hidden": true
				}), "الاتجاهات"]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "btn mt-4 w-full",
		onClick: () => setClaimed(true),
		children: claimed ? "وصل طلب المطالبة، بانتظار اتصال التوثيق" : "هذا نشاطي"
	})] });
}
//#endregion
export { BusinessPage as component };
