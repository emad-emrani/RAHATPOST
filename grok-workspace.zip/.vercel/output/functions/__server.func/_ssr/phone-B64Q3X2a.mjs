import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/phone-B64Q3X2a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RevealPhone({ phone }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "btn",
		onClick: () => setOpen(true),
		children: "إظهار الرقم"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: "btn",
		href: `tel:${phone.replaceAll("-", "")}`,
		children: phone
	});
}
//#endregion
export { RevealPhone as t };
