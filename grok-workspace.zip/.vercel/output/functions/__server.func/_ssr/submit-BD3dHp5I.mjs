import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/submit-BD3dHp5I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var modes = [
	"خبر",
	"إعلان",
	"نشاط"
];
function SubmitPage() {
	const [mode, setMode] = (0, import_react.useState)("خبر");
	const [sent, setSent] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-3 text-3xl font-bold",
			children: "أضف"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-3 gap-2",
			children: modes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: item === mode ? "chip chip-ink justify-center py-2" : "chip justify-center bg-paper py-2",
				onClick: () => {
					setMode(item);
					setSent(false);
				},
				children: item
			}, item))
		}),
		sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "stamp p-4 text-lg font-bold",
			children: "وصلنا. لن يُنشر قبل المراجعة."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "stamp flex flex-col gap-3 p-4",
			onSubmit: (event) => {
				event.preventDefault();
				setSent(true);
			},
			children: [
				mode === "خبر" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "ماذا حدث؟",
					name: "what"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "أين في رهط؟",
					name: "where"
				})] }) : null,
				mode === "إعلان" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "عنوان الإعلان",
						name: "title"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "التفاصيل",
						name: "body",
						long: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الحي",
						name: "area"
					})
				] }) : null,
				mode === "نشاط" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "اسم النشاط",
						name: "name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "التصنيف",
						name: "category"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الحي",
						name: "area"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "سطر وصف",
						name: "about"
					})
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "هاتف للتواصل",
					name: "phone"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn",
					children: "إرسال للمراجعة"
				})
			]
		})
	] });
}
function Field({ label, name, long }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block font-bold",
		children: [label, long ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			name,
			required: true,
			className: "field mt-1 min-h-28"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			required: true,
			className: "field mt-1"
		})]
	});
}
//#endregion
export { SubmitPage as component };
