import { i as __toESM } from "../_runtime.mjs";
import { a as businesses, i as businessCategories } from "./content-B8va05CA.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-DjaVfhUd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/directory-D4YLLTe7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DirectoryPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("الكل");
	const [verifiedOnly, setVerifiedOnly] = (0, import_react.useState)(false);
	const list = (0, import_react.useMemo)(() => {
		return businesses.filter((item) => {
			const query = q.trim();
			const matchesQuery = !query || item.name.includes(query) || item.neighborhood.includes(query) || item.category.includes(query);
			const matchesCat = cat === "الكل" || item.category === cat;
			const matchesVerified = !verifiedOnly || item.verified;
			return matchesQuery && matchesCat && matchesVerified;
		});
	}, [
		q,
		cat,
		verifiedOnly
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-3 text-3xl font-bold",
			children: "الدليل"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field mb-3",
			value: q,
			onChange: (event) => setQ(event.target.value),
			placeholder: "اسم النشاط أو الحي"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scroll-row",
				children: businessCategories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: item === cat ? "chip chip-ink shrink-0" : "chip shrink-0 bg-paper",
					onClick: () => setCat(item),
					children: item
				}, item))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: verifiedOnly ? "chip chip-ink mb-4" : "chip mb-4 bg-paper",
			onClick: () => setVerifiedOnly((value) => !value),
			children: "موثّق فقط"
		}),
		list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "stamp p-4 font-semibold",
			children: "لا نشاط يطابق البحث."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/directory/$slug",
				params: { slug: item.slug },
				className: "stamp press block p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip",
						children: item.category
					}),
					item.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "chip chip-ink ms-2",
						children: "موثّق"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 block text-xl font-bold",
						children: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold text-muted",
						children: [
							item.neighborhood,
							" · ",
							item.open ? "مفتوح" : "مغلق الآن",
							" · ",
							item.hours
						]
					})
				]
			}) }, item.slug))
		})
	] });
}
//#endregion
export { DirectoryPage as component };
