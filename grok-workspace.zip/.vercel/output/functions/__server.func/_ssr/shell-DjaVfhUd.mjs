import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Newspaper, c as House, l as Bus, n as Store, o as Megaphone, r as Siren } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-DjaVfhUd.js
var import_jsx_runtime = require_jsx_runtime();
var logo_default = "/assets/logo-j3tMaDGd.jpg";
var nav = [
	{
		to: "/",
		label: "الرئيسية",
		icon: House,
		exact: true
	},
	{
		to: "/news",
		label: "الأخبار",
		icon: Newspaper,
		exact: false
	},
	{
		to: "/today",
		label: "اليوم",
		icon: Siren,
		exact: true
	},
	{
		to: "/buses",
		label: "باصات",
		icon: Bus,
		exact: true
	},
	{
		to: "/directory",
		label: "الدليل",
		icon: Store,
		exact: false
	},
	{
		to: "/ads",
		label: "الإعلانات",
		icon: Megaphone,
		exact: false
	}
];
function Shell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-brand text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "edge-b sticky top-0 z-30 bg-brand",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl items-center gap-3 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "shrink-0 rounded-lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logo_default,
								alt: "",
								className: "h-16 w-16 object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xl font-bold leading-none",
								children: "رهط بوست"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-ink/70",
								children: "رهط والنقب"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/submit",
							className: "btn px-4",
							children: "أضف"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto hidden max-w-3xl gap-2 px-4 pb-3 md:flex",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						activeOptions: { exact: item.exact },
						className: "pill",
						activeProps: { className: "bg-ink text-brand" },
						children: item.label
					}, item.to))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-3xl px-4 pt-4 pb-28 md:pb-16",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto hidden max-w-3xl px-4 pb-8 text-sm font-semibold text-ink/70 md:block",
				children: "نسخة عرض بألوان الشعار. أرقام الطوارئ الوطنية حقيقية، وبقية الأرقام نماذج."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "edge-t fixed inset-x-0 bottom-0 z-30 bg-brand md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex max-w-3xl",
					children: nav.map((item) => {
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							activeOptions: { exact: item.exact },
							className: "flex flex-1 flex-col items-center gap-1 py-2 text-xs font-bold",
							activeProps: { className: "bg-ink text-brand" },
							inactiveProps: { className: "text-ink" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": true
							}), item.label]
						}, item.to);
					})
				})
			})
		]
	});
}
function SectionTitle({ title, to, more }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 flex items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-bold",
			children: title
		}), to && more ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to,
			className: "text-sm font-bold underline decoration-2 underline-offset-4",
			children: more
		}) : null]
	});
}
//#endregion
export { Shell as n, SectionTitle as t };
