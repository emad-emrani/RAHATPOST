//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RavdAjzf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/ads",
			"/buses",
			"/directory",
			"/news",
			"/submit",
			"/today"
		],
		preloads: ["/assets/index-BXKubiUN.js", "/assets/createLucideIcon-B4xyAFQ-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BXKubiUN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D9YYqqzQ.js",
			"/assets/shell-DI2rdevM.js",
			"/assets/map-pin-SnndSv0M.js",
			"/assets/phone-Bg1artK3.js"
		]
	},
	"/ads": {
		filePath: "/workspace/src/routes/ads.tsx",
		children: ["/ads/$id"],
		preloads: ["/assets/ads-DMKizyHl.js", "/assets/shell-DI2rdevM.js"]
	},
	"/buses": {
		filePath: "/workspace/src/routes/buses.tsx",
		children: void 0,
		preloads: ["/assets/buses-CRGYj2I1.js", "/assets/shell-DI2rdevM.js"]
	},
	"/directory": {
		filePath: "/workspace/src/routes/directory.tsx",
		children: ["/directory/$slug"],
		preloads: ["/assets/directory-sKImWHQW.js", "/assets/shell-DI2rdevM.js"]
	},
	"/news": {
		filePath: "/workspace/src/routes/news.tsx",
		children: ["/news/$slug"],
		preloads: ["/assets/news-DkQRPwy0.js", "/assets/shell-DI2rdevM.js"]
	},
	"/submit": {
		filePath: "/workspace/src/routes/submit.tsx",
		children: void 0,
		preloads: ["/assets/submit-DEbg_92l.js", "/assets/shell-DI2rdevM.js"]
	},
	"/today": {
		filePath: "/workspace/src/routes/today.tsx",
		children: void 0,
		preloads: [
			"/assets/today-y3iN9Hh4.js",
			"/assets/shell-DI2rdevM.js",
			"/assets/map-pin-SnndSv0M.js",
			"/assets/phone-Bg1artK3.js"
		]
	},
	"/ads/$id": {
		filePath: "/workspace/src/routes/ads.$id.tsx",
		children: void 0,
		preloads: ["/assets/ads._id-Mo6zUfQJ.js", "/assets/phone-C_72IHT7.js"]
	},
	"/directory/$slug": {
		filePath: "/workspace/src/routes/directory.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/directory._slug-Cb56g_T2.js",
			"/assets/map-pin-SnndSv0M.js",
			"/assets/phone-C_72IHT7.js"
		]
	},
	"/news/$slug": {
		filePath: "/workspace/src/routes/news.$slug.tsx",
		children: void 0,
		preloads: ["/assets/news._slug-CYye0mQz.js"]
	}
} });
//#endregion
export { tsrStartManifest };
